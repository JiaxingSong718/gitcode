# 默认用 image_url 字段传图片
python3 generate.py --input /Users/jiaxing/Documents/data/bench/v0330_S5_top4k_person_anno_test_set_sample_one_merge_url.jsonl --limit 15

# 不传图片（纯文本模式）
# python3 generate.py --input ../v0330_S5_*.jsonl --image-field ""
