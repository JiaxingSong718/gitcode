"""
全局配置：API 密钥、模型参数、游走参数等。
修改这里即可调整所有行为，无需改动核心逻辑。
"""
import os
from dotenv import load_dotenv

load_dotenv()

# ── LLM ──────────────────────────────────────────────────────────────
API_KEY  = os.getenv("API_KEY", "")
BASE_URL = os.getenv("BASE_URL", "https://antchat.alipay.com/v1")
MODEL    = os.getenv("MODEL", "Qwen3.5-397B-A17B")
TEMPERATURE = float(os.getenv("TEMPERATURE", "0.6"))

# SOFA 链路追踪 Header（antchat 接口需要，留空则不发送）
SOFA_TRACE_ID = os.getenv("SOFA_TRACE_ID", "")
SOFA_RPC_ID   = os.getenv("SOFA_RPC_ID", "")

# ── 图游走 ────────────────────────────────────────────────────────────
HOPS = int(os.getenv("HOPS", "3"))          # 每次随机游走的跳数
NUM_PER_ENTITY = int(os.getenv("NUM_PER_ENTITY", "1"))  # 每个实体生成几条 QA

# ── Wikipedia 描述 ────────────────────────────────────────────────────
WIKI_MAX_CHARS = int(os.getenv("WIKI_MAX_CHARS", "4000"))   # Wikipedia 全文截取上限
WIKI_MIN_CHARS = int(os.getenv("WIKI_MIN_CHARS", "200"))    # 低于此值视为重定向页

# ── 网络 ──────────────────────────────────────────────────────────────
REQUEST_TIMEOUT   = int(os.getenv("REQUEST_TIMEOUT", "15"))
HOP_SLEEP_SECONDS = float(os.getenv("HOP_SLEEP_SECONDS", "2"))  # 每跳间隔，避免限流
