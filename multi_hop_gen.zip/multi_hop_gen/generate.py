"""
批量生成多跳 QA 数据的入口脚本。

用法示例：
    # 使用默认参数（每实体 1 条，3 跳）
    python generate.py --input ../v0330_S5_top4k_person_anno_test_set_sample_one_merge_url.jsonl

    # 每实体生成 3 条，5 跳
    python generate.py --input ../v0330_S5_top4k_person_anno_test_set_sample_one_merge_url.jsonl \\
                       --num-per-entity 3 --hops 5

    # 指定输出文件、从第 100 条开始（断点续跑）
    python generate.py --input ../xxx.jsonl --output results.jsonl --start-from 100

参数说明：
    --input          输入 jsonl 文件路径（必填）
    --output         输出 jsonl 文件路径（默认 multi_hop_results.jsonl，追加写入）
    --entity-field   jsonl 中实体名所在字段（默认 class）
    --image-field    jsonl 中图片 URL 所在字段（默认 image_url；设为空字符串则不传图片）
    --num-per-entity 每个实体生成几条 QA（默认读取 config.NUM_PER_ENTITY）
    --hops           随机游走跳数（默认读取 config.HOPS）
    --start-from     跳过前 N 条记录，用于断点续跑（默认 0）
    --limit          最多处理 N 条记录，0 表示不限（默认 0）
"""
import argparse
import json
import os
import sys
import time

# 确保能 import 同目录下的 core / config
sys.path.insert(0, os.path.dirname(__file__))

import config
from core import WikidataGraphWalker, QASynthesizer


def parse_args():
    parser = argparse.ArgumentParser(description="批量生成多跳 QA 数据")
    parser.add_argument("--input",          required=True,  help="输入 jsonl 文件路径")
    parser.add_argument("--output",         default="multi_hop_results.jsonl",
                        help="输出 jsonl 文件路径（追加写入，默认 multi_hop_results.jsonl）")
    parser.add_argument("--entity-field",   default="class",
                        help="jsonl 中实体名所在字段（默认 class）")
    parser.add_argument("--image-field",    default="extra_info.pic_url",
                        help="jsonl 中图片 URL 所在字段，支持点号嵌套如 extra_info.pic_url（默认）；传空字符串则不使用图片")
    parser.add_argument("--num-per-entity", type=int, default=config.NUM_PER_ENTITY,
                        help=f"每个实体生成几条 QA（默认 {config.NUM_PER_ENTITY}）")
    parser.add_argument("--hops",           type=int, default=config.HOPS,
                        help=f"随机游走跳数（默认 {config.HOPS}）")
    parser.add_argument("--start-from",     type=int, default=0,
                        help="跳过前 N 条记录，用于断点续跑（默认 0）")
    parser.add_argument("--limit",          type=int, default=0,
                        help="最多处理 N 条记录，0 表示不限（默认 0）")
    return parser.parse_args()


def load_jsonl(path: str):
    records = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def get_nested(record: dict, field_path: str) -> str:
    """
    支持点号嵌套取值，例如 "extra_info.pic_url"。
    取不到返回空字符串。
    """
    obj = record
    for key in field_path.split("."):
        if not isinstance(obj, dict):
            return ""
        obj = obj.get(key, "")
    return str(obj).strip() if obj else ""


def append_jsonl(path: str, record: dict):
    """将一条记录追加写入 jsonl 文件（每行一个 JSON）。"""
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def main():
    args = parse_args()

    # ── 加载输入 ──────────────────────────────────────────────────
    print(f"[*] 加载输入文件: {args.input}")
    all_records = load_jsonl(args.input)
    total = len(all_records)
    print(f"[*] 共 {total} 条记录")

    # 应用 start-from / limit
    records = all_records[args.start_from:]
    if args.limit > 0:
        records = records[:args.limit]
    print(f"[*] 本次处理: {len(records)} 条"
          f"（从第 {args.start_from} 条开始"
          + (f"，最多 {args.limit} 条" if args.limit > 0 else "") + "）")

    # ── 初始化核心组件 ────────────────────────────────────────────
    walker     = WikidataGraphWalker()
    synthesizer = QASynthesizer()

    # ── 输出文件路径（相对于脚本所在目录）────────────────────────
    output_path = args.output
    if not os.path.isabs(output_path):
        output_path = os.path.join(os.path.dirname(__file__), output_path)

    success_count = 0
    fail_count    = 0

    for idx, record in enumerate(records, start=args.start_from + 1):
        entity_name = record.get(args.entity_field, "").strip()
        if not entity_name:
            print(f"[!] 第 {idx} 条记录缺少字段 '{args.entity_field}'，跳过。")
            fail_count += 1
            continue

        # 取图片 URL（image_field 为空字符串时不使用图片）
        image_url = ""
        if args.image_field:
            image_url = get_nested(record, args.image_field)
            if not image_url:
                print(f"[!] 第 {idx} 条记录 '{args.image_field}' 字段为空，将不传图片。")

        print(f"\n{'='*60}")
        print(f"[*] 处理第 {idx}/{total} 条: {entity_name}")
        print(f"{'='*60}")

        for attempt_i in range(1, args.num_per_entity + 1):
            if args.num_per_entity > 1:
                print(f"[*] 第 {attempt_i}/{args.num_per_entity} 次游走")

            # ── 游走：失败最多重试 3 次 ────────────────────────────
            path = None
            walk_max_retries = 3
            for walk_try in range(1, walk_max_retries + 2):  # 1次正常 + 3次重试
                path = walker.search_and_walk(entity_name, hops=args.hops)
                if path:
                    break
                if walk_try <= walk_max_retries:
                    wait = walk_try * 5
                    print(f"[!] '{entity_name}' 游走失败，第 {walk_try}/{walk_max_retries} 次重试，等待 {wait}s...")
                    time.sleep(wait)
            if not path:
                print(f"[!] '{entity_name}' 游走失败（已重试 {walk_max_retries} 次），跳过本次。")
                fail_count += 1
                continue

            # ── QA 合成：失败最多重试 3 次 ────────────────────────
            qa_pair = None
            qa_max_retries = 3
            for qa_try in range(1, qa_max_retries + 2):
                qa_pair = synthesizer.synthesize(
                    path,
                    person_name=entity_name,
                    image_url=image_url or None,
                )
                if qa_pair:
                    break
                if qa_try <= qa_max_retries:
                    wait = qa_try * 10
                    print(f"[!] '{entity_name}' QA 合成失败，第 {qa_try}/{qa_max_retries} 次重试，等待 {wait}s...")
                    time.sleep(wait)
            if not qa_pair:
                print(f"[!] '{entity_name}' QA 合成失败（已重试 {qa_max_retries} 次），跳过本次。")
                fail_count += 1
                continue

            output_record = {
                "source_record_index": idx - 1,
                "entity_name":         entity_name,
                "image_url":           image_url or None,
                "hops":                args.hops,
                "graph_path":          path,
                "qa_pair":             qa_pair,
            }
            append_jsonl(output_path, output_record)
            success_count += 1
            print(f"[+] 已写入: {output_path}  (累计成功 {success_count} 条)")

            # 多次游走之间稍作间隔，避免限流
            if attempt_i < args.num_per_entity:
                time.sleep(3)

    print(f"\n[*] 全部完成。成功 {success_count} 条，失败/跳过 {fail_count} 条。")
    print(f"[*] 结果已保存至: {output_path}")


if __name__ == "__main__":
    main()
