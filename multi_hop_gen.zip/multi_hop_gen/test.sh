curl -X POST https://antchat.alipay.com/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ENGVttMOCwb4fnoC0lBKOLowMEfo9exD" \
  -d '{
    "model": "Qwen3.5-397B-A17B",
    "messages":
    [
        {
            "role": "user",
            "content":
            [
                {
                    "type": "image_url",
                    "image_url": "https://img1.baidu.com/it/u=2486357819,1678612322&fm=253&fmt=auto&app=138&f=JPEG?w=475&h=603"
                },
                {
                    "type": "text",
                    "text": "请描述一下这个图片"
                }
            ]
        }
    ],
    "stream": false
}'