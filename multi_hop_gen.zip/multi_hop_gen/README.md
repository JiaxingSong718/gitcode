# 多跳 QA 数据生成工具

## 概述

本工具用于批量生成**多跳推理问答（Multi-hop QA）**数据集。核心思路是：

1. 以输入实体（如人物名称）为起点，在 **Wikidata 知识图谱**上进行随机游走，构建一条多步事实推理链；
2. 将游走路径喂给 **LLM**，由模型逆向合成一个需要多步推理才能回答的复杂问题；
3. 支持**多模态**模式：若提供人物图片，第一跳变为"看图识人"，后续跳为知识推理，生成视觉+知识的多模态多跳问题。

---

## 目录结构

```
multi_hop_gen/
├── config.py          # 全局配置（API Key、模型、游走参数等）
├── core.py            # 核心模块（WikidataGraphWalker + QASynthesizer）
├── generate.py        # 批量生成入口脚本
├── run.sh             # 快速启动示例
├── test.sh            # LLM 接口连通性测试
└── multi_hop_results.jsonl  # 默认输出文件（追加写入）
```

---

## 工作流程

```
输入 JSONL
    │
    ▼
读取实体名 (entity_field)
    │
    ▼
WikidataGraphWalker.search_and_walk()
    ├─ 搜索 Wikidata 实体 ID
    └─ 随机游走 N 跳
         每跳：获取实体属性 → 随机选一条边 → 跳到下一实体
         每跳附带：Wikipedia 全文描述（优先中文，其次英文）
    │
    ▼
graph_path（游走路径列表）
    │
    ▼
QASynthesizer.synthesize()
    ├─ 有图片 → 多模态 Prompt（第一跳=看图识人）
    └─ 无图片 → 纯文本 Prompt（纯知识推理）
    │
    ▼
输出 JSONL（追加写入）
```

---

## 快速开始

### 1. 配置环境变量

在项目根目录创建 `.env` 文件（或直接设置环境变量）：

```bash
API_KEY=your_api_key_here
BASE_URL=https://antchat.alipay.com/v1
MODEL=Qwen3.5-397B-A17B
```

### 2. 准备输入文件

输入为 JSONL 格式，每行一条记录，至少包含实体名字段（默认字段名为 `class`）。

```jsonl
{"class": "成龙", "extra_info": {"pic_url": "https://example.com/jackie.jpg"}}
{"class": "姚明", "extra_info": {"pic_url": "https://example.com/yao.jpg"}}
{"class": "莫言"}
```

### 3. 运行生成

```bash
# 最简用法（使用默认参数：3跳，每实体1条）
python3 generate.py --input your_data.jsonl

# 指定跳数和每实体生成条数
python3 generate.py --input your_data.jsonl --hops 4 --num-per-entity 2

# 只处理前15条记录（快速测试）
python3 generate.py --input your_data.jsonl --limit 15

# 断点续跑（跳过前100条）
python3 generate.py --input your_data.jsonl --start-from 100

# 不使用图片（纯文本多跳）
python3 generate.py --input your_data.jsonl --image-field ""
```

---

## 参数说明

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--input` | 必填 | 输入 JSONL 文件路径 |
| `--output` | `multi_hop_results.jsonl` | 输出文件路径（追加写入） |
| `--entity-field` | `class` | 实体名所在字段 |
| `--image-field` | `extra_info.pic_url` | 图片 URL 字段（支持点号嵌套；传空字符串则不使用图片） |
| `--num-per-entity` | `1`（见 config） | 每个实体生成几条 QA |
| `--hops` | `3`（见 config） | 随机游走跳数 |
| `--start-from` | `0` | 跳过前 N 条，用于断点续跑 |
| `--limit` | `0`（不限） | 最多处理 N 条记录 |

---

## 配置项（config.py）

| 配置项 | 默认值 | 说明 |
|--------|--------|------|
| `API_KEY` | 环境变量 | LLM API 密钥 |
| `BASE_URL` | `https://antchat.alipay.com/v1` | LLM 接口地址 |
| `MODEL` | `Qwen3.5-397B-A17B` | 使用的模型名称 |
| `TEMPERATURE` | `0.6` | 生成温度 |
| `HOPS` | `3` | 默认游走跳数 |
| `NUM_PER_ENTITY` | `1` | 默认每实体生成条数 |
| `WIKI_MAX_CHARS` | `4000` | Wikipedia 全文截取上限（字符数） |
| `WIKI_MIN_CHARS` | `200` | 低于此值视为重定向页，不使用 |
| `REQUEST_TIMEOUT` | `15` | 网络请求超时（秒） |
| `HOP_SLEEP_SECONDS` | `2` | 每跳间隔（秒），避免 Wikidata 限流 |

---

## 输出格式

输出为 JSONL，每行一条记录，结构如下：

```json
{
  "source_record_index": 0,
  "entity_name": "陈小纭",
  "image_url": "https://example.com/chenxiaoyun.jpg",
  "hops": 3,
  "graph_path": [
    {
      "entity_label": "陈小纭",
      "entity_desc": "陈小纭，中国女演员……（Wikipedia 全文节选）",
      "relation": "出生地",
      "target_id": "Q16666"
    },
    {
      "entity_label": "吉林省",
      "entity_desc": "吉林省，中国东北地区省份……",
      "relation": "行政中心",
      "target_id": "Q92161"
    },
    {
      "entity_label": "长春市",
      "entity_desc": "长春市，吉林省省会……",
      "relation": "拥有",
      "target_id": "Q15913266"
    },
    {
      "entity_label": "长春轨道交通2号线",
      "is_answer": true
    }
  ],
  "qa_pair": {
    "image_analysis": {
      "visual_clues": "图片中是一位长发女性，身穿红色带有黑色滚边的西装外套，正在挥手致意",
      "description_strategy": "描述为'图中这位身穿红色黑边外套、正在挥手致意的女士'，不直接提及姓名"
    },
    "reasoning_and_uniqueness_check": {
      "hop_analysis": "第一跳：通过图片识别出陈小纭。第二跳：陈小纭出生地为吉林省。第三跳：吉林省行政中心为长春市。第四跳：长春市拥有轨道交通2号线。",
      "obfuscation_notes": "将人名模糊为图片描述，将省份模糊为'家乡所在省份'，推理链唯一",
      "naturalness_notes": "采用自然询问口吻，避免生硬的'A的B的C'结构"
    },
    "complex_question": "图中这位身穿红色黑边外套、正在挥手致意的女士，她的出生地位于中国东北地区。请问她家乡所在省份的行政中心，目前运营着哪条编号为'2'的城市轨道交通线路？",
    "answer": "长春轨道交通2号线"
  }
}
```

---

## 示例场景

### 场景一：纯文本多跳（无图片）

**输入记录：**
```json
{"class": "诺兰"}
```

**游走路径（3跳示例）：**
```
诺兰 --[执导]--> 《星际穿越》 --[配乐]--> 汉斯·季默 --[出生地]--> 法兰克福
```

**生成问题：**
> 2014年上映、以虫洞旅行为核心情节的科幻大片，其配乐作曲家的出生城市是哪里？

**答案：** 法兰克福

---

### 场景二：多模态多跳（有图片）

**输入记录：**
```json
{"class": "姚明", "extra_info": {"pic_url": "https://example.com/yaoming.jpg"}}
```

**游走路径（3跳示例）：**
```
姚明 --[效力球队]--> 休斯顿火箭 --[所在城市]--> 休斯顿 --[所在州]--> 德克萨斯州
```

**生成问题（需结合图片）：**
> 图中这位身高格外突出、曾在NBA赛场叱咤风云的运动员，他职业生涯效力时间最长的球队所在城市，属于美国哪个州？

**答案：** 德克萨斯州

---

### 场景三：断点续跑

当任务中途中断时，可通过 `--start-from` 跳过已处理的记录：

```bash
# 假设已处理了前200条，从第201条继续
python3 generate.py --input your_data.jsonl --start-from 200
```

输出文件采用**追加写入**模式，不会覆盖已有结果。

---

### 场景四：批量生成多条

对同一实体生成多条不同路径的 QA（每次游走随机选边，路径不同）：

```bash
python3 generate.py --input your_data.jsonl --num-per-entity 3 --hops 4
```

每条记录将生成 3 条 QA，每条 QA 对应一条不同的随机游走路径。

---

## 注意事项

1. **网络要求**：游走阶段需访问 `wikidata.org` 和 `wikipedia.org`，请确保网络可达。
2. **限流保护**：工具内置了请求重试（最多4次）和跳间延迟（默认2秒），如遇频繁限流可适当增大 `HOP_SLEEP_SECONDS`。
3. **图片下载**：多模态模式下，工具会在本机下载图片并转为 base64 后发送给 LLM（因 LLM 服务无法访问内网 OSS 地址）。
4. **输出追加**：输出文件默认追加写入，重复运行不会覆盖已有数据，断点续跑时请配合 `--start-from` 使用。
5. **路径过滤**：游走过程中会自动过滤无意义属性（如 `P31 instance of`）和无意义实体（如国家、语言等通用节点），以保证路径的信息密度。
