"""
核心模块：WikidataGraphWalker + QASynthesizer
对外暴露的接口：
    walker  = WikidataGraphWalker()
    path    = walker.search_and_walk(entity_name, hops=3)
    qa_pair = QASynthesizer(api_key, base_url, model).synthesize(path)
"""
import json
import random
import re
import time

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

import config


# ─────────────────────────────────────────────────────────────────────
# WikidataGraphWalker
# ─────────────────────────────────────────────────────────────────────

class WikidataGraphWalker:
    def __init__(self):
        self.api_url = "https://www.wikidata.org/w/api.php"
        self.headers = {"User-Agent": "OpenSeeker-Data-Synthesizer/1.0"}
        self.timeout = config.REQUEST_TIMEOUT
        self._cache  = {}

        self.session = requests.Session()
        retry_strategy = Retry(
            total=3,
            backoff_factor=3,
            status_forcelist=[403, 429, 500, 502, 503, 504],
            allowed_methods=["GET"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("https://", adapter)
        self.session.mount("http://",  adapter)

        # ── 过滤无意义属性 ──────────────────────────────────────────
        self.excluded_props = {
            "P31",   "P279",  "P17",   "P131",  "P21",   "P27",
            "P106",  "P105",  "P734",  "P735",  "P1412", "P364",
            "P495",  "P361",  "P910",  "P1343", "P373",  "P5008",
            "P2670", "P1204", "P1424", "P301",  "P1753", "P1754",
            "P360",  "P3148", "P973",  "P460",  "P1889", "P1151",
            "P527",  "P18",   "P1464",
        }

        # ── 过滤无意义实体 ──────────────────────────────────────────
        self.excluded_entities = {
            "Q5",        "Q6256",     "Q43229",    "Q3624078",
            "Q16521",    "Q34770",    "Q30",       "Q2",
            "Q145",      "Q142",      "Q183",      "Q17",
            "Q1860",     "Q150",      "Q188",      "Q6581097",
            "Q6581072",  "Q46",       "Q159583",   "Q14204246",
            "Q13406463", "Q4167410",  "Q4167836",  "Q11266439",
            "Q52875056",
        }

    # ── 公开接口：一步完成搜索 + 游走 ──────────────────────────────
    def search_and_walk(self, entity_name: str, hops: int = None):
        """
        根据实体名搜索 Wikidata 并进行随机游走。
        返回 path（list）或 None（搜索/游走失败）。
        """
        hops = hops or config.HOPS
        entity_id = self.search_entity(entity_name)
        if not entity_id:
            return None
        return self.random_walk(entity_id, hops=hops)

    # ── 搜索实体 ────────────────────────────────────────────────────
    def search_entity(self, query: str):
        """通过搜索词查找 Wikidata 实体 ID，返回第一个匹配结果的 ID。"""
        print(f"[*] 正在搜索实体: '{query}'...")
        params = {
            "action": "wbsearchentities",
            "search": query,
            "language": "zh",
            "fallbacklanguage": "en",
            "format": "json",
            "limit": 1,
        }
        try:
            resp = self.session.get(
                self.api_url, params=params,
                headers=self.headers, timeout=self.timeout,
            )
            resp.raise_for_status()
            results = resp.json().get("search", [])
            if results:
                entity_id = results[0]["id"]
                label     = results[0].get("label", query)
                print(f"[*] 搜索 '{query}' -> 找到实体: {label} ({entity_id})")
                return entity_id
            print(f"[!] 搜索 '{query}' 未找到任何匹配实体。")
            return None
        except Exception as e:
            print(f"[!] 搜索 '{query}' 时出错: {type(e).__name__}: {e}")
            return None

    # ── 获取实体数据（带缓存 + 限流重试）──────────────────────────
    def get_entity_data(self, entity_id: str):
        if entity_id in self._cache:
            return self._cache[entity_id]

        params = {
            "action": "wbgetentities",
            "ids": entity_id,
            "format": "json",
            "languages": "zh|en",
        }
        max_attempts = 4
        for attempt in range(1, max_attempts + 1):
            try:
                resp = self.session.get(
                    self.api_url, params=params,
                    headers=self.headers, timeout=self.timeout,
                )
                if resp.status_code in (403, 429):
                    wait = 5 * attempt
                    print(f"[!] 请求 {entity_id} 被限流 (HTTP {resp.status_code})，"
                          f"第{attempt}/{max_attempts}次，等待 {wait}s...")
                    time.sleep(wait)
                    continue
                resp.raise_for_status()
                data = resp.json()
                if "-1" in data.get("entities", {}):
                    self._cache[entity_id] = None
                    return None
                result = data["entities"][entity_id]
                self._cache[entity_id] = result
                return result
            except requests.exceptions.HTTPError:
                wait = 5 * attempt
                print(f"请求 {entity_id} HTTP异常 (第{attempt}/{max_attempts}次)，等待 {wait}s...")
                time.sleep(wait)
            except Exception as e:
                wait = 5 * attempt
                print(f"请求 {entity_id} 数据异常 (第{attempt}/{max_attempts}次): {e}")
                if attempt < max_attempts:
                    print(f"[*] 等待 {wait}s 后重试...")
                    time.sleep(wait)
        print(f"[!] 请求 {entity_id} 最终失败，已耗尽所有重试次数。")
        return None

    def get_label(self, entity_id: str) -> str:
        data = self.get_entity_data(entity_id)
        if not data:
            return entity_id
        labels = data.get("labels", {})
        return (labels.get("zh", {}).get("value") or
                labels.get("en", {}).get("value") or
                entity_id)

    # ── Wikipedia 全文描述 ──────────────────────────────────────────
    def _fetch_wikipedia_fulltext(self, title: str, lang: str):
        """调用 Wikipedia action=query API 获取页面纯文本全文。"""
        api_url = f"https://{lang}.wikipedia.org/w/api.php"
        params  = {
            "action": "query",
            "titles": title,
            "prop": "extracts",
            "explaintext": True,
            "exsectionformat": "plain",
            "format": "json",
        }
        resp = self.session.get(api_url, params=params,
                                headers=self.headers, timeout=self.timeout)
        if resp.status_code != 200:
            return None
        pages = resp.json().get("query", {}).get("pages", {})
        for page in pages.values():
            if page.get("missing") is not None:
                return None
            text = page.get("extract", "").strip()
            if text and len(text) >= config.WIKI_MIN_CHARS:
                return text[:config.WIKI_MAX_CHARS]
        return None

    def build_rich_desc(self, entity_id: str) -> str:
        """优先中文 Wikipedia 全文，其次英文，最后回退 Wikidata 一句话描述。"""
        data = self.get_entity_data(entity_id)
        if not data:
            return "No description"

        sitelinks = data.get("sitelinks", {})
        for lang, sitekey in [("zh", "zhwiki"), ("en", "enwiki")]:
            if sitekey not in sitelinks:
                continue
            title = sitelinks[sitekey].get("title")
            if not title:
                continue
            try:
                text = self._fetch_wikipedia_fulltext(title, lang)
                if text:
                    print(f"[*] {entity_id} {lang.upper()} Wikipedia 全文 ({len(text)} 字符)")
                    return text
            except Exception as e:
                print(f"[!] 获取 {entity_id} {lang.upper()} Wikipedia 失败: {e}")

        print(f"[!] {entity_id} 无 Wikipedia 页面，使用 Wikidata 描述兜底")
        return (
            data.get("descriptions", {}).get("zh", {}).get("value") or
            data.get("descriptions", {}).get("en", {}).get("value") or
            "No description"
        )

    # ── 随机游走 ────────────────────────────────────────────────────
    def random_walk(self, start_entity_id: str, hops: int = None):
        """
        从 start_entity_id 出发进行 hops 跳随机游走。
        返回 path（list）或 None（遇到无效节点）。
        """
        hops = hops or config.HOPS
        print(f"[*] 开始 {hops} 跳随机游走，起点: {start_entity_id}")
        current_entity = start_entity_id
        path = []

        blacklist_keywords = [
            "Wikipedia:", "Category:", "Template:", "Portal:",
            "List of", "列表", "基礎條目", "Wikimedia",
        ]

        for i in range(hops):
            data = self.get_entity_data(current_entity)
            if not data:
                break

            label = self.get_label(current_entity)
            base_desc = (
                data.get("descriptions", {}).get("en", {}).get("value") or
                data.get("descriptions", {}).get("zh", {}).get("value") or ""
            )

            if any(kw.lower() in label.lower() or kw.lower() in base_desc.lower()
                   for kw in blacklist_keywords):
                print(f"[!] 动态拦截：无效节点 '{label}'，丢弃路径。")
                return None

            desc  = self.build_rich_desc(current_entity)
            claims = data.get("claims", {})
            valid_edges = []

            for prop_id, claim_list in claims.items():
                if prop_id in self.excluded_props:
                    continue
                for claim in claim_list:
                    mainsnak = claim.get("mainsnak", {})
                    if mainsnak.get("datatype") == "wikibase-item":
                        target_id = mainsnak.get("datavalue", {}).get("value", {}).get("id")
                        if target_id and target_id not in self.excluded_entities:
                            valid_edges.append((prop_id, target_id))

            if not valid_edges:
                print(f"[!] 第 {i+1} 跳无有效边，提前停止游走")
                break

            prop_id, next_entity = random.choice(valid_edges)
            prop_label = self.get_label(prop_id)

            path.append({
                "entity_label": label,
                "entity_desc":  desc,
                "relation":     prop_label,
                "target_id":    next_entity,
            })

            current_entity = next_entity
            time.sleep(config.HOP_SLEEP_SECONDS)

        final_label = self.get_label(current_entity)
        path.append({"entity_label": final_label, "is_answer": True})
        return path


# ─────────────────────────────────────────────────────────────────────
# QASynthesizer
# ─────────────────────────────────────────────────────────────────────

class QASynthesizer:
    def __init__(
        self,
        api_key:  str = None,
        base_url: str = None,
        model:    str = None,
    ):
        self.api_key  = api_key  or config.API_KEY
        self.base_url = base_url or config.BASE_URL
        self.model    = model    or config.MODEL

    def _call_llm(self, prompt: str, image_url: str = None) -> dict:
        """
        调用 LLM（antchat 接口），失败自动重试最多 2 次（指数退避）。
        若提供 image_url，本机下载图片转 base64 后以 vision 格式发送；
        否则使用纯文本格式。
        （antchat 服务器无法访问 OSS 内网地址，必须由本机下载后转 base64）
        """
        url = f"{self.base_url}/chat/completions"

        if image_url:
            import base64
            print(f"[*] 下载图片转 base64: {image_url[:80]}...")
            # 图片下载：失败最多重试 3 次
            img_content = None
            mime = "image/jpeg"
            for dl_try in range(1, 5):
                try:
                    img_resp = requests.get(
                        image_url,
                        headers={"User-Agent": "Mozilla/5.0"},
                        timeout=20,
                    )
                    img_resp.raise_for_status()
                    img_content = img_resp.content
                    mime = img_resp.headers.get("Content-Type", "image/jpeg").split(";")[0].strip()
                    break
                except Exception as e:
                    if dl_try < 4:
                        wait = dl_try * 5
                        print(f"[!] 图片下载失败（第 {dl_try}/3 次重试），等待 {wait}s: {e}")
                        time.sleep(wait)
                    else:
                        raise RuntimeError(f"图片下载失败（已重试 3 次）: {e}") from e
            b64_str  = base64.b64encode(img_content).decode("utf-8")
            data_uri = f"data:{mime};base64,{b64_str}"
            # antchat vision 格式：image_url 字段直接是字符串（data URI）
            content = [
                {"type": "image_url", "image_url": data_uri},
                {"type": "text",      "text": prompt},
            ]
        else:
            content = prompt

        payload = json.dumps({
            "model":       self.model,
            "temperature": config.TEMPERATURE,
            "messages":    [{"role": "user", "content": content}],
            "stream":      False,
        })
        headers = {
            "Authorization": (self.api_key
                              if self.api_key.startswith("Bearer ")
                              else f"Bearer {self.api_key}"),
            "Content-Type": "application/json",
        }
        # SOFA 链路追踪 Header（配置了才加）
        if config.SOFA_TRACE_ID:
            headers["SOFA-TraceId"] = config.SOFA_TRACE_ID
        if config.SOFA_RPC_ID:
            headers["SOFA-RpcId"] = config.SOFA_RPC_ID

        # LLM 请求：失败最多重试 3 次（指数退避）
        llm_max_retries = 3
        last_exc = None
        for llm_try in range(1, llm_max_retries + 2):
            try:
                resp = requests.post(url, headers=headers, data=payload, timeout=120)
                resp.raise_for_status()
                content_str = resp.json()["choices"][0]["message"]["content"]
                json_match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", content_str, re.DOTALL)
                if json_match:
                    return json.loads(json_match.group(1))
                return json.loads(content_str)
            except Exception as e:
                last_exc = e
                if llm_try <= llm_max_retries:
                    wait = 2 ** llm_try  # 2s, 4s, 8s
                    print(f"[!] LLM 请求失败（第 {llm_try}/{llm_max_retries} 次重试），等待 {wait}s: {type(e).__name__}: {e}")
                    time.sleep(wait)
        raise last_exc

    def synthesize(
        self,
        graph_path:  list,
        person_name: str = None,
        image_url:   str = None,
    ) -> dict | None:
        """
        根据图游走路径合成多跳 QA。

        参数：
            graph_path  : random_walk 返回的路径列表（必填）
            person_name : 图片中的人物名称；提供时使用多模态 prompt
            image_url   : 图片 URL；与 person_name 配合使用

        返回 dict 或 None（路径太短 / LLM 调用失败）。
        """
        if not graph_path or len(graph_path) < 2:
            print("[!] 路径太短，无法合成多跳问题。")
            return None

        path_str = ""
        for i in range(len(graph_path) - 1):
            step      = graph_path[i]
            next_step = graph_path[i + 1]
            path_str += (
                f"Step {i+1}: 实体 '{step['entity_label']}' "
                f"(描述: {step['entity_desc']}) "
                f"--[{step['relation']}]--> "
                f"实体 '{next_step['entity_label']}'\n"
            )

        target = graph_path[-1]["entity_label"]
        # 打印时每个 step 的描述只截取前 100 字符，避免刷屏
        path_str_preview = ""
        for i in range(len(graph_path) - 1):
            step      = graph_path[i]
            next_step = graph_path[i + 1]
            desc_preview = step['entity_desc'][:100].replace('\n', ' ')
            path_str_preview += (
                f"Step {i+1}: '{step['entity_label']}' "
                f"(描述: {desc_preview}...) "
                f"--[{step['relation']}]--> "
                f"'{next_step['entity_label']}'\n"
            )
        print(f"[*] 推理路径:\n{path_str_preview}")

        # ── 根据是否有图片选择 prompt ──────────────────────────────
        if person_name and image_url:
            prompt = f"""你是一个高级的多模态 AI 数据合成专家。你的任务是综合【图片人物信息】
和【真实事实路径】，构造一个以"看图识人"为第一跳的高质量多模态多跳问题。

────────────────────────────────────────
【输入信息】
────────────────────────────────────────
【图片】: （见附件图片）
【图片中的人物】: {person_name}（此为多跳推理的起点，问题中禁止直接出现此名字）
【真实事实路径】: 
{path_str}
【最终答案】: 
{target}

────────────────────────────────────────
【问题结构说明】
────────────────────────────────────────
你要生成的问题结构固定为：

  第一跳（视觉跳）: 答题者看图 → 认出图中人物是 {person_name}
  第二跳起（知识跳）: 以 {person_name} 为起点 → 沿事实路径逐步推理
  终点: 推导出【最终答案】 {target}

问题本身只呈现给答题者图片，不说出人名。
答题者必须先认出图中的人，才能开始后续推理。

────────────────────────────────────────
【你需要先完成的图片分析】
────────────────────────────────────────
请先观察图片，提取可用于自然描述的视觉细节，例如：
- 人物的外貌特征（发型、着装、神态等）
- 所处场景或背景（颁奖台、赛场、采访间等）
- 图中是否有辅助性文字、标志、道具等

这些细节可以用来在问题中自然地描述"图中这个人"，
但注意：描述只是辅助引导，不能精确到直接暗示出人名。

────────────────────────────────────────
【具体规则】
────────────────────────────────────────

1. 【人名保护：绝对禁止在问题中出现 {person_name}】
   - 用"图中这位……的人"、"照片里的他/她"等方式自然指代
   - 可以借助图片的场景细节辅助描述，但不能精确到让人不看图就能猜出
   - ✓ "图中这位身着正装、站在领奖台上的人"
   - ✗ "图中这位曾出演《XXX》的演员"（暗示过强，等于说出了名字）

2. 【图片是必要条件】
   - 生成的问题必须让图片成为不可缺少的解题要素
   - 即：如果没有图片，答题者无法完成第一跳，问题就无法作答
   - 检验方式：把问题中的图片相关描述去掉，看是否还能推出答案
     如果去掉后仍能推出，说明图片是多余的，需要重新设计

3. 【时间与细节的模糊化】
   - 尽量用自然模糊的表达替代精确信息：
     * 精确年份 → "大概十年前"、"上世纪末"、"那个年代"
     * 精确排名/数字 → "当时最受瞩目的之一"、"连续好几年"
   - 前提：模糊后组合语境仍然唯一指向正确答案

4. 【自然表达】
   - 像真人好奇地提问，而非出考题
   - 可以用分句、场景设定让问题读起来流畅自然
   - ✓ "照片里这个人，我记得他好像在某个领域很有建树，
         请问他的……最终……是什么？"
   - ✗ "图中满足A、B、C条件的人物的X的Y的Z是什么？"

5. 【唯一性保证】
   - 图片视觉 + 问题文字的组合，必须唯一指向 {target}
   - 每一跳只能有一个候选答案

6. 【禁止事项】
   - ❌ 问题中直接出现 {person_name}
   - ❌ 图片描述精确到等价于说出人名
   - ❌ 问题脱离图片也能作答（图片沦为装饰）
   - ❌ 单句堆砌超过2个精确限定条件
   - ❌ 生硬的"A的B的C的D"结构

────────────────────────────────────────
【输出格式】严格输出以下 JSON：
────────────────────────────────────────
{{
    "image_analysis": {{
        "visual_clues": "图片中可用于自然描述的视觉细节",
        "description_strategy": "打算如何在问题中自然地指代图中人物，且不暴露人名"
    }},
    "reasoning_and_uniqueness_check": {{
        "hop_analysis": "逐跳说明推导过程及唯一性（第一跳=看图认出{person_name}，后续跳=知识推理）",
        "obfuscation_notes": "哪些信息做了模糊化处理，为何模糊后仍不歧义",
        "naturalness_notes": "如何让问题读起来自然"
    }},
    "complex_question": "合成的多模态多跳问题（必须结合图片才能作答）",
    "answer": "{target}"(如果答案是繁体字请转成中文简体)
}}
"""
        else:
            # 无图片：使用原始纯文本 prompt
            prompt = f"""你是一个高级的 AI 数据合成专家。你的任务是根据提供的【真实事实路径】，逆向构造一个高质量、需要深度搜索（Deep Search）和多跳推理（Multi-hop Reasoning）才能回答的复杂问题。

【真实事实路径】:
{path_str}
【最终答案】: 
{target}

【避免"一对多"问题】
你合成的问题必须具有【唯一解】。根据你提供的问题线索进行推导时，每一步都必须只能指向唯一的确切实体，最终精准推导出【最终答案】，绝不能因为线索过于宽泛而推导出其他无关的正确答案。

【任务与严格规则】:
1. 实体掩码与唯一性约束 (Obfuscation & Uniqueness): 
   - 不要直接提及路径中间的实体名称。必须使用它们的特征、成就或关系来掩码（Mask）它们。
   - ⚠️ 关键约束：掩码描述必须是【全局唯一】且【可搜索】的。不要使用"一部科幻电影"、"一个欧洲国家"这种宽泛描述；必须使用交叉条件，如"2014年获得奥斯卡最佳视觉效果奖的科幻电影"、"1992年举办过夏季奥运会的欧洲国家"，确保每一步推导的候选结果只有一个。
2. 自然连贯 (Naturalness): 问题必须符合人类的自然提问习惯，语言为流畅的中文，避免生硬的定语堆砌（如"A的B的C是谁"），可以通过设定特定场景或分句来提问。
3. 逻辑验证 (Verification): 在生成问题前，你必须模拟搜索过程，验证是否可能得出与【最终答案】不同的结果。

【输出格式】必须严格为以下 JSON 结构：
{{
    "reasoning_and_uniqueness_check": "简述你如何设计线索，并证明为什么根据你的问题，推导过程是唯一的，不会产生'一对多'的歧义。",
    "complex_question": "合成的高质量多跳问题",
    "answer": "最终答案"
}}
"""

        print("[*] 正在调用 LLM 合成问题...")
        try:
            return self._call_llm(prompt, image_url=image_url)
        except Exception as e:
            print(f"[!] LLM 调用失败: {e}")
            return None
