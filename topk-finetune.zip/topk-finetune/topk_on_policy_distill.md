# Top-K On-Policy Distillation

## 1. 动机

标准 On-Policy Distillation 在每个时间步仅采样**一个** token，然后计算该 token 上教师与学生的 KL 散度。这存在以下问题：

1. **信息利用不充分**：每个位置只看到一个 token 的教师反馈，忽略了教师在其他高概率 token 上的分布信息
2. **方差大**：单 token 采样导致梯度估计的方差较高，训练不稳定
3. **分布匹配粗糙**：仅在采样到的 token 上对齐概率，无法捕捉教师分布的局部结构（如 top 候选之间的相对排序）

**核心改进思路**：在每个位置采样 Top-K 个 token，在这 K 个 token 构成的子空间上计算 KL 散度，并以学生的生成概率作为权重进行 loss 聚合。

## 2. 符号定义

| 符号 | 含义 |
|------|------|
| $x$ | 输入 prompt |
| $y_{<t}$ | 前 $t-1$ 个已生成的 token（前缀） |
| $\pi_S(\cdot \| y_{<t}, x)$ | 学生模型在位置 $t$ 的完整词表分布 |
| $\pi_T(\cdot \| y_{<t}, x)$ | 教师模型在位置 $t$ 的完整词表分布 |
| $\mathcal{V}$ | 完整词表 |
| $K$ | 每个位置采样的 token 数量 |
| $\mathcal{T}_t^K$ | 位置 $t$ 上学生模型概率最高的 $K$ 个 token 集合 |
| $T$ | 序列总长度 |

## 3. 方法详述

### 3.1 Top-K 采样

在每个位置 $t$，从学生模型的分布中选取概率最高的 $K$ 个 token：

$$
\mathcal{T}_t^K = \underset{S \subseteq \mathcal{V},\, |S|=K}{\arg\max} \sum_{v \in S} \pi_S(v | y_{<t}, x)
$$

即：

$$
\mathcal{T}_t^K = \{ v_1, v_2, \ldots, v_K \} \quad \text{where} \quad \pi_S(v_1 | y_{<t}, x) \geq \pi_S(v_2 | y_{<t}, x) \geq \cdots \geq \pi_S(v_K | y_{<t}, x)
$$

### 3.2 Top-K 子空间上的归一化分布

在 Top-K 集合 $\mathcal{T}_t^K$ 上，分别对学生和教师的分布进行**重新归一化**：

**学生归一化分布**：

$$
\hat{\pi}_S(v | y_{<t}, x) = \frac{\pi_S(v | y_{<t}, x)}{\sum_{v' \in \mathcal{T}_t^K} \pi_S(v' | y_{<t}, x)}, \quad v \in \mathcal{T}_t^K
$$

**教师归一化分布**：

$$
\hat{\pi}_T(v | y_{<t}, x) = \frac{\pi_T(v | y_{<t}, x)}{\sum_{v' \in \mathcal{T}_t^K} \pi_T(v' | y_{<t}, x)}, \quad v \in \mathcal{T}_t^K
$$

> **注意**：归一化确保在 Top-K 子空间上 $\hat{\pi}_S$ 和 $\hat{\pi}_T$ 都是合法的概率分布，使得 KL 散度有意义。

### 3.3 Top-K KL 散度

在每个位置 $t$，计算 Top-K 子空间上的 KL 散度（Reverse KL）：

$$
D_{\mathrm{KL}}^{(t, K)} = D_{\mathrm{KL}}\!\left(\hat{\pi}_S(\cdot | y_{<t}, x) \;\|\; \hat{\pi}_T(\cdot | y_{<t}, x)\right) = \sum_{v \in \mathcal{T}_t^K} \hat{\pi}_S(v | y_{<t}, x) \log \frac{\hat{\pi}_S(v | y_{<t}, x)}{\hat{\pi}_T(v | y_{<t}, x)}
$$

也可以选择 Forward KL：

$$
D_{\mathrm{KL}}^{(t, K, \text{fwd})} = \sum_{v \in \mathcal{T}_t^K} \hat{\pi}_T(v | y_{<t}, x) \log \frac{\hat{\pi}_T(v | y_{<t}, x)}{\hat{\pi}_S(v | y_{<t}, x)}
$$

### 3.4 概率加权的 Loss 聚合

关键创新：**不同位置的 KL 散度按该位置实际生成 token 的学生概率进行加权**。

设在 on-policy 采样中，位置 $t$ 实际生成的 token 为 $y_t$（从学生模型自回归采样得到），则该位置的权重为：

$$
w_t = \pi_S(y_t | y_{<t}, x)
$$

**直觉**：
- 学生对某个位置越"自信"（$w_t$ 越大），该位置的蒸馏信号权重越高——因为这些位置是学生在推理时最可能走到的路径，对齐这些位置的分布更重要
- 学生不确定的位置（$w_t$ 较小），权重较低——这些位置的 Top-K 分布可能噪声较大，降低权重有助于稳定训练

权重归一化（可选）：

$$
\bar{w}_t = \frac{w_t}{\sum_{t'=1}^{T} w_{t'}}
$$

### 3.5 最终损失函数

**加权形式**：

$$
\boxed{
\mathcal{L}_{\text{TopK-Distill}} = \sum_{t=1}^{T} w_t \cdot D_{\mathrm{KL}}^{(t, K)} = \sum_{t=1}^{T} \pi_S(y_t | y_{<t}, x) \cdot \sum_{v \in \mathcal{T}_t^K} \hat{\pi}_S(v | y_{<t}, x) \log \frac{\hat{\pi}_S(v | y_{<t}, x)}{\hat{\pi}_T(v | y_{<t}, x)}
}
$$

**归一化加权形式**（可选，使 loss 尺度与序列长度无关）：

$$
\mathcal{L}_{\text{TopK-Distill}}^{\text{norm}} = \sum_{t=1}^{T} \bar{w}_t \cdot D_{\mathrm{KL}}^{(t, K)}
$$

### 3.6 完整展开

将所有定义代入，完整的损失函数为：

$$
\mathcal{L} = \sum_{t=1}^{T} \pi_S(y_t | y_{<t}, x) \cdot \sum_{v \in \mathcal{T}_t^K} \frac{\pi_S(v | y_{<t}, x)}{Z_S^{(t)}} \left[ \log \frac{\pi_S(v | y_{<t}, x)}{Z_S^{(t)}} - \log \frac{\pi_T(v | y_{<t}, x)}{Z_T^{(t)}} \right]
$$

其中归一化常数：

$$
Z_S^{(t)} = \sum_{v' \in \mathcal{T}_t^K} \pi_S(v' | y_{<t}, x), \quad Z_T^{(t)} = \sum_{v' \in \mathcal{T}_t^K} \pi_T(v' | y_{<t}, x)
$$

## 4. 梯度分析

对学生参数 $\theta$ 求梯度，$\mathcal{L}$ 中有两处依赖 $\theta$：

1. **权重 $w_t = \pi_S(y_t | y_{<t}, x)$** 依赖 $\theta$
2. **Top-K KL 散度 $D_{\mathrm{KL}}^{(t,K)}$** 中的 $\hat{\pi}_S$ 依赖 $\theta$

梯度为：

$$
\nabla_\theta \mathcal{L} = \sum_{t=1}^{T} \left[ \nabla_\theta w_t \cdot D_{\mathrm{KL}}^{(t,K)} + w_t \cdot \nabla_\theta D_{\mathrm{KL}}^{(t,K)} \right]
$$

其中第二项（KL 散度对 $\theta$ 的梯度）是主要的学习信号：

$$
\nabla_\theta D_{\mathrm{KL}}^{(t,K)} = \sum_{v \in \mathcal{T}_t^K} \nabla_\theta \hat{\pi}_S(v) \cdot \left(1 + \log \frac{\hat{\pi}_S(v)}{\hat{\pi}_T(v)} \right)
$$

> **实践建议**：可以对 $w_t$ 做 stop-gradient（即 `w_t.detach()`），只通过 KL 散度项传梯度，简化训练并提高稳定性。

## 5. 算法流程

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Algorithm: Top-K On-Policy Distillation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

输入:
  - 教师模型 π_T（参数冻结）
  - 学生模型 π_S（参数 θ，待优化）
  - 数据集 D = {x_1, x_2, ...}
  - Top-K 参数 K
  - 学习率 η

For each iteration:

  ┌─ Step 1: 采样 Prompt ─────────────────────────────────────┐
  │  从 D 中采样一批 prompt: {x_i}_{i=1}^B                     │
  └───────────────────────────────────────────────────────────┘

  ┌─ Step 2: On-Policy 序列生成 ──────────────────────────────┐
  │  For each x_i:                                            │
  │    用学生模型 π_S 自回归生成序列:                             │
  │    y = (y_1, y_2, ..., y_T),  y_t ~ π_S(·|y_{<t}, x_i)  │
  └───────────────────────────────────────────────────────────┘

  ┌─ Step 3: 计算 Top-K 集合 ─────────────────────────────────┐
  │  For each position t = 1, ..., T:                         │
  │    logits_S = π_S(·|y_{<t}, x)     # 学生完整词表 logits   │
  │    T_t^K = TopK(logits_S, K)       # 取概率最高的 K 个 token│
  └───────────────────────────────────────────────────────────┘

  ┌─ Step 4: 教师模型推理 ────────────────────────────────────┐
  │  For each position t = 1, ..., T:                         │
  │    logits_T = π_T(·|y_{<t}, x)     # 教师完整词表 logits   │
  │    提取教师在 T_t^K 上的概率                                │
  └───────────────────────────────────────────────────────────┘

  ┌─ Step 5: 归一化 ──────────────────────────────────────────┐
  │  For each position t:                                     │
  │    π̂_S(v) = π_S(v) / Σ_{v'∈T_t^K} π_S(v'),  v ∈ T_t^K  │
  │    π̂_T(v) = π_T(v) / Σ_{v'∈T_t^K} π_T(v'),  v ∈ T_t^K  │
  └───────────────────────────────────────────────────────────┘

  ┌─ Step 6: 计算 Top-K KL 散度 ──────────────────────────────┐
  │  For each position t:                                     │
  │    KL_t = Σ_{v∈T_t^K} π̂_S(v) · log(π̂_S(v) / π̂_T(v))   │
  └───────────────────────────────────────────────────────────┘

  ┌─ Step 7: 概率加权聚合 ────────────────────────────────────┐
  │  For each position t:                                     │
  │    w_t = π_S(y_t | y_{<t}, x)      # 实际生成 token 的概率 │
  │                                                           │
  │  L = Σ_t  w_t · KL_t               # 加权求和             │
  │  (可选: w_t 做 stop-gradient)                              │
  └───────────────────────────────────────────────────────────┘

  ┌─ Step 8: 参数更新 ────────────────────────────────────────┐
  │  θ ← θ - η · ∇_θ L                                       │
  └───────────────────────────────────────────────────────────┘

Return: 训练好的学生模型 π_S
```

## 6. 伪代码实现

```python
def topk_on_policy_distill_step(student, teacher, prompts, K, optimizer):
    """单步 Top-K On-Policy Distillation"""

    total_loss = 0

    for x in prompts:
        # Step 1: On-Policy 生成（学生自回归采样）
        y, student_logits_seq = student.generate(x, return_logits=True)
        # y: (T,)  student_logits_seq: (T, |V|)

        # Step 2: 教师前向推理（无需生成，只需对学生序列打分）
        with torch.no_grad():
            teacher_logits_seq = teacher.forward(x, y)
            # teacher_logits_seq: (T, |V|)

        loss = 0
        for t in range(len(y)):
            # Step 3: 学生分布
            student_probs = F.softmax(student_logits_seq[t], dim=-1)  # (|V|,)
            teacher_probs = F.softmax(teacher_logits_seq[t], dim=-1)  # (|V|,)

            # Step 4: 取学生 Top-K
            topk_probs_s, topk_indices = torch.topk(student_probs, K)  # (K,)

            # Step 5: 提取教师在 Top-K 上的概率
            topk_probs_t = teacher_probs[topk_indices]  # (K,)

            # Step 6: 在 Top-K 子空间上归一化
            topk_probs_s_norm = topk_probs_s / topk_probs_s.sum()
            topk_probs_t_norm = topk_probs_t / topk_probs_t.sum()

            # Step 7: 计算 Top-K Reverse KL
            kl_t = (topk_probs_s_norm * (topk_probs_s_norm.log() - topk_probs_t_norm.log())).sum()

            # Step 8: 概率加权
            w_t = student_probs[y[t]].detach()  # stop-gradient on weight
            loss += w_t * kl_t

        total_loss += loss

    # Step 9: 反向传播
    optimizer.zero_grad()
    total_loss.backward()
    optimizer.step()

    return total_loss.item()
```

## 7. 理论分析

### 7.1 与标准 On-Policy Distillation 的关系

当 $K = |\mathcal{V}|$（即 K 等于词表大小）时：

$$
\mathcal{T}_t^K = \mathcal{V}, \quad \hat{\pi}_S = \pi_S, \quad \hat{\pi}_T = \pi_T
$$

此时 Top-K KL 退化为标准的全词表 KL 散度，加权后等价于：

$$
\mathcal{L}_{\text{TopK}} \xrightarrow{K=|\mathcal{V}|} \sum_t \pi_S(y_t) \cdot D_{\mathrm{KL}}(\pi_S \| \pi_T)
$$

当 $K = 1$ 时，Top-K 集合只包含概率最大的 token，KL 散度退化为 0（单点分布的 KL 为 0），此时 loss 无意义。因此 **$K$ 应至少为 2**。

### 7.2 Top-K 子空间近似的合理性

**信息集中性**：对于训练良好的语言模型，大部分概率质量集中在少数 token 上。设 Top-K 覆盖的概率质量为：

$$
\rho_S^{(t)} = \sum_{v \in \mathcal{T}_t^K} \pi_S(v | y_{<t}, x)
$$

通常当 $K \geq 10$ 时，$\rho_S^{(t)} > 0.9$，即 Top-K 已覆盖 90% 以上的概率质量。

**近似误差界**：Top-K 子空间上的 KL 散度与全词表 KL 散度之间的差异可以被约束：

$$
\left| D_{\mathrm{KL}}(\hat{\pi}_S \| \hat{\pi}_T) - D_{\mathrm{KL}}(\pi_S \| \pi_T) \right| \leq \mathcal{O}\!\left(\frac{1 - \rho_S^{(t)}}{\rho_S^{(t)}} \log |\mathcal{V}|\right)
$$

当 $\rho_S^{(t)} \to 1$ 时，近似误差趋于 0。

### 7.3 概率加权的效果

概率加权使得 loss 自适应地关注学生模型的"主路径"：

- **高概率位置**（$w_t$ 大）：学生在推理时大概率会走到这些位置，对齐这些位置的 Top-K 分布直接提升推理质量
- **低概率位置**（$w_t$ 小）：这些位置可能是探索性的采样，分布对齐的优先级较低

这种加权方式等价于在学生的 **trajectory probability** 下做重要性采样：

$$
\mathcal{L} = \mathbb{E}_{y \sim \pi_S} \left[ \sum_t \pi_S(y_t | y_{<t}, x) \cdot D_{\mathrm{KL}}^{(t,K)} \right] \approx \mathbb{E}_{y \sim \pi_S} \left[ \sum_t P(\text{position } t \text{ matters}) \cdot D_{\mathrm{KL}}^{(t,K)} \right]
$$

## 8. 超参数建议

| 超参数 | 建议范围 | 说明 |
|--------|---------|------|
| $K$ | 5 ~ 50 | 太小信息不足，太大计算开销增加且引入噪声 |
| 权重策略 | `stop-gradient` | 对 $w_t$ 做 detach，避免梯度通过权重回传 |
| KL 方向 | Reverse KL | 与 on-policy 采样天然匹配 |
| 归一化 | 可选 | 长序列建议使用归一化权重 $\bar{w}_t$ |
| 温度 $\tau$ | 1.0 ~ 2.0 | 可在 softmax 前对 logits 除以 $\tau$，平滑分布 |

## 9. 方法优势总结

| 维度 | 标准 On-Policy Distill | Top-K On-Policy Distill（本方法） |
|------|----------------------|--------------------------------|
| 每位置信息量 | 1 个 token | K 个 token |
| 分布匹配精度 | 点估计 | 局部分布匹配 |
| 梯度方差 | 较高 | 较低（多 token 平均） |
| 计算开销 | 基准 | 略增（Top-K 选取 + 教师 K 点查询） |
| 对教师排序信息的利用 | 无 | 保留 Top-K 内的相对排序 |
| 加权策略 | 均匀 | 按生成概率自适应加权 |
