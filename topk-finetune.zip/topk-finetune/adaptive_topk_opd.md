# Adaptive Top-K On-Policy Distillation：从固定 K 到状态自适应蒸馏

## 1. 问题起点：固定 Top-K 蒸馏的局限

固定 Top-K On-Policy Distillation 的核心做法是：在每个生成位置 $t$，取学生模型概率最高的 $K$ 个 token，在这个子空间上归一化后计算 KL 散度，再按生成概率做位置加权。

这个方法相比全词表 KL 有降噪声、促聚焦的好处，但**固定 $K$ 本身引入了一个不合理的假设**：所有位置、所有训练阶段、所有样本，都用同样大小的候选集。

这个假设在以下场景中明显不成立：

| 场景 | 位置特点 | 固定 K 的问题 |
|------|---------|-------------|
| 生成常见虚词（"的""了""是"） | 分布极尖峰，top-1 概率 > 0.9 | K=32 时，大量低概率 token 被纳入，它们在子空间归一化后占比不低，引入噪声 |
| 开放性选择题/续写 | 分布平坦，多个候选概率接近 | K=8 时，截断了可能很重要的候选，子空间 KL 偏差大 |
| 训练早期 vs 后期 | 早期学生高熵，后期逐渐锐化 | 同一个 K 在早期可能不够、在后期可能过多 |
| 简单 prompt vs 复杂 prompt | 不确定性分布不同 | 全局统一的 K 无法适配 prompt 级别的差异 |

> 核心矛盾：**固定 K 是一个静态的折中——它在所有位置上均匀地承担截断偏差与长尾噪声的代价，而不是根据当前状态的需要动态分配。**

---

## 2. 全词表蒸馏的深层问题分析

在提出自适应方案之前，有必要更仔细地分析全词表 KL 蒸馏为什么在实践中表现不佳，因为这些分析会直接影响自适应 K 的设计。

### 2.1 长尾区域的梯度行为

全词表 KL 散度为：

$$
D_{\mathrm{KL}}(\pi_S \| \pi_T) = \sum_{v \in \mathcal{V}} \pi_S(v) \log \frac{\pi_S(v)}{\pi_T(v)}
$$

对学生参数 $\theta$ 的梯度为：

$$
\nabla_\theta D_{\mathrm{KL}} = \sum_{v \in \mathcal{V}} \nabla_\theta \pi_S(v) \cdot \log \frac{\pi_S(v)}{\pi_T(v)} + \pi_S(v) \cdot \frac{\nabla_\theta \pi_S(v)}{\pi_S(v)}
$$

对于长尾 token $v$（$\pi_S(v) < \epsilon$），虽然 $\pi_S(v)$ 很小，但：

1. **$\log \frac{\pi_S(v)}{\pi_T(v)}$ 可能非常大**：当 $\pi_S(v)$ 与 $\pi_T(v)$ 差几个数量级时，log-ratio 可以达到 $|10| \sim |20|$
2. **梯度方向不稳定**：微小参数扰动可能导致某些长尾 token 的概率排序翻转，从而产生方向相反的梯度
3. **多个长尾 token 的梯度可能相互矛盾**：由于参数共享，对一个低概率 token 的梯度调整可能损害其他 token 的对齐

具体来说，设长尾 token 的集合为 $\mathcal{L} = \{v : \pi_S(v) < \epsilon\}$，则长尾部分的 KL 贡献为：

$$
D_{\mathrm{KL}}^{\text{tail}} = \sum_{v \in \mathcal{L}} \pi_S(v) \log \frac{\pi_S(v)}{\pi_T(v)}
$$

虽然 $\sum_{v \in \mathcal{L}} \pi_S(v)$ 很小，但这并不意味着 $D_{\mathrm{KL}}^{\text{tail}}$ 可以忽略。考虑一个简化的例子：

- 词表大小 $|\mathcal{V}| = 100000$
- Top-10 覆盖 95% 的概率质量
- 剩余 99990 个 token 平分 5% 的概率质量，每个约 $5 \times 10^{-7}$
- 若 $\pi_S(v)$ 与 $\pi_T(v)$ 在这些 token 上差 3 倍，则 $\log \frac{\pi_S}{\pi_T} \approx 1.1$
- $D_{\mathrm{KL}}^{\text{tail}} \approx 99990 \times 5 \times 10^{-7} \times 1.1 \approx 0.055$

而 Top-10 的 KL 可能也就 0.1~0.5 的量级。所以**长尾贡献的量级不可忽略，但它的信号质量很差**——这些 log-ratio 在训练中来回波动，本质上是对随机噪声的拟合。

### 2.2 全词表蒸馏的隐含假设

全词表 KL 要求学生在**整个词表空间**上和教师一致。这隐含了一个强假设：学生对所有 token 的概率估计都应该接近教师。但实际上：

1. **推理时绝大部分 token 不会被采样到**：通常只有 top-1 到 top-5 的 token 有实际影响
2. **关键差异在排序而非绝对概率**：如果学生把教师的 top-1 和 top-2 搞反了，即使概率绝对值接近，生成质量也差
3. **长尾概率的"准确"对齐对下游任务几乎无意义**：用户不会因为模型把某个罕见 token 的概率从 $10^{-6}$ 调到 $10^{-5}$ 而感受到任何区别

### 2.3 一个关键区分：校准 vs 决策

可以从功能角度把蒸馏目标拆分为两个子目标：

| 子目标 | 定义 | 关心的 token | 全词表 KL 是否合适 |
|--------|------|-------------|------------------|
| **决策对齐** | 让学生在关键候选上的排序和教师一致 | Top-K 高概率 token | 不必要，长尾稀释信号 |
| **整体校准** | 让学生的完整概率分布和教师一致 | 全词表 | 必须全词表 |

对于下游任务表现，**决策对齐**远比整体校准重要。Top-K 蒸馏本质上就是在做决策对齐，而自适应 Top-K 则是在不同状态下动态决定"多少个候选足以做决策对齐"。

---

## 3. 为什么 K 应该是位置-依赖的：一个更细致的分析

### 3.1 从信息论角度：不同位置的信息需求不同

在一个生成序列中，不同位置对蒸馏信息的"需求量"是不同的。我们可以用一个简单的模型来理解：

**确定性位置**（例如生成的语法结构词）：
- 学生分布近似 one-hot：$\pi_S(v^*) \approx 1$，其余 $\approx 0$
- 熵 $H \approx 0$
- 教师在该位置也很确定，$\pi_T(v^*) \approx 1$
- **需要的 K 很小**：top-2 或 top-3 即可覆盖全部有意义信息，更多 token 只是噪声

**中等不确定性位置**（例如有 3~5 个合理选项）：
- 学生分布有几个局部峰
- 熵 $H$ 中等
- **需要 K=10~20**：必须覆盖所有"合理候选"才能正确对齐排序

**高不确定性位置**（例如开放式续写、创造性生成）：
- 学生分布非常平坦，可能有几十个 token 概率相近
- 熵 $H$ 很高
- **需要 K=30~100+**：截断太早会丢失教师的重要偏好信息

### 3.2 从偏差-方差权衡角度

将 Top-K KL 看作全词表 KL 的估计量，其误差可分解为：

$$
\text{Error}(K_t) = \underbrace{\text{Bias}(K_t)}_{\text{截断偏差：K 太小导致遗漏信息}} + \underbrace{\text{Variance}(K_t)}_{\text{估计方差：K 太大导致噪声引入}}
$$

- **Bias(K_t)** 随 K_t 递减（K 越大越接近全词表，偏差越小）
- **Variance(K_t)** 随 K_t 递增（包含更多低概率 token，噪声更大）

关键洞察：**最优 K_t*（使 Error 最小）在不同位置是不同的**：

$$
K_t^* = \arg\min_{K} \left[ \text{Bias}(K) + \text{Variance}(K) \right]_{\text{at position } t}
$$

- 高确定性位置：Variance 主导，$K_t^*$ 应该小
- 高不确定性位置：Bias 主导，$K_t^*$ 应该大

固定 K 相当于用一个全局值近似所有位置的最优 K_t*，而 Adaptive K 试图逐位置逼近 K_t*。

### 3.3 从训练动态角度

训练过程中，学生的分布特性在变化：

```
训练初期：学生分布普遍平坦（高熵）→ 大部分位置需要较大 K
         ↓
训练中期：部分位置开始锐化，出现分化 → 需要 mix of K
         ↓
训练后期：大部分位置趋于确定 → 多数位置只需小 K，少数难位置仍需大 K
```

如果用固定 K：
- 初期 K 太小 → 截断偏差累积
- 后期 K 太大 → 噪声拖慢收敛

自适应 K 则天然与训练动态匹配。

---

## 4. Adaptive Top-K 的三种核心机制

### 4.1 基于熵的 Adaptive K

#### 4.1.1 基本定义

学生模型在位置 $t$ 的（归一化）熵：

$$
H_S(t) = -\sum_{v \in \mathcal{V}} \pi_S(v | y_{<t}, x) \log \pi_S(v | y_{<t}, x)
$$

$$
\hat{H}_S(t) = \frac{H_S(t)}{\log |\mathcal{V}|} \in [0, 1]
$$

映射到 $K_t$：

$$
K_t = \text{round}\left(K_{\min} + (K_{\max} - K_{\min}) \cdot \hat{H}_S(t)^\gamma\right)
$$

参数 $\gamma$ 控制曲线形状：

- $\gamma = 1$：线性映射
- $\gamma > 1$：低熵区更激进压小 K（推荐 $\gamma \in [1.2, 2.0]$）
- $\gamma < 1$：中高熵区更快放大 K

#### 4.1.2 熵驱动 K 的直觉验证

考虑两个极端情况：

**情况 A：尖峰分布**
- $\pi_S(v^*) = 0.95$，其余 128K 个 token 平分 0.05
- $H_S \approx -0.95 \log 0.95 - 0.05 \log(0.05/128000) \approx 0.62$ nats
- $\hat{H}_S \approx 0.62 / \log(128000) \approx 0.05$
- $\gamma = 1.5$ 时，$K_t \approx K_{\min} + 0.05^{1.5} \cdot (K_{\max} - K_{\min}) \approx K_{\min} + 0.011 \cdot \Delta K$
- 即几乎命中 $K_{\min}$，合理

**情况 B：均匀分布**
- 所有 token 概率约 $1/128000$
- $H_S = \log(128000) \approx 11.77$ nats，$\hat{H}_S = 1.0$
- $K_t = K_{\max}$，合理

**情况 C：3 个候选等概率**
- $\pi_S(v_1) = \pi_S(v_2) = \pi_S(v_3) = 1/3$
- $H_S = \log 3 \approx 1.1$ nats，$\hat{H}_S \approx 0.093$
- $\gamma=1.5$ 时 $K_t \approx K_{\min} + 0.093^{1.5} \cdot \Delta K \approx K_{\min} + 0.028 \cdot \Delta K$
- 这可能偏小了——3 个等概率候选显然需要 K ≥ 3

这说明**纯熵映射在"少量候选等概率"这种中间状态可能偏保守**。解决方案：
1. 调小 $\gamma$（如 0.8~1.0）
2. 或用更细粒度的信号（如累计质量阈值）

#### 4.1.3 熵的近似计算

精确计算熵需要遍历全词表。实际中可以用 Top-M 近似（$M \gg K_{\max}$）：

$$
H_S(t) \approx -\sum_{i=1}^{M} \pi_S(v_i) \log \pi_S(v_i) - \left(1 - \sum_{i=1}^{M} \pi_S(v_i)\right) \log \frac{1 - \sum_{i=1}^{M} \pi_S(v_i)}{|\mathcal{V}| - M}
$$

其中 $M = 2 \times K_{\max}$ 通常就够了，因为 Top-M 已覆盖绝大部分概率质量。

---

### 4.2 基于累计概率质量阈值的 Adaptive K

#### 4.2.1 基本定义

不直接映射 K，而是设定一个概率覆盖阈值 $\rho$，取最小 $K_t$ 使得：

$$
\sum_{i=1}^{K_t} \pi_S(v_i | y_{<t}, x) \geq \rho_t
$$

其中 $v_1, v_2, \ldots$ 是按学生概率降序排列的 token。

#### 4.2.2 阈值 $\rho_t$ 也可以自适应

$\rho_t$ 本身也可以随状态变化：

$$
\rho_t = \rho_{\min} + (\rho_{\max} - \rho_{\min}) \cdot (1 - \hat{H}_S(t))
$$

- 高熵位置 $\hat{H}_S(t) \to 1$：$\rho_t \to \rho_{\min}$（如 0.85），允许覆盖少一些但多看候选
- 低熵位置 $\hat{H}_S(t) \to 0$：$\rho_t \to \rho_{\max}$（如 0.99），高覆盖但 K 自然小

**直觉**：
- 低熵时，top-1 已占大部分质量，$\rho = 0.99$ 也不需要很多 token
- 高熵时，$\rho = 0.99$ 可能需要极多 token，所以调低阈值在"信息充分性"和"K 可控性"间折中

#### 4.2.3 累计质量法的优势与风险

| 维度 | 优势 | 风险 |
|------|------|------|
| 可解释性 | "覆盖 X% 的决策信息" | — |
| 跨词表可迁移 | 同样的 $\rho$ 在不同词表大小下语义一致 | — |
| 稳定性 | K 对单个 token 概率波动不敏感 | 极平分布时 K 可能暴涨 |
| 与熵法对比 | 更"目标导向" | 需要排序遍历，但有 topk 硬件加速 |

**防止 K 爆炸**：设置 $K_{\max}$ 硬截断，并在截断处做温度平滑（避免梯度不连续）。

---

### 4.3 基于教师-学生分歧的 Adaptive K

#### 4.3.1 动机

熵只反映学生的不确定性，但不反映学生与教师之间的差异。考虑以下情况：

- 学生在某位置低熵且确定，但**选错了 token**——此时教师-学生分歧大，即使 K 小也应包含教师的正确选项
- 学生在某位置高熵但与教师分布一致——此时 K 不需要太大

因此，**分歧是比熵更直接的信号**。

#### 4.3.2 分歧指标的选取

在 Top-M 候选集（$M$ 为预计算量，如 64）上估计分歧：

**方法 A：Top-M 上的 JS 散度**

$$
D_t^{\text{JS}} = \frac{1}{2} D_{\mathrm{KL}}(\pi_S^{\text{topM}} \| \pi_M) + \frac{1}{2} D_{\mathrm{KL}}(\pi_T^{\text{topM}} \| \pi_M)
$$

其中 $\pi_M = \frac{1}{2}(\hat{\pi}_S^{\text{topM}} + \hat{\pi}_T^{\text{topM}})$。

**方法 B：Top-1 一致性**

$$
\delta_t = \mathbb{1}[\arg\max_v \pi_S(v) \neq \arg\max_v \pi_T(v)]
$$

简单但只看 top-1，信息不够。

**方法 C：候选集差异度**

$$
\Delta_t = |\mathcal{T}_S^M \setminus \mathcal{T}_T^M| / M
$$

其中 $\mathcal{T}_S^M$ 和 $\mathcal{T}_T^M$ 分别是学生和教师的 Top-M 集合。反映两者的候选集重叠度。

#### 4.3.3 组合映射

将熵和分歧组合：

$$
K_t = \text{clip}\left(\alpha \cdot \hat{H}_S(t) + \beta \cdot D_t + K_{\min},\; K_{\min},\; K_{\max}\right)
$$

其中 $D_t$ 是归一化的分歧指标，$\alpha, \beta$ 是可调系数。

#### 4.3.4 分歧法的局限

- **需要教师先跑一遍 Top-M**：额外计算开销
- **分歧本身需要归一化**：不同位置、不同训练阶段的分歧分布可能变化
- **工程复杂度高**：建议作为第二阶段实验

---

### 4.4 三种机制的比较与推荐

| 维度 | 熵驱动 | 累计质量阈值 | 分歧驱动 |
|------|--------|------------|---------|
| 实现复杂度 | 低 | 低 | 中高 |
| 额外计算量 | 几乎为零（复用学生logits） | 需排序（硬件加速快） | 需教师前向 |
| 信号来源 | 学生自身不确定性 | 学生概率结构 | 学生与教师的差异 |
| 适用阶段 | 优先实现 | 优先实现 | 进阶优化 |
| 主要风险 | 中间状态偏保守 | 极平分布 K 爆炸 | 工程复杂 |
| 推荐顺序 | **第一选择** | **并列第一** | 第二阶段 |

---

## 5. 对 Top-K 子空间归一化的再审视

Adaptive K 带来了一个被固定 K 方法掩盖的问题：**不同位置使用不同 K 后，子空间归一化引入的偏差不再均匀。**

### 5.1 归一化偏差分析

对 Top-K 集合 $\mathcal{T}_t^{K_t}$ 的归一化：

$$
\hat{\pi}_S(v) = \frac{\pi_S(v)}{\sum_{v' \in \mathcal{T}_t^{K_t}} \pi_S(v')}, \quad \hat{\pi}_T(v) = \frac{\pi_T(v)}{\sum_{v' \in \mathcal{T}_t^{K_t}} \pi_T(v')}
$$

这个归一化把被截断的概率质量重新分配给子空间内的 token。问题在于：

**学生和教师被重新分配的质量不同**：
- 如果学生的 Top-K 覆盖了 $\rho_S = 0.95$ 的概率质量
- 教师在这同样的 Top-K 集合上可能只覆盖 $\rho_T = 0.80$（因为教师的 top-K 和学生的 top-K 不完全重叠）
- 归一化后，教师在 Top-K 上的分布会被"拉伸"更多，可能扭曲教师对 Top-K 内部排序的表达

### 5.2 一个简单修正：概率质量比加权

为了缓解上述偏差，可以在 KL 计算中引入概率质量比的修正：

$$
D_{\mathrm{KL}}^{\text{corr}}(t) = D_{\mathrm{KL}}(\hat{\pi}_S \| \hat{\pi}_T) + \lambda \cdot \left|\log \frac{\rho_S^{(t)}}{\rho_T^{(t)}}\right|
$$

其中 $\rho_S^{(t)}$ 和 $\rho_T^{(t)}$ 分别是学生和教师在 $\mathcal{T}_t^{K_t}$ 上的概率覆盖。

第二项是一个正则项，惩罚学生和教师在 Top-K 集合上覆盖差距过大的情况，间接促使学生的 Top-K 选择更贴近教师关心的区域。

### 5.3 另一个修正方案：残差概率的显式建模

不是简单截断，而是把长尾部分聚合成一个虚拟 token：

$$
\hat{\pi}_S^{\text{ext}}(v) = \begin{cases} \pi_S(v) & v \in \mathcal{T}_t^{K_t} \\ 1 - \rho_S^{(t)} & v = \texttt{[REST]} \end{cases}
$$

$$
\hat{\pi}_T^{\text{ext}}(v) = \begin{cases} \pi_T(v) & v \in \mathcal{T}_t^{K_t} \\ 1 - \rho_T^{(t)} & v = \texttt{[REST]} \end{cases}
$$

在这个 $K_t + 1$ 维的扩展空间上计算 KL：

$$
D_{\mathrm{KL}}^{\text{ext}}(t) = \sum_{v \in \mathcal{T}_t^{K_t}} \hat{\pi}_S^{\text{ext}}(v) \log \frac{\hat{\pi}_S^{\text{ext}}(v)}{\hat{\pi}_T^{\text{ext}}(v)} + (1 - \rho_S^{(t)}) \log \frac{1 - \rho_S^{(t)}}{1 - \rho_T^{(t)}}
$$

**优点**：
- 保留了长尾概率总量的差异信息（$1 - \rho_S$ vs $1 - \rho_T$）
- 不需要对学生/教师分别归一化——概率总和都是 1
- 不会因为归一化拉伸而扭曲内部排序

**缺点**：
- 多了一个虚拟 token 的 KL 项，当 $\rho_S$ 和 $\rho_T$ 差异大时，该项可能主导
- 需要仔细权衡

---

## 6. 位置权重 $\alpha_t$ 的自适应设计

在固定 Top-K OPD 中，位置权重为 $\alpha_t = \pi_S(y_t | y_{<t}, x)$。在自适应 K 下，我们可以重新思考这个权重。

### 6.1 原有权重的问题

$\alpha_t = \pi_S(y_t)$ 有以下隐含假设：
- 学生越自信的位置，蒸馏越重要
- 不确定的位置被自动降权

但在自适应 K 的语境下，这产生了矛盾：
- 高自信位置 → $K_t$ 小 → KL 值小 → 乘以高权重后仍然贡献有限
- 低自信位置 → $K_t$ 大 → KL 值大 → 乘以低权重后被压制

这意味着**真正需要关注的困难位置被双重压制了**（K 大但权重小）。

### 6.2 替代权重方案

**方案 A：逆熵权重**

$$
\alpha_t = 1 - \hat{H}_S(t)
$$

即越确定的位置权重越高。这与原方案思路一致，但直接用熵而非生成概率。

**方案 B：均匀权重**

$$
\alpha_t = 1
$$

最简单，让自适应 K 本身承担所有"注意力分配"的职责。

**方案 C：KL 幅度自适应权重**

$$
\alpha_t = \sigma\left(-\log D_{\mathrm{KL}}^{(t, K_t)}\right)
$$

KL 散度很大的位置说明对齐不足，应该得到更多关注。但这会导致 KL 越大权重越小... 方向矛盾。

修正为：

$$
\alpha_t = \text{stopgrad}\left(\sigma\left(\eta \cdot D_{\mathrm{KL}}^{(t, K_t)} - \mu\right)\right)
$$

其中 $\eta, \mu$ 是缩放参数。直觉：对 KL 较大的位置给予更多关注，但需要 stop-gradient 防止模型通过增大 KL 来获取更高权重。

**方案 D：混合权重（推荐）**

$$
\alpha_t = \lambda \cdot \pi_S(y_t | y_{<t}, x) + (1 - \lambda) \cdot \left(1 - \hat{H}_S(t)\right)^{\beta}
$$

- $\lambda = 1$：退化为原方案
- $\lambda = 0$：纯逆熵
- $\lambda = 0.5, \beta = 0.5$：折中

### 6.3 推荐

初步实验建议**先用均匀权重**（$\alpha_t = 1$），让自适应 K 自己发挥作用。如果发现困难位置学习不足，再引入权重调度。这样做的好处是：
1. 控制变量法——先验证 adaptive K 本身的价值
2. 避免权重和 K 的交互效应导致难以消融

---

## 7. 完整目标函数

### 7.1 主推荐版本（熵驱动 Adaptive K + 均匀权重）

$$
\mathcal{L}_{\text{Adaptive-TopK-OPD}} = \sum_{t=1}^{T} D_{\mathrm{KL}}\!\left(\hat{\pi}_S^{(K_t)} \| \hat{\pi}_T^{(K_t)}\right)
$$

其中：
- $K_t = \text{round}(K_{\min} + (K_{\max} - K_{\min}) \cdot \hat{H}_S(t)^\gamma)$，$K_t$ 做 stop-gradient
- $\hat{\pi}_S^{(K_t)}, \hat{\pi}_T^{(K_t)}$ 是在 $\mathcal{T}_t^{K_t} = \text{Top-}K_t(\pi_S)$ 上归一化的分布
- $\hat{H}_S(t)$ 从学生 logits 计算，做 stop-gradient

### 7.2 进阶版本（扩展虚拟 token + 概率加权）

$$
\mathcal{L} = \sum_{t=1}^{T} \alpha_t \cdot \left[ D_{\mathrm{KL}}^{\text{ext}}(t) + \lambda_{\text{reg}} \cdot \left|\log \frac{\rho_S^{(t)}}{\rho_T^{(t)}}\right| \right]
$$

其中：
- $K_t$ 由熵 + 分歧联合决定
- 使用扩展虚拟 token 的 KL（第 5.3 节）
- $\alpha_t$ 用混合权重（第 6.2 节方案 D）
- 正则项控制概率覆盖差异

### 7.3 与已有方法的关系

| $K_t$ 设置 | 方法 |
|-----------|------|
| $K_t = |\mathcal{V}|$ | 标准 OPD（全词表 KL） |
| $K_t = K_{\text{fixed}}$ | 固定 Top-K OPD |
| $K_t = f(\hat{H}_S(t))$ | **Adaptive Top-K OPD（本方法）** |

Adaptive Top-K OPD 是固定 Top-K OPD 的自然推广，后者是前者在 $f \equiv K_{\text{fixed}}$ 时的特例。

---

## 8. 自适应 K 的工程实现考量

### 8.1 批量不规整问题

不同位置 $t$ 的 $K_t$ 不同，导致同一 batch 内不同位置的 KL 计算维度不同。这在 GPU 上不友好。

**解决方案**：

**方案 1：离散化 $K_t$ 到固定集合**

$$
K_t \in \{K_1, K_2, \ldots, K_L\}, \quad \text{e.g., } \{4, 8, 16, 32, 64\}
$$

将位置按 $K_t$ 分桶，每个桶内做 batch 化 KL 计算。

**方案 2：统一用 $K_{\max}$，然后 mask**

取所有位置的 Top-$K_{\max}$，但对 $K_t < K_{\max}$ 的位置，只在前 $K_t$ 个 token 上计算 KL，后续 mask 掉。这样只需要一次 Top-$K_{\max}$ 操作，额外开销仅是 masking。

**方案 3：排序后前缀和 + 质量阈值法天然 batchable**

对于累计质量阈值法，可以先取 Top-$K_{\max}$，然后对排序后的概率做前缀和，用 `searchsorted` 找到每个位置首次超阈值的位置。这种方式可以全程 batch 化。

### 8.2 计算开销对比

| 方法 | 每位置开销 | 额外操作 |
|------|-----------|---------|
| 全词表 KL | $O(|\mathcal{V}|)$ | 无 |
| 固定 K KL | $O(K)$ | Top-K 选取 $O(|\mathcal{V}| \log K)$ 或 $O(|\mathcal{V}|)$ |
| 自适应 K（熵法） | $O(K_{\max})$ | Top-$K_{\max}$ 选取 + 熵估计（复用 top-M） |
| 自适应 K（质量法） | $O(K_{\max})$ | Top-$K_{\max}$ + 前缀和 + searchsorted |

**关键观察**：Top-$K_{\max}$ 选取的开销是一次性的，一旦取了 Top-$K_{\max}$，后续的截断/归一化/KL 计算都在 $K_{\max}$ 空间内完成。因此，**自适应 K 相对固定 K 的额外计算开销几乎为零**——唯一的额外成本是熵估计或前缀和计算，这些都是 $O(K_{\max})$ 的操作。

### 8.3 K_t 的平滑与防抖

训练早期 $K_t$ 可能不稳定，导致相邻 step 的 K 剧烈波动。解决方案：

**EMA 平滑**：

$$
K_t^{\text{smooth}} = (1 - \beta) \cdot K_t + \beta \cdot K_t^{\text{smooth, prev}}
$$

$\beta = 0.9$ 或 $0.99$。

**离散分桶**：如 $K_t \in \{4, 8, 16, 32\}$，天然防止抖动。

### 8.4 Stop-gradient 的必要性

$K_t$ 的计算路径中包含学生模型的 logits，如果不做 stop-gradient：

$$
\frac{\partial \mathcal{L}}{\partial \theta} \supset \frac{\partial \mathcal{L}}{\partial K_t} \cdot \frac{\partial K_t}{\partial H_S} \cdot \frac{\partial H_S}{\partial \theta}
$$

模型可能学到"人为压低熵以减小 K_t，从而降低 KL loss"——这是一个 shortcut，不是真正的分布对齐。

因此，**$K_t$、$\hat{H}_S(t)$、$\alpha_t$ 都必须做 stop-gradient**。

---

## 9. 全词表蒸馏 vs Top-K 蒸馏 vs Adaptive Top-K 蒸馏：系统比较

### 9.1 理论性质比较

| 性质 | 全词表 KL | 固定 K Top-K KL | Adaptive K Top-K KL |
|------|----------|----------------|-------------------|
| 目标无偏性 | 无偏（优化真实 KL） | 有偏（截断后 ≠ 真实 KL） | 有偏，但偏差随状态自适应 |
| 梯度方差 | 高（长尾噪声） | 低 | 低~中（取决于 K_t 分布） |
| 每位置计算量 | $O(|\mathcal{V}|)$ | $O(K)$ | $O(K_{\max})$ 平均 $O(\mathbb{E}[K_t])$ |
| 对排序信息的利用 | 全词表排序（但被噪声稀释） | Top-K 内排序 | Top-K_t 内排序 |
| 是否需要超参调优 | 少（温度等） | K 需网格搜索 | $K_{\min}, K_{\max}, \gamma$ |
| 对分布形状的适配 | 全适配 | 不适配 | 部分适配（通过 K_t） |

### 9.2 何时全词表更优？

- 学生已经训练得较好，与教师差异小，长尾噪声不严重
- 词表较小（$|\mathcal{V}| < 10K$），长尾问题本身不严重
- 研究场景，追求理论完备性

### 9.3 何时固定 K 更优？

- 简单快速 baseline
- 所有位置的不确定性分布比较均匀（如某些受限领域）
- 工程约束要求最简实现

### 9.4 何时 Adaptive K 最有价值？

- **大词表**（32K+）：长尾问题严重，不同位置熵差异大
- **异构数据**：prompt 难度差异大（如数学推理 + 创意写作混合训练）
- **训练资源受限**：需要在相同算力下获得更好效果
- **蒸馏后期**：学生已收敛，需要精细对齐少数困难位置

---

## 10. 实验设计方案

### 10.1 必做对照实验

| 组别 | 方法 | 说明 |
|------|------|------|
| A1 | 全词表 OPD | Upper bound on quality, lower bound on efficiency |
| A2 | Fixed-K=4 OPD | 小 K baseline |
| A3 | Fixed-K=8 OPD | 中 K baseline |
| A4 | Fixed-K=16 OPD | 中大 K baseline |
| A5 | Fixed-K=32 OPD | 大 K baseline |
| B1 | Entropy-Adaptive-K OPD | **主方法** |
| B2 | Mass-threshold-Adaptive-K OPD | 强对照 |
| B3 | Entropy+Divergence-Adaptive-K OPD | 进阶方法 |

### 10.2 关键评估指标

**任务性能**：
- 下游 benchmark 得分（GSM8K, HumanEval, MMLU 等）
- 生成质量（胜率 vs 教师 / 参考模型）
- Pass@k / rouge / BLEU 等

**蒸馏效率**：
- 平均 $\mathbb{E}[K_t]$（衡量计算节省）
- 训练吞吐量（tokens/s）
- 教师推理总 FLOPs
- 达到相同性能所需训练步数

**机制诊断**（验证 adaptive 是否在做正确的事）：
- $K_t$ 分布 vs 归一化熵 $\hat{H}_S(t)$ 的散点图
- 不同位置类型（语法词、逻辑词、开放式生成）的平均 $K_t$
- $K_t$ 随训练 step 的动态变化
- 不同 bin 下（低/中/高熵）的 KL 下降曲线

**稳定性**：
- 训练 loss 方差
- 梯度范数方差
- $K_t$ 的时序稳定性（EMA 前后的对比）

### 10.3 核心要验证的假设

1. **Adaptive K 在高熵位置显著增大 K_t**，在低熵位置显著减小 K_t
2. **在相同 $\mathbb{E}[K_t]$ 预算下，Adaptive K 优于 Fixed K**（效率前沿 Pareto 改进）
3. **Adaptive K 能接近全词表 KL 的效果，但平均 K 远小于 $|\mathcal{V}|$**
4. **Adaptive K 在异构数据上优势更大**（对比单一领域数据）

### 10.4 消融实验

| 消融项 | 变量 | 目的 |
|--------|------|------|
| γ 的选择 | {0.5, 1.0, 1.5, 2.0} | 熵映射曲线的影响 |
| $K_{\min}$ 的选择 | {2, 4, 8} | 最小覆盖的必要性 |
| 权重方案 | 均匀 vs $\pi_S(y_t)$ vs 混合 | 验证权重与 K 的交互 |
| 虚拟 token | 有/无 | 归一化偏差修正的效果 |
| EMA 平滑 | 有/无 | 训练稳定性 |
| 训练阶段调度 | 固定 vs 课程式 | K_min 随训练变化的作用 |

---

## 11. 可能的失败模式与应对

### 11.1 自适应 K 与全词表差距过大

**症状**：Adaptive K 的效果反而不如 Fixed-K=32 或全词表。

**可能原因**：
1. $K_{\max}$ 设得太小
2. 熵映射函数不准确，导致高熵位置 K 仍然不够
3. 归一化偏差在 K 变化时累积

**应对**：
- 增大 $K_{\max}$
- 用累计质量法替代纯熵法
- 加入虚拟 token 修正

### 11.2 K_t 抖动导致训练不稳定

**症状**：loss 曲线震荡，梯度范数波动大。

**可能原因**：
1. K_t 在两个离散值之间来回跳（如 7→8→7→8）
2. 不同 step 的 K_t 差异导致 KL 尺度不一致

**应对**：
- EMA 平滑
- 离散分桶到 {4, 8, 16, 32}
- 对 KL 值做 layer norm（消除尺度波动）

### 11.3 学生"欺骗"自适应机制

**症状**：学生学到压低熵来减小 K_t，但实际分布质量并未改善。

**可能原因**：
1. K_t 未做 stop-gradient
2. 梯度通过熵间接影响学生策略

**应对**：
- 确保 $K_t, \hat{H}_S(t), \alpha_t$ 全部 stop-gradient
- 在验证集上监控全词表 KL（而非 Top-K KL），确保全词表 KL 也在下降
- 加入熵正则化项防止学生过度锐化

### 11.4 Adaptive K 的额外开销抵消了收益

**症状**：算上熵估计和动态 topk 的开销，总训练时间接近全词表。

**应对**：
- 熵估计复用 Top-$K_{\max}$ 的 logits（零额外前向）
- 用质量阈值法时，前缀和操作是 $O(K_{\max})$ 的，开销可以忽略
- 核心收益在教师推理端：只需返回 Top-$K_{\max}$ 的 logits 而非全词表 → **通信量和教师计算量大幅节省**

---

## 12. 一个最小可行方案（MVP）

如果你要快速验证 adaptive top-k 的价值，建议以下配置：

### 配置

```python
# 超参数
K_MIN = 4
K_MAX = 64
GAMMA = 1.5
K_BUCKETS = [4, 8, 16, 32, 64]  # 离散分桶

# 训练策略
WARMUP_STEPS = 100  # 前 100 步用 K=32 固定
EMA_BETA = 0.9      # K_t 平滑

# 权重
ALPHA_STRATEGY = "uniform"  # 先用均匀，验证 K 本身的价值
# ALPHA_STRATEGY = "prob"   # 第二轮实验

# 归一化
USE_VIRTUAL_TOKEN = False  # 第一轮不用，简化实现

# Stop-gradient
STOP_GRAD_K = True
STOP_GRAD_ALPHA = True
```

### 伪代码

```python
def adaptive_topk_opd_step(student, teacher, prompts, optimizer):
    total_loss = 0

    for x in prompts:
        # 1. On-policy 生成
        y, student_logits_seq = student.generate(x, return_logits=True)

        # 2. 教师前向
        with torch.no_grad():
            teacher_logits_seq = teacher.forward(x, y)

        # 3. 统一取 Top-K_MAX
        student_probs = F.softmax(student_logits_seq, dim=-1)
        topk_probs_s, topk_indices = student_probs.topk(K_MAX, dim=-1)

        # 4. 计算熵（复用 top-K_MAX 的 logits 近似）
        entropy = compute_entropy_approx(student_probs, topk_probs_s)  # (T,)
        norm_entropy = entropy / math.log(VOCAB_SIZE)  # (T,)

        # 5. 计算 K_t
        K_t_continuous = K_MIN + (K_MAX - K_MIN) * (norm_entropy ** GAMMA)
        K_t = bucketize(K_t_continuous, K_BUCKETS)  # 离散化
        K_t = ema_smooth(K_t, prev_K_t)  # EMA 平滑
        K_t = K_t.detach()  # stop-gradient

        # 6. 逐位置计算 Adaptive Top-K KL
        loss = 0
        for t in range(len(y)):
            kt = K_t[t].item()

            # 学生 Top-kt 分布
            s_probs = topk_probs_s[t, :kt]
            t_probs = F.softmax(teacher_logits_seq[t], dim=-1)[topk_indices[t, :kt]]

            # 归一化
            s_probs_norm = s_probs / s_probs.sum()
            t_probs_norm = t_probs / t_probs.sum()

            # Reverse KL
            kl_t = (s_probs_norm * (s_probs_norm.log() - t_probs_norm.log())).sum()

            loss += kl_t  # 均匀权重

        total_loss += loss

    optimizer.zero_grad()
    total_loss.backward()
    optimizer.step()
```

### 评估重点

1. **画 $K_t$ vs $\hat{H}_S(t)$ 的散点图**：验证"高熵→大K"是否如预期
2. **画 performance vs $\mathbb{E}[K_t]$ 的曲线**：对比 Adaptive/Fixed 在相同平均 K 下的性能
3. **对比 Fixed-K=32 和 Adaptive（$\mathbb{E}[K_t] \approx 32$）的效果**：如果 Adaptive 更好，说明 K 的动态分配有意义

---

## 13. 研究叙事建议

如果要把这个工作写成论文，核心叙事可以是：

**问题**：Top-K 蒸馏用固定 K，但不同位置的信息需求不同 → 截断偏差与长尾噪声的折中不够优。

**洞察**：On-Policy 蒸馏天然为学生提供了不确定性信号（熵），这个信号可以用来动态决定每个位置需要多少候选 token 来做有效的分布对齐。

**方法**：Adaptive Top-K OPD——基于学生不确定性（熵/累计质量）自适应决定每位置的 K_t，在 Top-K_t 子空间上蒸馏。

**关键论点**：
1. 自适应 K 是偏差-方差权衡的**位置级最优解**，而非全局折中
2. 在相同计算预算（$\mathbb{E}[K_t]$）下，Adaptive K Pareto 改进 Fixed K
3. 自适应 K 让蒸馏"在该用力的地方用力"，与 on-policy 的核心精神（按学生当前状态学习）一脉相承

---

## 14. 总结

| 问题 | 回答 |
|------|------|
| 全词表 KL 的核心问题？ | 长尾噪声大、梯度方差高、计算成本高，但对"不重要"的 token 浪费了对齐精度 |
| 固定 K 的核心问题？ | 不同位置/不同状态下信息需求不同，全局 K 无法适配 → 低熵位置浪费、高熵位置欠覆盖 |
| Adaptive K 的核心思想？ | 让 K 随位置自适应——确定的少看、不确定的多看，在偏差和方差间做位置级最优折中 |
| 为什么在 OPD 中尤其自然？ | OPD 本身就是"按学生当前分布学习"，Adaptive K 把这从序列级推广到了 token 级 |
| 最简实现方案？ | 熵映射 $\hat{H}_S(t)^\gamma \to K_t$ + 均匀权重 + stop-gradient |
| 核心验证实验？ | 性能-$\mathbb{E}[K_t]$ 前沿图：Adaptive 是否 Pareto 改进 Fixed |

**一句话**：Full-vocab 太全但噪，Fixed-TopK 太硬；Adaptive-TopK 通过状态自适应的 K_t，在每个位置上找到偏差与方差的最优折中，是更符合 on-policy 本质的动态蒸馏策略。