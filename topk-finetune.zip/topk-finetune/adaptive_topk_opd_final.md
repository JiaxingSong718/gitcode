# Adaptive Top-K On-Policy Distillation 最终方案

## 1. 核心问题

固定 Top-K OPD 存在根本矛盾：高确定性位置（语法补全等）只需小 K 去噪，高不确定性位置（开放生成、推理分叉）需要大 K 保留教师信号，全局固定 K 无法兼顾两者。

## 2. 方案总览

本方案包含两个核心设计：

1. **概率质量覆盖自适应 K**：根据学生模型在每个位置的输出分布，动态选择参与蒸馏的 token 数量 $K_t$
2. **熵驱动的位置加权**：用归一化熵调制位置权重，替代原来的生成概率加权，重点关照"学生不确定"和"学生自信但可能与教师分歧"的位置

---

## 3. 自适应 Top-K 选择

### 3.1 公式

$$
K_t = \min \left\{ k \in [K_{\min}, K_{\max}] : \sum_{i=1}^{k} \pi_S(v_i \mid y_{<t}, x) \geq \rho \right\}
$$

其中 $v_1, v_2, \ldots$ 按学生概率降序排列。

### 3.2 超参数推荐

| 超参数 | 推荐值 | 含义 |
|--------|--------|------|
| $\rho$ | 0.85 ~ 0.95 | 概率质量覆盖率阈值，直接控制近似误差界 |
| $K_{\min}$ | 3 ~ 5 | 最小 token 数，避免退化为单点比较 |
| $K_{\max}$ | 30 ~ 100 | 最大 token 数，控制计算开销上限 |

### 3.3 为什么选概率质量覆盖而非熵映射

| 维度 | 熵映射 $K = f(H)$ | 概率质量覆盖 |
|------|-------------------|-------------|
| 可解释性 | 熵到 K 的映射不直观 | $\rho$ 直接对应"忽略多少概率质量" |
| 与误差界的关系 | 间接 | 直接挂钩：近似误差 $\leq \mathcal{O}(\frac{1-\rho}{\rho}\log|\mathcal{V}|)$ |
| 分布形态鲁棒性 | 熵相近但分布形态不同（双峰 vs 均匀）时所需 K 差异大 | 直接操作概率质量，绕过映射不确定性 |

### 3.4 近似误差保证

设定覆盖率阈值 $\rho$，位置 $t$ 的实际覆盖率 $\rho_t \geq \rho$，则 Top-K KL 与全词表 KL 的近似误差有上界：

$$
\left| D_{\mathrm{KL}}^{(t, K_t)} - D_{\mathrm{KL}}^{(t, |\mathcal{V}|)} \right| \leq \mathcal{O}\!\left(\frac{1 - \rho}{\rho} \log |\mathcal{V}|\right)
$$

固定 K 无法保证每个位置的覆盖率——高熵位置的 $\rho_t$ 可能远低于此，导致近似误差不可控。

---

## 4. 熵驱动的位置加权

### 4.1 公式

$$
w_t = \hat{H}_t \cdot \pi_S(y_t \mid y_{<t}, x)
$$

其中 $\hat{H}_t = H_t / \log|\mathcal{V}|$ 是归一化熵，$\pi_S(y_t)$ 做 stop-gradient。

### 4.2 与原始方法的对比

原始 Top-K OPD 的位置权重为 $w_t = \pi_S(y_t)$，仅关注"学生确定的主路径"。引入熵调制后：

| 位置特征 | $\hat{H}_t$ | $\pi_S(y_t)$ | $w_t$ | 解读 |
|---------|------------|-------------|-------|------|
| 高确定 + 主路径 | 低 | 高 | 中 | 已对齐好，无需过度加权 |
| 高确定 + 非主路径 | 低 | 低 | 低 | 不需要关注 |
| **高不确定 + 主路径** | **高** | **高** | **高** | **最关键位置**：学生概率集中但分布整体不确定，教师可能不同意，需重点对齐 |
| 高不确定 + 非主路径 | 高 | 低 | 中低 | 探索性采样，适度关注 |

**关键洞察**：仅用 $\pi_S(y_t)$ 加权会忽略"学生虽自信但教师不同意"的位置。$\hat{H}_t$ 的引入使得即使 $\pi_S(y_t)$ 高（某个 token 概率大），只要整体分布的熵高（说明其他 token 也有不可忽略的概率），该位置仍会获得较高权重。

### 4.3 方差-偏差权衡

- **低熵位置**（$\hat{H}_t$ 小）：KL 估计方差低，但偏差可能大。低 $\hat{H}_t$ 适度降权，避免在已对齐位置浪费梯度
- **高熵位置**（$\hat{H}_t$ 大）：KL 估计方差较高，但也是最需要教师指导的位置。高 $\hat{H}_t$ 提升权重，确保关键位置获得足够训练信号

本质上是一种**重要性采样**——在最关键的位置上分配更多计算预算。

---

## 5. 最终损失函数

$$
\boxed{
\mathcal{L} = \sum_{t=1}^{T} \underbrace{\hat{H}_t \cdot \pi_S(y_t \mid y_{<t}, x)}_{\text{熵调制位置权重}} \cdot \underbrace{\sum_{v \in \mathcal{T}_t^{K_t}} \hat{\pi}_S(v) \log \frac{\hat{\pi}_S(v)}{\hat{\pi}_T(v)}}_{\text{自适应 Top-K KL 散度}}
}
$$

其中：
- $K_t$：由概率质量覆盖阈值 $\rho$ 动态决定
- $\mathcal{T}_t^{K_t}$：位置 $t$ 上学生概率最高的 $K_t$ 个 token
- $\hat{\pi}_S, \hat{\pi}_T$：在 $\mathcal{T}_t^{K_t}$ 上的归一化分布
- $\hat{H}_t = H_t / \log|\mathcal{V}|$：归一化熵
- $\pi_S(y_t)$：做 stop-gradient

---

## 6. 可选增强：KL 散度混合加权

更强的位置加权信号——直接用 Top-K 子空间上的 KL 散度作为权重：

$$
w_t^{\text{hybrid}} = \hat{H}_t^\alpha \cdot \left(D_{\mathrm{KL}}^{(t, K_t)}\right)^\beta
$$

- $\alpha, \beta$ 控制熵和分歧度的影响比例（推荐初值 $\alpha=1.0, \beta=0.5$）
- **必须对 KL 散度项做 stop-gradient**，否则梯度优化会让 KL 趋近 0（直接降权而非真正对齐）

---

## 7. 算法流程

```
输入: 教师模型 π_T, 学生模型 π_S, 数据集 D,
      覆盖率阈值 ρ, K_min, K_max, 学习率 η

For each iteration:

  1. 采样 Prompt
     从 D 中采样一批 prompt: {x_i}_{i=1}^B

  2. On-Policy 序列生成
     For each x_i:
       y = (y_1, ..., y_T),  y_t ~ π_S(·|y_{<t}, x_i)

  3. 自适应确定 K_t
     For each position t:
       probs_S = softmax(π_S(·|y_{<t}, x))
       sorted_probs = sort(probs_S, descending=True)
       cumsum = cumulative_sum(sorted_probs)
       K_t = min {k ∈ [K_min, K_max] : cumsum[k] ≥ ρ}
       H_t = entropy(probs_S)
       Ĥ_t = H_t / log|V|

  4. 构建 Top-K 集合并计算 KL
     For each position t:
       T_t^{K_t} = {前 K_t 个概率最高的 token}
       π̂_S, π̂_T = 分别在 T_t^{K_t} 上归一化
       KL_t = D_KL(π̂_S || π̂_T)

  5. 熵调制加权
     w_t = Ĥ_t · π_S(y_t | y_{<t}, x).detach()
     # 可选归一化: w_t = w_t / Σ_{t'} w_{t'}

  6. 加权聚合
     L = Σ_t  w_t · KL_t

  7. 参数更新
     θ ← θ - η · ∇_θ L
```

---

## 8. 伪代码实现

```python
def adaptive_topk_opd_step(student, teacher, prompts, rho, K_min, K_max, optimizer):
    """单步 Adaptive Top-K On-Policy Distillation"""

    total_loss = 0
    vocab_size = student.config.vocab_size

    for x in prompts:
        # Step 1: On-Policy 生成
        y, student_logits_seq = student.generate(x, return_logits=True)

        # Step 2: 教师前向推理
        with torch.no_grad():
            teacher_logits_seq = teacher.forward(x, y)

        loss = 0
        for t in range(len(y)):
            student_probs = F.softmax(student_logits_seq[t], dim=-1)
            teacher_probs = F.softmax(teacher_logits_seq[t], dim=-1)

            # Step 3: 自适应确定 K_t（概率质量覆盖）
            sorted_probs, sorted_indices = torch.sort(student_probs, descending=True)
            cumsum = torch.cumsum(sorted_probs, dim=0)
            K_t = torch.searchsorted(cumsum, rho) + 1
            K_t = torch.clamp(K_t, min=K_min, max=K_max).item()

            # Step 4: 取自适应 Top-K 并归一化
            topk_probs_s = sorted_probs[:K_t]
            topk_indices = sorted_indices[:K_t]
            topk_probs_t = teacher_probs[topk_indices]

            topk_probs_s_norm = topk_probs_s / topk_probs_s.sum()
            topk_probs_t_norm = topk_probs_t / topk_probs_t.sum()

            # Step 5: 计算自适应 Top-K KL 散度
            kl_t = (topk_probs_s_norm * (
                topk_probs_s_norm.log() - topk_probs_t_norm.log()
            )).sum()

            # Step 6: 熵调制位置权重
            H_t = -(student_probs * student_probs.log()).sum()
            H_t_norm = H_t / math.log(vocab_size)
            w_t = H_t_norm * student_probs[y[t]].detach()

            loss += w_t * kl_t

        total_loss += loss

    # Step 7: 反向传播
    optimizer.zero_grad()
    total_loss.backward()
    optimizer.step()

    return total_loss.item()
```

---

## 9. 计算效率分析

### 9.1 平均等效 K

根据语言模型分布的典型特性（大部分位置是低熵的），平均等效 K 远小于保证覆盖率所需的固定 K：

- 典型设置：$K_{\min}=3, K_{\max}=50, \rho=0.9$
- 假设 70% 低熵位置（$K_t \approx 5$），30% 高熵位置（$K_t \approx 30$）
- 平均 $\bar{K} \approx 0.7 \times 5 + 0.3 \times 30 = 12.5$
- 对比固定 $K=30$（需保证高熵位置覆盖），节省约 58% 的 KL 计算

### 9.2 额外开销

自适应 K 引入的额外计算（排序 + 累积和）相对于 Transformer 前向推理可忽略。主要开销在教师推理和 KL 计算，而自适应 K 在低熵位置减少的 KL 计算量远超排序开销。

---

## 10. 训练动态：自然课程学习

Adaptive Top-K 在训练过程中会自然演化，无需额外调度：

| 阶段 | 分布特点 | $K_t$ 行为 | 等效效果 |
|------|---------|-----------|---------|
| 早期 | 学生与教师差异大，高熵位置多 | 整体 $K_t$ 偏大 | 广泛探索 |
| 中期 | 学生学到教师主要模式，部分位置熵降低 | $K_t$ 两极分化 | 聚焦关键位置 |
| 晚期 | 大部分位置已对齐，熵普遍低 | 整体 $K_t$ 偏小，仅残余分歧位置用大 K | 精修微调 |

这种自然的课程学习效果是固定 K 无法实现的。

---

## 11. 与 Top-K OPD 的完整对比

| 维度 | Top-K OPD | Adaptive Top-K OPD |
|------|-----------|-------------------|
| K 的选择 | 全局固定超参数 | 逐位置动态决定 |
| 位置权重 | 生成概率 $\pi_S(y_t)$ | 熵调制 $\hat{H}_t \cdot \pi_S(y_t)$ |
| 近似误差 | 不可控（高熵位置可能很大） | 有上界（覆盖率 $\rho$ 保证） |
| 计算效率 | 固定开销 | 自适应开销，平均更低 |
| 训练动态 | 静态课程 | 自然课程学习 |
| 超参数 | $K$（1 个） | $\rho, K_{\min}, K_{\max}$（3 个，有直观含义） |

---

## 12. 实验设计

### 12.1 消融实验

| 编号 | K 策略 | 位置权重 | 说明 |
|------|--------|---------|------|
| E1 | 固定 K=10 | 均匀 | 标准 Top-K OPD baseline |
| E2 | 固定 K=10 | $\pi_S(y_t)$ | Top-K OPD（原方法） |
| E3 | 概率覆盖 $\rho=0.9$ | 均匀 | 仅 Adaptive K，无位置加权 |
| E4 | 概率覆盖 $\rho=0.9$ | $\pi_S(y_t)$ | Adaptive K + 原位置加权 |
| E5 | 概率覆盖 $\rho=0.9$ | $\hat{H}_t \cdot \pi_S(y_t)$ | **完整方法** |
| E6 | 概率覆盖 $\rho=0.9$ | $D_{\mathrm{KL}}^{(t, K_t)}$ | Adaptive K + KL 加权 |
| E7 | 概率覆盖 $\rho=0.9$ | $\hat{H}_t^\alpha \cdot (D_{\mathrm{KL}}^{(t,K_t)})^\beta$ | Adaptive K + 混合加权 |
| E8 | 全词表 | 均匀 | 标准 OPD 上界 |

### 12.2 关键指标

1. **蒸馏质量**：下游任务性能（perplexity, 准确率）
2. **分布对齐度**：教师-学生 KL 散度（全词表和 Top-K 分别测量）
3. **计算效率**：平均 $K_t$、总 FLOPs、训练时间
4. **训练动态**：$K_t$ 和 $\hat{H}_t$ 随训练步数的演化曲线
5. **位置级分析**：不同类型位置（语法/语义/推理）的 $K_t$ 分布

### 12.3 超参数搜索

| 超参数 | 搜索范围 | 说明 |
|--------|---------|------|
| $\rho$ | [0.80, 0.85, 0.90, 0.95] | 覆盖率阈值 |
| $K_{\min}$ | [2, 3, 5] | 最小 token 数 |
| $K_{\max}$ | [30, 50, 100] | 计算预算上限 |
| $\alpha$ | [0.5, 1.0, 2.0] | 熵权重指数（混合加权） |
| $\beta$ | [0.0, 0.5, 1.0] | KL 散度权重指数（混合加权） |

### 12.4 可验证假设

1. **H1**：低熵位置的平均 $K_t$ 显著低于高熵位置
2. **H2**：Adaptive Top-K 在高熵位置对齐质量优于固定小 K，低熵位置计算开销低于固定大 K
3. **H3**：训练过程中 $K_t$ 平均值呈下降趋势（自然课程学习）
4. **H4**：熵调制加权比纯概率加权在"学生自信但教师不同意"位置上有更好梯度信号
5. **H5**：$\rho$ 最优值与教师-学生能力差距正相关

---

## 13. 与其他方法的兼容性

- **GKD（混合 on/off-policy）**：完全兼容，Adaptive K 和熵调制加权正交于数据选择策略，可直接替换 GKD 中的固定 K
- **训练课程自适应**：可在本方案基础上叠加 $K_{\max}(\alpha)$ 衰减，实现位置+训练进度双维度自适应
- **多尺度融合**：可作为本方案的替代方案，用多组 $\{K^{(m)}\}$ 的加权融合替代单一 $K_t$，但计算开销为 $M$ 倍

---

## 14. 常见疑问

**Q: $\rho$ 和 $K_{\max}$ 效果高度耦合怎么办？**
固定 $K_{\max}$ 为较大值（如 100），只调 $\rho$。$K_{\max}$ 主要影响极端平坦分布，大多数位置由 $\rho$ 主导。

**Q: 为什么不用 KL 散度驱动 K（方案二）？**
KL 散度驱动更精细，但需多次计算 KL（逐步扩展），计算开销大。概率质量覆盖只需一次排序+累积和，效率高且与误差界直接挂钩。可在本方案验证有效后，作为进阶增强手段。

**Q: 如何处理 batch 内不同样本不同位置 K_t 不同的问题？**
标准实现中，每个位置独立计算 $K_t$ 和 KL，天然支持变长 K。batch 化时可用 padding + mask 处理。