# Top-K On-Policy Distillation：创新点详解

## 0. 关键前提澄清

在讨论创新点之前，必须先明确标准 On-Policy Distillation（OPD）的真实做法：

**标准 OPD 在每个位置已经计算了全词表 $|\mathcal{V}|$ 维度的 KL 散度**。其"on-policy"体现在**序列级别**——用学生模型自回归采样生成序列 $y$，从而确定每个位置的前缀 $y_{<t}$。给定前缀后，KL 散度是在完整词表上计算的：

$$
\mathcal{L}_{\text{standard-OPD}} = \sum_{t=1}^{T} D_{\mathrm{KL}}\!\left(\pi_S(\cdot | y_{<t}, x) \;\|\; \pi_T(\cdot | y_{<t}, x)\right)
$$

其中 $\pi_S(\cdot)$ 和 $\pi_T(\cdot)$ 都是 $|\mathcal{V}|$ 维的完整分布。

因此，本方法的创新**不是**"从单 token 扩展到多 token 的信息利用"，而是以下两个正交的改进方向。

---

## 创新点一：Top-K 聚焦蒸馏——去噪与高效的分布匹配

### 1.1 问题：全词表 KL 的长尾噪声

标准 OPD 在完整词表（$|\mathcal{V}|$ 通常为 32K~128K+）上计算 KL 散度。然而语言模型的输出分布具有极强的**长尾特性**：

- 在任意位置 $t$，绝大多数 token 的概率极低（$< 10^{-6}$）
- 这些长尾 token 对 KL 散度的贡献是**噪声主导**的：
  - 教师和学生在这些 token 上的概率估计都不可靠
  - 微小的概率波动会导致 $\log$ 比值剧烈变化
  - 这些 token 在推理时几乎不会被采样到，对齐它们没有实际意义

形式化地说，全词表 KL 可以分解为：

$$
D_{\mathrm{KL}}(\pi_S \| \pi_T) = \underbrace{\sum_{v \in \mathcal{T}_t^K} \pi_S(v) \log \frac{\pi_S(v)}{\pi_T(v)}}_{\text{Top-K 高概率区域（信号）}} + \underbrace{\sum_{v \notin \mathcal{T}_t^K} \pi_S(v) \log \frac{\pi_S(v)}{\pi_T(v)}}_{\text{长尾区域（噪声）}}
$$

长尾部分虽然每个 token 的 $\pi_S(v)$ 很小，但 $\log \frac{\pi_S(v)}{\pi_T(v)}$ 可能很大且不稳定，累积起来会引入显著噪声。

### 1.2 解决方案：Top-K 子空间聚焦

**只在学生模型概率最高的 $K$ 个 token 构成的子空间上计算 KL 散度**，主动丢弃长尾噪声：

$$
\mathcal{T}_t^K = \text{Top-K}(\pi_S(\cdot | y_{<t}, x))
$$

在 $\mathcal{T}_t^K$ 上重新归一化后计算 KL：

$$
D_{\mathrm{KL}}^{(t, K)} = \sum_{v \in \mathcal{T}_t^K} \hat{\pi}_S(v) \log \frac{\hat{\pi}_S(v)}{\hat{\pi}_T(v)}
$$

其中：

$$
\hat{\pi}_S(v) = \frac{\pi_S(v)}{\sum_{v' \in \mathcal{T}_t^K} \pi_S(v')}, \quad \hat{\pi}_T(v) = \frac{\pi_T(v)}{\sum_{v' \in \mathcal{T}_t^K} \pi_T(v')}
$$

### 1.3 为什么这是合理的？

**信息集中性保证**：对于训练良好的语言模型，Top-K 覆盖的概率质量：

$$
\rho_S^{(t)} = \sum_{v \in \mathcal{T}_t^K} \pi_S(v | y_{<t}, x)
$$

通常 $K \geq 10$ 时 $\rho_S^{(t)} > 0.9$。这意味着 Top-K 已经捕获了分布的主要结构，丢弃的只是噪声。

**近似误差可控**：

$$
\left| D_{\mathrm{KL}}(\hat{\pi}_S \| \hat{\pi}_T) - D_{\mathrm{KL}}(\pi_S \| \pi_T) \right| \leq \mathcal{O}\!\left(\frac{1 - \rho_S^{(t)}}{\rho_S^{(t)}} \log |\mathcal{V}|\right)
$$

当 $\rho_S^{(t)} \to 1$ 时误差趋于 0。

### 1.4 创新点总结

| 维度 | 标准 OPD（全词表 KL） | Top-K OPD |
|------|---------------------|-----------|
| KL 计算范围 | 全词表 $|\mathcal{V}|$（32K~128K） | Top-K 子空间（$K$ 通常 5~50） |
| 长尾 token | 全部参与，引入噪声 | 主动过滤，聚焦高概率区域 |
| 计算复杂度 | $O(|\mathcal{V}|)$ per position | $O(K)$ per position（+ Top-K 选取） |
| 梯度质量 | 受长尾噪声干扰 | 更干净，信噪比更高 |
| 教师排序信息 | 被长尾稀释 | 在 Top-K 内精确保留相对排序 |

**核心 insight**：蒸馏的目标不是让学生在所有 128K 个 token 上都和教师一致，而是让学生在**真正重要的候选 token**上和教师的偏好排序一致。Top-K 聚焦正是实现了这一点。

---

## 创新点二：生成概率自适应加权——位置级重要性感知

### 2.1 问题：标准 OPD 的均匀位置权重

标准 OPD 对序列中所有位置的 KL 散度做**均匀求和**：

$$
\mathcal{L}_{\text{standard}} = \sum_{t=1}^{T} D_{\mathrm{KL}}^{(t)}
$$

这隐含了一个假设：**每个位置同等重要**。但实际上：

- 有些位置学生非常确定（如常见的语法词、确定性的推理步骤），$\pi_S(y_t)$ 接近 1
- 有些位置学生非常不确定（如开放性选择、多种合理续写），$\pi_S(y_t)$ 很小
- 这两类位置对蒸馏的贡献和需求是不同的

### 2.2 解决方案：按生成概率加权

用学生在每个位置实际生成的 token 的概率作为该位置的权重：

$$
w_t = \pi_S(y_t | y_{<t}, x)
$$

加权后的损失函数：

$$
\mathcal{L} = \sum_{t=1}^{T} w_t \cdot D_{\mathrm{KL}}^{(t, K)}
$$

### 2.3 为什么用生成概率加权？

**直觉 1：主路径优先**

学生在推理时，高概率 token 构成的路径是最可能被走到的"主路径"。对齐主路径上的分布，直接提升推理时的实际表现。

$$
P(\text{走到位置 } t \text{ 的前缀 } y_{<t}) = \prod_{i=1}^{t-1} \pi_S(y_i | y_{<i}, x)
$$

$w_t = \pi_S(y_t)$ 大意味着这个位置在主路径上，蒸馏它的价值更高。

**直觉 2：不确定位置降权 = 降噪**

当学生在某个位置非常不确定时（$w_t$ 小）：
- 该位置的 Top-K 分布本身就比较平坦，KL 散度的信号质量较低
- 教师在该位置的分布可能和学生差异很大，强行对齐可能导致训练不稳定
- 降低权重相当于对这些"噪声位置"做了自适应的正则化

**直觉 3：与 trajectory probability 的联系**

概率加权可以被理解为在学生的 trajectory 分布下做重要性加权：

$$
\mathcal{L} = \mathbb{E}_{y \sim \pi_S} \left[ \sum_t \pi_S(y_t | y_{<t}, x) \cdot D_{\mathrm{KL}}^{(t,K)} \right]
$$

这使得 loss 自然地关注学生在推理时最可能经过的状态，而非均匀地覆盖所有状态。

### 2.4 与现有加权策略的对比

| 加权策略 | 权重定义 | 特点 |
|---------|---------|------|
| 均匀（标准 OPD） | $w_t = 1$ | 所有位置同等对待 |
| 长度归一化 | $w_t = 1/T$ | 消除序列长度影响，但仍均匀 |
| 教师置信度加权 | $w_t = \max_v \pi_T(v)$ | 关注教师确定的位置 |
| **生成概率加权（本方法）** | $w_t = \pi_S(y_t)$ | **关注学生确定的位置，即推理主路径** |
| Advantage 加权（RL 风格） | $w_t = A(y_t)$ | 需要额外的 value function |

**本方法的独特之处**：权重完全来自学生自身，无需额外模型或标注，且与 on-policy 的理念一致——关注学生自己最可能走的路径。

### 2.5 实践细节

**Stop-gradient**：建议对 $w_t$ 做 `detach()`，只让梯度通过 KL 散度项回传：

$$
\nabla_\theta \mathcal{L} \approx \sum_{t=1}^{T} \underbrace{w_t}_{\text{detached}} \cdot \nabla_\theta D_{\mathrm{KL}}^{(t,K)}
$$

原因：如果不 detach，梯度会试图同时优化权重本身（让 $w_t$ 变小来降低 loss），这与蒸馏目标矛盾。

**归一化（可选）**：

$$
\bar{w}_t = \frac{w_t}{\sum_{t'=1}^{T} w_{t'}}
$$

使 loss 尺度与序列长度解耦，便于跨不同长度样本的 batch 训练。

---

## 两个创新点的协同效应

两个创新点不是独立的，它们协同工作产生 1+1 > 2 的效果：

```
                    标准 OPD
                    ┌─────────────────────────────┐
                    │  全词表 KL × 均匀权重         │
                    │  = 噪声多 × 不区分位置重要性   │
                    └─────────────────────────────┘
                              │
              ┌───────────────┼───────────────┐
              ▼                               ▼
    创新点一：Top-K 聚焦            创新点二：概率加权
    ┌─────────────────┐          ┌─────────────────┐
    │ Token 维度去噪    │          │ 位置维度去噪      │
    │ 过滤长尾 token    │          │ 降权不确定位置     │
    │ 聚焦高概率候选    │          │ 聚焦推理主路径     │
    └─────────────────┘          └─────────────────┘
              │                               │
              └───────────────┬───────────────┘
                              ▼
                    Top-K OPD（本方法）
                    ┌─────────────────────────────┐
                    │  Top-K KL × 概率加权          │
                    │  = Token 维度聚焦              │
                    │  × 位置维度聚焦                │
                    │  = 双重去噪，精准蒸馏           │
                    └─────────────────────────────┘
```

**协同效应**：
- **Token 维度**（创新点一）：在每个位置只关注最重要的 K 个 token，过滤长尾噪声
- **位置维度**（创新点二）：在序列中只关注最重要的位置（学生确定的主路径），降权噪声位置
- **双重聚焦**：同时在 token 和位置两个维度上做了自适应的"注意力"，使蒸馏信号的信噪比大幅提升

---

## 最终损失函数

$$
\boxed{
\mathcal{L}_{\text{TopK-OPD}} = \sum_{t=1}^{T} \underbrace{\pi_S(y_t | y_{<t}, x)}_{\text{位置权重（创新点二）}} \cdot \underbrace{\sum_{v \in \mathcal{T}_t^K} \hat{\pi}_S(v) \log \frac{\hat{\pi}_S(v)}{\hat{\pi}_T(v)}}_{\text{Top-K KL 散度（创新点一）}}
}
$$

其中 $\mathcal{T}_t^K = \text{Top-K}(\pi_S(\cdot | y_{<t}, x))$，$\hat{\pi}_S, \hat{\pi}_T$ 是在 $\mathcal{T}_t^K$ 上的归一化分布。

---

## 与相关工作的区分

| 方法 | Token 维度 | 位置维度 | 序列级别 |
|------|-----------|---------|---------|
| 标准 KD（Hinton 2015） | 全词表 | 均匀 | Off-policy |
| SeqKD（Kim & Rush 2016） | 全词表 | 均匀 | Off-policy（教师序列） |
| On-Policy Distillation | 全词表 | 均匀 | On-policy（学生序列） |
| GKD（Agarwal et al. 2024） | 全词表 | 均匀 | 混合 on/off-policy |
| **Top-K OPD（本方法）** | **Top-K 聚焦** | **概率加权** | **On-policy** |

本方法是首个同时在 **token 维度**和**位置维度**上进行自适应聚焦的 on-policy 蒸馏方法。
