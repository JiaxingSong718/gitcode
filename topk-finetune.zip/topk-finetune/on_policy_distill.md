# On-Policy Distillation 简要理论

## 1. 概述

On-Policy Distillation 是一种知识蒸馏方法，其核心思想是：**学生模型（Student）使用自身策略生成的数据来向教师模型（Teacher）学习**，而非使用教师模型生成的数据。这与 Off-Policy Distillation（直接在教师生成的数据上训练学生）形成对比。

## 2. 基本框架

### 2.1 角色定义

| 角色 | 说明 |
|------|------|
| **Teacher** $\pi_T$ | 大规模预训练模型，参数冻结，仅提供指导信号 |
| **Student** $\pi_S$ | 小规模模型，需要通过蒸馏获得接近教师的能力 |

### 2.2 On-Policy vs Off-Policy

| 维度 | On-Policy Distillation | Off-Policy Distillation |
|------|----------------------|------------------------|
| 数据来源 | 学生模型 $\pi_S$ 自身采样 | 教师模型 $\pi_T$ 预先生成 |
| 分布匹配 | 训练分布 = 推理分布 | 训练分布 $\neq$ 推理分布 |
| 数据新鲜度 | 每轮更新后重新采样 | 静态数据集，可能过时 |
| 计算开销 | 较高（需在线采样） | 较低（离线数据复用） |
| 训练稳定性 | 更稳定，避免 distribution shift | 可能存在 exposure bias |

## 3. 核心理论

### 3.1 目标函数

On-Policy Distillation 的核心目标是最小化学生策略与教师策略之间的差异，**在学生自身的分布下**度量：

$$
\mathcal{L}_{\text{on-policy}} = \mathbb{E}_{x \sim \mathcal{D},\, y \sim \pi_S(\cdot|x)} \left[ D_{\mathrm{KL}}\!\left(\pi_T(\cdot|x, y_{<t}) \;\|\; \pi_S(\cdot|x, y_{<t})\right) \right]
$$

其中：
- $x$ 是输入 prompt，从数据集 $\mathcal{D}$ 中采样
- $y$ 是学生模型 $\pi_S$ 自回归生成的完整序列
- $y_{<t}$ 是前 $t-1$ 个 token 的前缀
- $D_{\mathrm{KL}}$ 是 KL 散度

### 3.2 为什么用 On-Policy 数据？

**关键直觉**：学生模型在推理时只会遇到自己生成的 token 序列。如果训练时使用教师的序列（off-policy），学生在推理时面对自己生成的（可能有误的）前缀时，无法正确续写——这就是 **exposure bias** 问题。

形式化地说，off-policy 目标优化的是：

$$
\mathcal{L}_{\text{off-policy}} = \mathbb{E}_{y \sim \pi_T} \left[ \ell(\pi_S, \pi_T, y) \right]
$$

但推理时学生面对的分布是 $\pi_S$，两者之间的 mismatch 会导致 **compounding error**：

$$
\text{Total Error} \leq T \cdot \epsilon_{\max} \quad \text{(off-policy, 线性累积)}
$$

而 on-policy 训练直接在 $\pi_S$ 的分布上优化，避免了这种累积误差。

### 3.3 KL 散度方向的选择

在 on-policy 设定下，常见两种 KL 方向：

**Forward KL（Mode-covering）**：

$$
D_{\mathrm{KL}}(\pi_T \| \pi_S) = \mathbb{E}_{\pi_T}\left[\log \frac{\pi_T}{\pi_S}\right]
$$

- 学生倾向于覆盖教师的所有模式
- 可能导致学生分布过于分散

**Reverse KL（Mode-seeking）**：

$$
D_{\mathrm{KL}}(\pi_S \| \pi_T) = \mathbb{E}_{\pi_S}\left[\log \frac{\pi_S}{\pi_T}\right]
$$

- 学生倾向于集中在教师的高概率区域
- 更适合 on-policy 设定，因为期望在 $\pi_S$ 下计算，天然与采样分布一致

**实践中常用 Reverse KL**，因为：
1. 期望在 $\pi_S$ 下取，可以直接用学生的采样来估计
2. 鼓励学生学习教师最自信的行为模式
3. 梯度形式简洁，便于优化

### 3.4 梯度推导

对 Reverse KL 目标，关于学生参数 $\theta$ 的梯度为：

$$
\nabla_\theta \mathcal{L} = \mathbb{E}_{y \sim \pi_S} \left[ \sum_{t=1}^{T} \nabla_\theta \log \pi_S(y_t | y_{<t}, x) \cdot \left( \log \pi_S(y_t | y_{<t}, x) - \log \pi_T(y_t | y_{<t}, x) \right) \right]
$$

直觉解读：
- 当学生对某个 token 的概率**高于**教师时，梯度会**降低**该 token 的概率
- 当学生对某个 token 的概率**低于**教师时，梯度会**提升**该 token 的概率
- 这个过程在学生自己生成的序列上进行，确保了 on-policy 特性

## 4. 与 RLHF/RL 的联系

On-Policy Distillation 可以被视为一种特殊的强化学习：

$$
\mathcal{L}_{\text{on-policy distill}} = \mathbb{E}_{y \sim \pi_S} \left[ -\sum_t \log \pi_T(y_t | y_{<t}, x) \right]
$$

这等价于将 $r(y_t) = \log \pi_T(y_t | y_{<t}, x)$ 作为 token-level reward 的 RL 目标。因此：

- **On-Policy Distillation $\approx$ RL with teacher log-prob as reward**
- 可以复用 RL 的基础设施（PPO、REINFORCE 等）
- 也可以加入 baseline / advantage 来降低方差

## 5. 实践算法流程

```
输入: 教师模型 π_T, 学生模型 π_S, 数据集 D
For each iteration:
    1. 从 D 中采样一批 prompt {x_i}
    2. 用学生模型 π_S 对每个 prompt 生成响应 y_i ~ π_S(·|x_i)  [On-Policy 采样]
    3. 用教师模型 π_T 计算每个 token 的 log-prob: log π_T(y_t|y_{<t}, x)
    4. 计算蒸馏损失 L（如 Reverse KL）
    5. 反向传播更新学生参数 θ
    6. （可选）每 K 步重新采样，保持数据新鲜
```

## 6. 常见变体

### 6.1 GKD (Generalized Knowledge Distillation)
- 混合使用 on-policy 和 off-policy 数据
- 引入混合比例 $\beta$ 控制两者权重

### 6.2 On-Policy Distillation with RL Reward
- 在蒸馏损失基础上加入外部 reward 信号
- $\mathcal{L} = \mathcal{L}_{\text{distill}} - \alpha \cdot \mathbb{E}[R(y)]$

### 6.3 Sequence-Level Distillation
- 不在 token 级别匹配，而是在序列级别比较
- 使用教师的 ranking 信息（如 DPO 风格）

## 7. 总结

| 要点 | 内容 |
|------|------|
| 核心思想 | 在学生自身生成的数据上向教师学习 |
| 关键优势 | 避免 exposure bias 和 distribution shift |
| 常用目标 | Reverse KL divergence |
| 与 RL 的关系 | 等价于以教师 log-prob 为 reward 的 RL |
| 主要代价 | 需要在线采样，计算开销较大 |
