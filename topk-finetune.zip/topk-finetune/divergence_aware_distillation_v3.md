# Divergence-Aware On-Policy Distillation（v3）：单发散点两阶段方案

## 1. 核心洞察

### 1.1 一个关键事实

On-policy distillation 中，学生 $\pi_S$ 自回归生成序列 $y = (y_1, \dots, y_T)$，在每个位置计算 $\text{KL}(\pi_S(\cdot|y_{<t}) \| \pi_T(\cdot|y_{<t}))$ 作为蒸馏信号。

**核心问题**：当学生在位置 $t^*$ 采样到教师认为概率极低的 token 时，$t^*$ **之后的教师条件分布都不可信了**——因为教师是在一个"它几乎不会到达的前缀"上做条件推理。

由此得到一个简洁的推论：

> **每条序列至多只有一个发散点 $t^*$。** 在 $t^*$ 之后，教师对所有后续位置的条件分布已经失去参考价值，不存在"纠偏后再检测第二次发散"的逻辑基础——因为纠偏只修了一个 token，前 $t^*-1$ 个 token 的累积偏差仍然存在，整条轨迹已经不是教师的自然分布了。

### 1.2 为什么不存在第二个发散点？

假想在位置 $t^*$ 检测到发散后，用教师纠偏了一个 token $\hat{y}_{t^*}$，学生继续采样到 $t' > t^*$。此时：

- 前缀 $(y_1, \dots, y_{t^*-1}, \hat{y}_{t^*}, y_{t^*+1}, \dots, y_{t'-1})$ 是学生采样和教师纠偏的混合路径
- 教师对这个混合前缀的条件分布 $\pi_T(\cdot|y_{<t'})$ 本身就是在一个"教师不会自然走到的状态"上的推断
- 再去衡量 $\text{KL}(\pi_S \| \pi_T)$ 在位置 $t'$ 是否"发散"，衡量的只是两个模型在错误路径上的分歧——这个信号从一开始就是噪声

因此：**第一个发散点是唯一有意义的检测点，之后的所有位置要么截断、要么降权，不存在"再检测一次"的必要性。**

### 1.3 现有方法的盲区

| 方法 | 发散点处理 | 问题 |
|------|-----------|------|
| 标准 On-Policy KL | 均等权重所有位置 | 发散后的噪声梯度污染整体更新 |
| KL Clipping | 截断极大 KL 值 | 只压幅度，噪声方向仍在 |
| GKD | 混合 on/off-policy | 不处理前缀级联失效 |
| v1/v2 方案 | 多次纠偏 | "第二次纠偏"缺乏理论基础 |

---

## 2. 方案设计

### 2.1 整体架构：两阶段解耦

| 阶段 | 内容 | 特点 |
|------|------|------|
| **Phase 1：采样+检测** | 学生采样，检测第一个发散点 $t^*$，教师纠偏 $\hat{y}_{t^*}$，学生继续采样完 | 纯推理，no grad |
| **Phase 2：前向+训练** | 对纠偏后序列做一次完整前向，算加权 KL | 标准 FSDP 流程 |

### 2.2 Phase 1 详解

```
输入: prompt x, 学生 π_S, 教师 π_T, 阈值 τ_div, τ_surp

初始化: y_prefix = x, divergence_point = None

For t = 1, 2, ..., T:
    1. 学生采样 y_t ~ π_S(·|y_prefix)
    
    2. 若 divergence_point is None (尚未发散):
       a) 计算发散指标:
          s_t = KL(π_S(·|y_{<t}) || π_T(·|y_{<t}))
          a_t = -log π_T(y_t | y_{<t})
       b) 若 s_t > τ_div 或 a_t > τ_surp:
          - 标记 t 为发散点 t*
          - 教师纠偏采样: ŷ_t ~ π_T(·|y_{<t})
          - 后续不再检测发散，学生继续采样至结束
          - 用 ŷ_t 替换 y_t 继续生成
    
    3. 将 y_t (或 ŷ_t) 拼入序列

输出: 纠偏后序列 ỹ, 发散点位置 t* (若无发散则为 None)
```

### 2.3 序列结构

**情况 1：无发散**（学生整条轨迹都在教师附近）

```
位置:    1    2    3    4    5    6    7    ...
token:  y_1  y_2  y_3  y_4  y_5  y_6  y_7  ...
类型:    A    A    A    A    A    A    A   ...
权重:    1    1    1    1    1    1    1   ...
```

等同于标准 on-policy KL，无任何修改。

**情况 2：在位置 3 发散**

```
位置:    1    2    3(orig)  3(corr)  4    5    6    7   ...
token:  y_1  y_2   y_3      ŷ_3     y_4  y_5  y_6  y_7  ...
类型:    A    A     B        C       D    D    D    D   ...
```

- **类型 A**：发散前的正常位置（$t < t^*$）
- **类型 B**：发散点，学生原始 token
- **类型 C**：纠偏 token，教师重新采样
- **类型 D**：纠偏后学生继续采样的位置（$t > t^*$），不再检测发散

> **注意**：类型 B 和 C 共享位置 $t^*$，序列在此处多一个 token。完整序列长度为 $T + \mathbb{1}[t^* \text{ exists}]$。由于每条序列至多一个发散点，序列长度至多 +1。

### 2.4 Phase 2 详解

将纠偏后序列整体输入学生和教师，一次前向拿到所有位置的 logits，然后按类型加权计算 KL 损失。

```python
# 学生前向 (标准 FSDP)
s_logits = student(corrected_seq).logits      # [1, S, V]

# 教师前向 (no grad)
with torch.no_grad():
    t_logits = teacher(corrected_seq).logits  # [1, S, V]

# 计算 reverse KL
s_logp = log_softmax(s_logits, dim=-1)
t_logp = log_softmax(t_logits, dim=-1)
s_p    = softmax(s_logits, dim=-1)
kl_per_pos = (s_p * (s_logp - t_logp)).sum(dim=-1)  # [S]

# 按位置类型加权
loss = (weights * kl_per_pos).sum() / weights.sum()
```

---

## 3. 权重设计

### 3.1 四种类型的权重

**类型 A：发散前正常位置**（$t < t^*$）

$$w_t^{(A)} = 1$$

前缀完全由学生自己采样，on-policy 纯度最高，KL 信号质量最好。

**类型 B：发散点**（学生在位置 $t^*$ 的原始 token）

$$w_t^{(B)} = \gamma \cdot \text{sg}\left(\frac{\min(s_{t^*}, s_{\max})}{\min(s_{t^*}, s_{\max}) + \beta}\right)$$

- $\gamma \in (0,1)$：全局缩放因子
- $\beta > 0$：饱和速度
- $s_{\max}$：KL 截断上界
- $\text{sg}(\cdot)$：stop gradient
- **设计直觉**：发散点 KL 值极大但方向不可靠（$\log \pi_T \to -\infty$），需要软抑制。$s_{t^*}$ 越大 → 权重越低 → 信号越不可信。

**类型 C：纠偏 token**（教师在位置 $t^*$ 的重新采样）

$$w_t^{(C)} = 1 + \lambda \cdot \max\left(0,\; \log \pi_T(\hat{y}_{t^*} | y_{<t^*}) - c\right)$$

- $c$：置信度阈值
- $\lambda$：增强幅度
- **设计直觉**：纠偏 token 是最有价值的学习信号——"在这种前缀下，你应该选什么"。教师越自信的纠偏，权重越高。基础权重 1 保证不低于正常位置。

**类型 D：纠偏后后续位置**（$t > t^*$，学生基于纠偏前缀继续采样）

$$w_t^{(D)} = \alpha \cdot \exp\left(-\eta \cdot (t - t^*)\right) + (1 - \alpha)$$

- $\alpha \in (0,1)$：衰减幅度
- $\eta > 0$：衰减速率
- **设计直觉**：纠偏只修了一个 token，$y_1, \dots, y_{t^*-1}$ 的累积偏差仍在，后续位置的 KL 信号质量从"不可靠"逐步"恢复正常"。指数衰减 + 基础权重 $(1-\alpha)$ 保证最低学习信号不致为零。

### 3.2 权重曲线可视化

```
权重
 1 +--C--+
   |      \
   |       \---D---~~--- (指数衰减趋近 1-α)
   |                           
γ  +--B--+                    
   |                             
 0 +-----+--------+--------+----→ 位置
        t*       t*+1     t*+k

   ←A→  ←B→ ←C→  ←---D---→
  (发散前)(发散)(纠偏)(纠偏后衰减)
```

### 3.3 无发散时退化为标准方法

当学生整条序列都没有发散时，所有位置都是类型 A，权重全为 1：

$$\mathcal{L}_{\text{DA}} \xrightarrow[\text{无发散}]{} \mathcal{L}_{\text{standard on-policy KL}}$$

当阈值 $\tau \to \infty$ 时，永远不会触发发散检测，同样退化：

$$\mathcal{L}_{\text{DA}} \xrightarrow[\tau \to \infty]{} \mathcal{L}_{\text{standard on-policy KL}}$$

**标准方法是本方案的特例，理论上不会劣于基线。**

---

## 4. 完整算法流程

```
================================================================================
Divergence-Aware On-Policy Distillation (v3) — 单发散点两阶段方案
================================================================================

输入: 
  教师模型 π_T (frozen), 学生模型 π_S (trainable)
  数据集 D, 阈值 τ_div, τ_surp
  权重超参 γ, β, α, λ, η, c, s_max

================================================================================
Phase 1: 采样 + 单次发散检测 + 纠偏  (no grad, 可用推理引擎)
================================================================================

For each prompt x in batch:
    1. y_prefix = x, div_point = None
    2. For t = 1 to T:
        a) y_t ~ π_S(·|y_prefix)
        b) If div_point is None:
            计算 s_t, a_t
            If s_t > τ_div or a_t > τ_surp:
                记录: t* = t, orig_token = y_t, s_{t*} = s_t
                ŷ_t ~ π_T(·|y_prefix)       # 教师纠偏
                记录: corr_token = ŷ_t, teacher_logp
                y_prefix.append(ŷ_t)         # 用纠偏 token 继续
                div_point = t*               # 标记已发散，后续不再检测
           Else:
                y_prefix.append(y_t)
    3. 输出: 纠偏后序列 ỹ, {t*, s_{t*}, ŷ_{t*}, teacher_logp} (若有发散)

================================================================================
Phase 2: 前向 + 加权 KL 损失  (标准 FSDP 流程)
================================================================================

1. 学生 + 教师分别对纠偏后序列做一次完整前向, 得到逐位置 logits
2. 计算逐位置 KL 散度
3. 根据发散点信息计算逐位置权重 w_t (A/B/C/D)
4. loss = (Σ w_t · kl_t) / (Σ w_t)
5. 反后向 + 更新参数

================================================================================
```

---

## 5. PyTorch 伪代码

```python
import torch
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Optional, Tuple, List


@dataclass
class DivergenceInfo:
    """单发散点信息"""
    position: int           # 发散位置 t*
    kl_score: float         # 发散时的 KL 散度
    orig_token: int         # 学生原始 token
    corr_token: int         # 教师纠偏 token
    teacher_logp: float     # 教师对纠偏 token 的 log prob


def phase1_sample_and_correct(
    student, teacher, prompt_ids,
    tau_div=5.0, tau_surp=10.0,
    max_seq_len=512
) -> Tuple[List[int], Optional[DivergenceInfo]]:
    """
    Phase 1: 采样 + 单次发散检测 + 纠偏
    返回纠偏后序列和发散点信息（若无发散则为 None）
    """
    seq = list(prompt_ids)
    prefix = list(prompt_ids)
    div_info = None
    already_diverged = False

    with torch.no_grad():
        for t in range(max_seq_len):
            # 学生采样
            s_logits = student(torch.tensor([prefix])).logits[:, -1, :]
            s_probs = F.softmax(s_logits, dim=-1)
            y_t = torch.multinomial(s_probs, num_samples=1).item()

            # 仅在未发散时检测
            if not already_diverged:
                t_logits = teacher(torch.tensor([prefix])).logits[:, -1, :]
                t_log_probs = F.log_softmax(t_logits, dim=-1)
                t_probs = F.softmax(t_logits, dim=-1)

                # 发散指标
                s_t = F.kl_div(
                    t_log_probs, s_probs,
                    log_target=False, reduction='sum'
                ).item()
                a_t = -t_log_probs[0, y_t].item()

                if s_t > tau_div or a_t > tau_surp:
                    # 教师纠偏
                    y_t_corrected = torch.multinomial(t_probs, num_samples=1).item()
                    teacher_logp = t_log_probs[0, y_t_corrected].item()

                    # 记录发散信息
                    div_info = DivergenceInfo(
                        position=t,
                        kl_score=s_t,
                        orig_token=y_t,
                        corr_token=y_t_corrected,
                        teacher_logp=teacher_logp,
                    )

                    # 序列中保留原始 token (类型B) + 插入纠偏 token (类型C)
                    seq.append(y_t)
                    seq.append(y_t_corrected)
                    prefix.append(y_t_corrected)  # 用纠偏 token 继续
                    already_diverged = True
                    continue

            # 正常追加
            seq.append(y_t)
            prefix.append(y_t)

    return seq, div_info


def compute_weights(seq_len: int, prompt_len: int, 
                    div_info: Optional[DivergenceInfo],
                    gamma=0.3, beta=1.0, alpha=0.7,
                    lam=1.0, eta=0.1, c=-2.0, s_max=20.0):
    """
    根据发散点信息计算逐位置权重
    """
    resp_len = seq_len - prompt_len
    weights = torch.ones(resp_len)

    if div_info is None:
        # 无发散：所有位置权重为 1
        return weights

    t_star = div_info.position  # 发散位置（response 内的偏移）

    # 类型 B: 发散点（学生原始 token）
    # 注意：因为插入了纠偏 token，发散点在序列中的下标是 t_star
    s_clamped = min(div_info.kl_score, s_max)
    weights[t_star] = gamma * (s_clamped / (s_clamped + beta))

    # 类型 C: 纠偏 token（序列中 t_star + 1 的位置）
    bonus = max(0.0, div_info.teacher_logp - c)
    weights[t_star + 1] = 1.0 + lam * bonus

    # 类型 D: 纠偏后后续位置（t_star + 2 起）
    for t in range(t_star + 2, resp_len):
        dist = t - (t_star + 1)  # 到纠偏点的距离
        weights[t] = alpha * torch.exp(torch.tensor(-eta * dist)).item() + (1 - alpha)

    # 类型 A: 发散前位置权重已经为 1，无需修改

    return weights.detach()  # stop gradient on weights


def phase2_compute_loss(student, teacher, seq, div_info,
                        prompt_len, pad_token_id=0,
                        gamma=0.3, beta=1.0, alpha=0.7,
                        lam=1.0, eta=0.1, c=-2.0, s_max=20.0):
    """
    Phase 2: 标准 teacher-forcing 前向 + 加权 KL 损失
    完全兼容 FSDP
    """
    device = next(student.parameters()).device

    # 一次前向拿到所有 logits
    input_ids = torch.tensor([seq], device=device)
    s_logits = student(input_ids).logits[:, prompt_len - 1:-1, :]  # shift
    with torch.no_grad():
        t_logits = teacher(input_ids).logits[:, prompt_len - 1:-1, :]

    # 逐位置 reverse KL
    s_logp = F.log_softmax(s_logits, dim=-1)
    t_logp = F.log_softmax(t_logits, dim=-1)
    s_p = F.softmax(s_logits, dim=-1)
    kl = (s_p * (s_logp - t_logp)).sum(dim=-1).squeeze(0)  # [resp_len]

    # 计算权重
    weights = compute_weights(
        len(seq), prompt_len, div_info,
        gamma, beta, alpha, lam, eta, c, s_max
    ).to(device)

    # 加权损失
    loss = (weights * kl).sum() / weights.sum()
    return loss


# ============================================================
# 训练主循环
# ============================================================

def train_iteration(student, teacher, dataloader, optimizer, **kwargs):
    """一个完整的训练迭代"""

    batch_seqs = []
    batch_div_infos = []
    prompt_len = None

    # ========== Phase 1: 采样 + 纠偏 (no grad) ==========
    student.eval()
    teacher.eval()
    with torch.no_grad():
        for prompt in dataloader:
            seq, div_info = phase1_sample_and_correct(
                student, teacher, prompt, **kwargs
            )
            batch_seqs.append(seq)
            batch_div_infos.append(div_info)
            if prompt_len is None:
                prompt_len = len(prompt)

    # ========== Phase 2: 前向 + 损失 + 反后向 ==========
    student.train()
    total_loss = 0.0
    for seq, div_info in zip(batch_seqs, batch_div_infos):
        loss = phase2_compute_loss(
            student, teacher, seq, div_info,
            prompt_len, **kwargs
        )
        total_loss += loss

    total_loss /= len(batch_seqs)
    optimizer.zero_grad()
    total_loss.backward()
    optimizer.step()

    return total_loss.item()
```

---

## 6. 简化版本：纯截断（无纠偏）

如果想先以最小工程成本验证核心假设，可以先不做纠偏，**发散后直接截断**：

### 6.1 Phase 1（简化）

```
学生自回归采样，每步检测发散
若发散: 截断，只保留 y[1:t*]
若全程无发散: 保留完整序列
```

### 6.2 权重（简化）

只有两种权重：

$$w_t = \begin{cases} 1 & t < t^* \quad \text{(发散前，正常位置)} \\ \gamma \cdot \dfrac{\min(s_{t^*}, s_{\max})}{\min(s_{t^*}, s_{\max}) + \beta} & t = t^* \quad \text{(发散点，软抑制)} \\ \end{cases}$$

无类型 C 和 D。发散后直接截断，不参与损失计算。

### 6.3 简化版 vs 完整版

| 维度 | 简化版（截断） | 完整版（纠偏+衰减） |
|------|---------------|-------------------|
| 工程复杂度 | 最低 | 中等 |
| 发散后信号 | 完全丢弃 | 纠偏恢复 + 衰减保留 |
| 序列长度 | 变短 | 原长度 + 1 |
| 理论风险 | 学生对长序列能力不足 | 无 |
| 验证价值 | 可验证"发散后 KL 有害" | 可验证"纠偏信号有价值" |

**推荐的实验路径**：先实现简化版 → 验证核心假设 → 再升级完整版。

---

## 7. 理论分析

### 7.1 为什么只检测一次发散？

设学生在位置 $t^*$ 第一次显著偏离教师，即 $\pi_T(y_{t^*}|y_{<t^*}) \approx 0$。

对于任意 $t > t^*$：

$$\pi_T(\cdot|y_{<t}) = \pi_T(\cdot|y_{<t^*}, y_{t^*}, \dots, y_{t-1})$$

其中 $y_{t^*}$ 是教师几乎不会采样的 token，后续 $(y_{t^*+1}, \dots, y_{t-1})$ 是学生在异常前缀上的采样。因此：

$$\pi_T(\cdot|y_{<t}) \text{ 是模型在 OOD 输入上的外推，缺乏统计意义}$$

即使纠偏了 $y_{t^*}$ 为 $\hat{y}_{t^*}$，前缀 $(y_1, \dots, y_{t^*-1})$ 仍然可能有累积偏差（学生和教师的分布在 $1$ 到 $t^*-1$ 的位置上并非完全一致）。在纠偏后的混合前缀上，教师的条件分布比纯学生前缀上好，但仍然不是教师自然分布下的条件估计。

因此：
- 位置 $> t^*$ 的 KL 信号**质量低于**位置 $< t^*$ 的信号
- 用指数衰减权重（类型 D）处理比均等权重更合理
- 但再去检测"第二次发散"没有意义——因为从第一次发散起，我们就已经知道后续信号可信度递降

### 7.2 梯度方差缩减

标准 on-policy KL 的梯度：

$$\nabla_\theta \mathcal{L}_{\text{std}} = \sum_{t=1}^{T} \nabla_\theta \log \pi_S(y_t|y_{<t}) \cdot \left(\log \pi_S(y_t|y_{<t}) - \log \pi_T(y_t|y_{<t})\right)$$

发散点 $t^*$ 处 $\log \pi_T(y_{t^*}|y_{<t^*}) \to -\infty$，梯度极不稳定。

本方案通过：
- 类型 B 的软抑制：$w^{(B)} \to 0$（当 $s_{t^*} \to \infty$），压制住发散点的噪声梯度
- 类型 D 的衰减：$w^{(D)} < 1$，减少不可靠位置的梯度贡献

有效降低梯度方差，特别是在弱学生 + 长序列场景下。

### 7.3 与 DAgger 的联系

从 RL 视角（on-policy distillation $\approx$ RL with teacher log-prob as reward）：

- 标准方法：学生偏离后继续接收无意义 reward ‒ 类似于在错误状态上用错误的 value function 指导
- 本方法：在第一个偏离点执行一次 expert intervention（教师纠偏），之后继续但降低信任度 ‒ 类似于 **单次 DAgger 纠正**

与 DAgger 的关键区别：DAgger 可以在线反复纠正，而本方法只纠正一次。原因正是上述分析——自回归语言模型中，第一次发散后的整条轨迹都已不可信，多次纠正缺乏理论支撑。

---

## 8. FSDP 工程实现

### 8.1 Rollout Buffer 解耦架构（推荐）

```
┌──────────────────────┐
│   Rollout Worker     │
│  (Phase 1: 采样)     │
│  - 学生采样 + 检测   │
│  - 教师纠偏 (1次)    │
│  - 可用推理引擎      │
│  - no grad           │
└──────────┬───────────┘
           │ 纠偏序列 + DivergenceInfo
           ▼
┌──────────────────────┐
│   Training Buffer    │
│  (共享内存 / Redis)  │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────┐
│   Training Worker    │
│  (Phase 2: 标准 FSDP)│
│  - 批量前向反后向     │
│  - 一次前向拿全部 logits│
│  - 加权 KL 损失      │
│  - 可多卡 FSDP       │
└──────────────────────┘
```

### 8.2 批量化处理

每条序列至多一个发散点，纠偏后长度为 $T$ 或 $T+1$。两种处理方式：

**方式 1：统一 pad 到 $T+1$**

对于无发散的序列，在末尾 pad 一个 token（权重设为 0），使所有序列等长：

```python
# 对齐长度
max_len = T + 1  # 最长可能
for i in range(batch_size):
    if batch_div_infos[i] is None:
        # 无发散：末尾 pad，权重为 0
        batch_seqs[i].append(pad_id)
        batch_weights[i].append(0.0)
```

**方式 2：按是否有发散分组**

无发散的序列等长为 $T$，有发散的等长为 $T+1$，分两组处理：

```python
no_div = [(s, w) for s, w, d in zip(seqs, weights, div_infos) if d is None]
has_div = [(s, w) for s, w, d in zip(seqs, weights, div_infos) if d is not None]

loss1 = compute_batch_loss(student, teacher, no_div)
loss2 = compute_batch_loss(student, teacher, has_div)
loss = (loss1 + loss2) / 2
```

### 8.3 Phase 1 教师推理的省略

Phase 1 中，教师的前向仅在发散检测时需要。一旦检测到发散，后续位置不再需要教师推理。这意味着：

- 教师前向最多只执行到位置 $t^*$
- 若 $t^*$ 较早（如序列前 20%），教师计算量可节省 80%
- 若全程无发散，教师需要做完整前向（但此情况就是标准 on-policy，无需特殊处理）

---

## 9. 动态阈值策略

### 9.1 统计自适应阈值

用 EMA 跟踪 KL 散度分布：

$$\mu_{\text{KL}}^{(k)} = (1-\rho) \cdot \mu_{\text{KL}}^{(k-1)} + \rho \cdot \bar{s}_k$$
$$\sigma_{\text{KL}}^{(k)} = (1-\rho) \cdot \sigma_{\text{KL}}^{(k-1)} + \rho \cdot \text{std}(s_t^{(k)})$$

$$\tau_{\text{div}}(k) = \mu_{\text{KL}}^{(k)} + n \cdot \sigma_{\text{KL}}^{(k)}$$

训练早期 $\sigma$ 大 → 阈值高 → 容忍更多发散；训练后期 $\sigma$ 小 → 阈值低 → 更精细检测。

### 9.2 基于 teacher surprisal 的辅助判据

单独的 KL 散度可能漏检某些情况（如整体分布接近，但学生选中了教师概率极低的某个 token）。用 teacher surprisal 作补充：

$$a_t = -\log \pi_T(y_t|y_{<t})$$

当 $a_t > \tau_{\text{surp}}$ 时也判为发散，即使 KL 散度未超阈值。两者是 OR 关系，覆盖更全面。

---

## 10. 实验设计

### 10.1 基线

| 编号 | 方法 | 说明 |
|------|------|------|
| B1 | Standard On-Policy KL | 均等权重，无发散处理 |
| B2 | KL Clipping | 对 KL 值截断上界 |
| B3 | DA-Truncate | 发散后直接截断（简化版） |
| B4 | DA-Correct | 发散检测 + 单次纠偏 + 自适应权重（完整版） |

### 10.2 核心实验

1. **假设验证**：B3 vs B1 — 发散后 KL 是否有害？
2. **纠偏增益**：B4 vs B3 — 纠偏 token 是否有额外价值？
3. **权重消融**：B4 分别去掉类型 B/C/D 权重
4. **阈值扫描**：$\tau_{\text{div}} \in \{1, 2, 3, 5, 10, 20\}$
5. **长度分析**：不同生成长度（128/256/512/1024）下的效果差异

### 10.3 分析指标

| 指标 | 说明 |
|------|------|
| Divergence Rate | 每序列是否发散、发散位置分布 |
| KL Profile | 训练过程中各位置 KL 均值曲线 |
| Gradient Norm | 验证去噪效果 |
| Teacher FLOPs | 教师计算量对比（截断可省算力） |
| Generation Quality | BLEU/ROUGE/Win Rate |
| Sequence Length Dist | 训练中序列长度分布（简化版会变短） |

### 10.4 预期结果

1. B3 > B1：验证发散后 KL 有害
2. B4 > B3：验证纠偏信号有价值
3. 类型 C 权重（纠偏 token 增强）贡献最大
4. Divergence Rate 随训练下降（学生越来越不偏离教师）
5. 长序列收益 > 短序列（长序列更容易发散，改进空间更大）
6. B3 的 Teacher FLOPs 显著低于 B1

---

## 11. 总结

| 要点 | 内容 |
|------|------|
| **核心洞察** | 第一个发散点后，教师条件分布不可信；不存在有意义的"第二次发散" |
| **方案简化** | 每条序列至多一个发散点，一次检测、一次纠偏 |
| **权重类型** | A（正常）+ B（发散点软抑制）+ C（纠偏增强）+ D（纠偏后衰减） |
| **工程友好** | Phase 1 纯推理 / Phase 2 标准 FSDP；序列长度至多 +1，批量化简单 |
| **理论保证** | 无发散时退化为标准方法，不会劣于基线 |
| **推荐路径** | 简化版（截断）→ 验证假设 → 完整版（纠偏） |

**一句话总结**：基于"第一个发散点后教师信号即失效"的洞察，每条序列只检测一次发散、只纠偏一次，用四类自适应权重处理不同位置的 KL 信号可信度，工程上两阶段解耦、FSDP 友好，理论上退化为标准方法。