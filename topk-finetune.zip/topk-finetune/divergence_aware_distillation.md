# Divergence-Aware On-Policy Distillation：基于发散点检测的自适应蒸馏框架

## 1. 核心问题

### 1.1 问题定义

在 On-Policy Distillation 中，学生模型 $\pi_S$ 自回归生成序列 $y = (y_1, y_2, \dots, y_T)$，在每个位置 $t$ 计算 KL 散度作为蒸馏信号。现有方法假设**所有位置的 KL 散度都提供有意义的梯度信号**，但实际中存在一个关键问题：

> **一旦学生在某个位置 $t^*$ 产生了严重偏离教师的 token（即 $D_{\mathrm{KL}}(\pi_S(\cdot|x, y_{<t^*}) \| \pi_T(\cdot|x, y_{<t^*}))$ 极大），那么位置 $t^*$ 之后的所有 KL 信号都变得不可靠甚至有害。**

### 1.2 为什么后续 KL 信号失效？

这背后有三层原因：

**（1）条件分布的级联崩溃**

自回归模型的条件分布依赖于前缀：$\pi_\theta(y_t | y_{<t}, x)$。当 $y_{t^*} \notin \text{supp}(\pi_T(\cdot|x, y_{<t^*}))$ 或 $\pi_T(y_{t^*}|y_{<t^*}, x) \approx 0$ 时，即学生采样到了教师认为概率极低的 token，前缀序列 $y_{<t^*+1}$ 已经偏离了教师的分布。此时：

- 教师 $\pi_T(\cdot|x, y_{<t^*+1})$ 是在一个"教师几乎不会到达的状态"上做条件推断
- 教师在这个异常状态下的输出分布可能没有意义——它从未在这种前缀上被训练过
- 后续 $t > t^*$ 的 KL 散度衡量的是"两个模型在一条错误路径上的分歧"，而非"学生应该如何纠正"

**（2）噪声梯度放大**

形式化地，设在发散点 $t^*$，学生采样到 token $y_{t^*}$ 使得 $\pi_T(y_{t^*}|y_{<t^*}, x) \to 0$，则：

$$\nabla_\theta D_{\mathrm{KL}}(t^*) = \nabla_\theta \log \pi_S(y_{t^*}|y_{<t^*}, x) \cdot \left(\log \pi_S(y_{t^*}|y_{<t^*}, x) - \log \pi_T(y_{t^*}|y_{<t^*}, x)\right)$$

其中 $\log \pi_T(y_{t^*}|y_{<t^*}, x) \to -\infty$，导致梯度幅度极大且方向不稳定。更关键的是，后续位置的梯度：

$$\nabla_\theta D_{\mathrm{KL}}(t^*+1) = \nabla_\theta \log \pi_S(y_{t^*+1}|y_{<t^*+1}, x) \cdot \left(\log \pi_S(y_{t^*+1}|y_{<t^*+1}, x) - \log \pi_T(y_{t^*+1}|y_{<t^*+1}, x)\right)$$

由于 $y_{<t^*+1}$ 是异常前缀，$\pi_T(y_{t^*+1}|y_{<t^*+1}, x)$ 本身就是无意义的信号，其与 $\pi_S$ 的差异无法提供有效的学习方向。

**（3）计算浪费**

对教师模型的前向传播是蒸馏的主要计算瓶颈。在发散点之后继续让教师做条件推理，不仅梯度信号有害，还白白浪费了 GPU 算力。

### 1.3 现有方法的盲区

| 方法 | 发散点处理 | 问题 |
|------|-----------|------|
| 标准 On-Policy KL | 均等权重所有位置 | 发散后的噪声梯度污染整体更新 |
| GKD（混合 on/off） | 不处理 | 仅缓解数据新鲜度，未解决级联发散 |
| Token-level KL clip | 截断极大 KL 值 | 只压制了幅度，未消除方向上的噪声 |
| Sequence-level distillation | 放弃 token 级匹配 | 丢失了 token 级精确对齐信息 |

---

## 2. Divergence-Aware Distillation 框架

### 2.1 核心思想

提出一个三阶段机制：

1. **Divergence Detection**：在自回归采样过程中实时检测发散点 $t^*$
2. **Teacher-Guided Resampling**：在发散点处，用教师信号引导学生重新采样，恢复到正确路径
3. **Adaptive KL Weighting**：对发散点前、发散点处、重采样后的 KL 信号施以不同权重策略

关键洞察：**我们不是简单丢弃发散后的信号，而是在发散点处进行"纠偏采样"，使得后续 token 在正确的前缀上继续生成，从而恢复后续 KL 信号的有效性。**

### 2.2 形式化定义

#### 2.2.1 发散点检测（Divergence Point Detection）

对每个生成位置 $t$，定义 token 级别的发散分数：

$$s_t = D_{\mathrm{KL}}\left(\pi_S(\cdot|x, y_{<t}) \;\|\; \pi_T(\cdot|x, y_{<t})\right)$$

同时定义教师对学生已选 token 的"惊讶度"：

$$a_t = -\log \pi_T(y_t | y_{<t}, x)$$

**发散点判定**：位置 $t$ 为发散点，当且仅当：

$$t^* = \min \left\{ t : s_t > \tau_{\text{div}} \;\text{or}\; a_t > \tau_{\text{surp}} \right\}$$

其中 $\tau_{\text{div}}$ 和 $\tau_{\text{surp}}$ 是发散和惊讶度阈值。

> **直觉**：$s_t$ 衡量两个分布在位置 $t$ 的整体分歧程度；$a_t$ 补充衡量教师对学生具体选择的"意外程度"。两者结合可以更稳健地捕获发散。

#### 2.2.2 教师引导重采样（Teacher-Guided Resampling）

在检测到发散点 $t^*$ 后，不是继续在错误前缀上生成，而是执行以下重采样：

**Step 1：教师纠正采样**

从教师的条件分布中采样替换 token：

$$\hat{y}_{t^*} \sim \pi_T(\cdot | x, y_{<t^*})$$

**Step 2：学生接力生成**

以纠正后的前缀继续由学生模型采样：

$$y_t \sim \pi_S(\cdot | x, \hat{y}_{<t^*}, y_{<t}) \quad \text{for } t > t^*$$

这样后续生成的前缀始终是"教师认可的路径"，保证了后续 KL 信号的有效性。

**Step 3：记录轨迹片段**

整条生成轨迹被分割为多个片段（segments）：

$$\text{trajectory} = \underbrace{(y_1, \dots, y_{t^*-1})}_{\text{Segment 0: 正常段}} \;\cup\; \underbrace{(y_{t^*})}_{\text{Segment 0 尾：发散点}} \;\cup\; \underbrace{(\hat{y}_{t^*})}_{\text{纠偏 token}} \;\cup\; \underbrace{(y_{t^*+1}, \dots)}_{\text{Segment 1: 纠偏后续段}}$$

#### 2.2.3 分段自适应 KL 权重（Segment-Adaptive KL Weighting）

不同位置的 KL 信号应有不同的学习价值：

**类型 A：正常位置**（$t < t^*$，未发散）

$$w_t^{(A)} = 1$$

正常位置的 KL 散度是高质量的蒸馏信号，给予标准权重。

**类型 B：发散点**（$t = t^*$）

$$w_t^{(B)} = \gamma \cdot \text{stop\_grad}\left(\frac{s_t}{s_t + \beta}\right)$$

其中 $\gamma \in (0, 1)$ 是缩放因子，$\beta > 0$ 是平滑参数。使用 stop_grad 避免权重本身参与梯度计算。对发散点的 KL 信号进行软抑制——信号越大，置信度越低，权重越小。

**类型 C：纠偏位置**（教师重采样点 $t^*$ 的替换 token）

$$w_t^{(C)} = \alpha \cdot \left(1 + \lambda \cdot \log \pi_T(\hat{y}_{t^*}|y_{<t^*}, x)\right)$$

纠偏位置是学生**最应该学习**的地方——它告诉学生"在这种前缀下，你应该选择什么"。我们用教师对该 token 的 log-prob 来调节权重：教师越自信的纠偏，权重越高。

**类型 D：纠偏后后续位置**（$t > t^*$，基于纠偏前缀生成）

$$w_t^{(D)} = \alpha \cdot \exp\left(-\eta \cdot (t - t^*)\right)$$

纠偏后的后续位置虽然前缀已恢复正确，但随着距离发散点越远，轨迹与纯学生采样的偏差越大。用指数衰减来反映这种"信任递减"效应。$\alpha$ 是衰减基础权重，$\eta$ 控制衰减速率。

### 2.3 完整目标函数

综合以上设计，Divergence-Aware 的蒸馏目标为：

$$\mathcal{L}_{\text{DA}} = \mathbb{E}_{y \sim \pi_S} \left[ \sum_{t=1}^{T} w_t \cdot D_{\mathrm{KL}}\left(\pi_S(\cdot|x, y_{<t}) \;\|\; \pi_T(\cdot|x, y_{<t})\right) \right]$$

其中 $w_t$ 由上述分段策略决定。

等价地，展开为梯度形式：

$$\nabla_\theta \mathcal{L}_{\text{DA}} = \mathbb{E}_{y \sim \pi_S} \left[ \sum_{t=1}^{T} w_t \cdot \nabla_\theta \log \pi_S(y_t|x, y_{<t}) \cdot \left(\log \pi_S(y_t|x, y_{<t}) - \log \pi_T(y_t|x, y_{<t})\right) \right]$$

---

## 3. 算法流程

```
输入: 教师模型 π_T, 学生模型 π_S, 数据集 D, 
      阈值 τ_div, τ_surp, 超参数 γ, β, α, λ, η

For each training iteration:
    1. 从 D 中采样一批 prompt {x_i}
    
    2. 【On-Policy 采样 + 发散检测 + 重采样】
       For each prompt x_i:
           a) 用 π_S 自回归生成，每步同时计算:
              - s_t = KL(π_S(·|x, y_{<t}) || π_T(·|x, y_{<t}))
              - a_t = -log π_T(y_t|y_{<t}, x)
           b) 若 s_t > τ_div 或 a_t > τ_surp:
              - 标记 t 为发散点 t^*
              - 从 π_T(·|x, y_{<t^*}) 采样纠偏 token ŷ_{t^*}
              - 以纠偏前缀 (y_{<t^*}, ŷ_{t^*}) 继续 π_S 采样
              - 可支持多次发散检测（多次纠偏）
           c) 否则继续正常采样
    
    3. 【计算分段自适应权重】
       根据每个 token 的类型 (A/B/C/D) 计算权重 w_t
    
    4. 【计算加权蒸馏损失】
       L_DA = Σ_t w_t · KL(π_S(·|x, y_{<t}) || π_T(·|x, y_{<t}))
    
    5. 反向传播更新 θ
```

### 3.1 伪代码实现

```python
import torch
import torch.nn.functional as F

def divergence_aware_distillation(
    student, teacher, prompts, 
    tau_div=5.0, tau_surp=10.0,
    gamma=0.3, beta=1.0, alpha=0.7, lam=1.0, eta=0.1,
    max_divergences_per_seq=3
):
    """
    Divergence-Aware On-Policy Distillation
    """
    batch_size = len(prompts)
    total_loss = 0.0
    
    for x in prompts:
        # ===== Step 1: On-policy 采样 + 发散检测 + 重采样 =====
        tokens = []
        weights = []
        segment_ids = []  # 标记每个 token 属于哪个 segment
        is_correction = []  # 标记是否为纠偏 token
        divergence_points = []
        
        y_prefix = x  # 初始前缀就是 prompt
        segment_id = 0
        n_divergences = 0
        
        for t in range(max_seq_len):
            # 学生采样
            s_logits = student(y_prefix).logits[:, -1, :]  # 最后一个位置的 logits
            s_probs = F.softmax(s_logits, dim=-1)
            y_t = torch.multinomial(s_probs, num_samples=1)  # 采样
            
            # 教师前向（共享前缀）
            with torch.no_grad():
                t_logits = teacher(y_prefix).logits[:, -1, :]
                t_probs = F.softmax(t_logits, dim=-1)
            
            # 计算发散分数
            s_t = F.kl_div(
                t_logits.log_softmax(-1), 
                s_probs.log(), 
                log_target=False, 
                reduction='sum'
            )  # reverse KL
            a_t = -F.log_softmax(t_logits, dim=-1).gather(-1, y_t.unsqueeze(-1)).item()
            
            # ===== 发散检测 =====
            if (s_t.item() > tau_div or a_t > tau_surp) and n_divergences < max_divergences_per_seq:
                # 标记发散点
                divergence_points.append(t)
                n_divergences += 1
                
                # 记录发散位置的 KL（类型 B 权重）
                w_B = gamma * (s_t.item() / (s_t.item() + beta))
                tokens.append(y_t)
                weights.append(w_B)
                segment_ids.append(segment_id)
                is_correction.append(False)
                
                # 教师引导重采样
                y_t_corrected = torch.multinomial(t_probs, num_samples=1)
                
                # 记录纠偏位置（类型 C 权重）
                t_log_prob = F.log_softmax(t_logits, dim=-1).gather(-1, y_t_corrected.unsqueeze(-1)).item()
                w_C = alpha * (1 + lam * t_log_prob)
                tokens.append(y_t_corrected)
                weights.append(w_C)
                segment_ids.append(segment_id)
                is_correction.append(True)
                
                # 更新前缀为纠偏后的序列
                y_prefix = torch.cat([y_prefix, y_t_corrected.unsqueeze(0)], dim=-1)
                segment_id += 1  # 进入新 segment
            else:
                # 正常位置（类型 A 或 D 权重）
                if len(divergence_points) == 0:
                    w_t = 1.0  # 类型 A
                else:
                    last_div = divergence_points[-1]
                    w_t = alpha * torch.exp(torch.tensor(-eta * (t - last_div)))  # 类型 D
                
                tokens.append(y_t)
                weights.append(w_t)
                segment_ids.append(segment_id)
                is_correction.append(False)
                
                y_prefix = torch.cat([y_prefix, y_t.unsqueeze(0)], dim=-1)
        
        # ===== Step 2: 计算加权蒸馏损失 =====
        for t, (tok, w, is_corr) in enumerate(zip(tokens, weights, is_correction)):
            if is_corr:
                # 纠偏 token：计算 π_S(ŷ_t|...) 与 π_T(ŷ_t|...) 的 KL
                # 需要用学生模型在纠偏前缀上重新前向
                s_log_prob = ...  # 学生在纠偏前缀上的 log prob
                t_log_prob = ...  # 教师在纠偏前缀上的 log prob
                kl_t = ... 
            else:
                # 正常 token：用已计算的 KL
                kl_t = s_t  # 已在采样时计算
            
            total_loss += w * kl_t
    
    total_loss /= batch_size
    return total_loss
```

---

## 4. 理论分析

### 4.1 与标准 On-Policy KL 的关系

当 $\tau_{\text{div}} \to \infty$, $\tau_{\text{surp}} \to \infty$ 时，永远不会触发发散检测，此时：

$$\mathcal{L}_{\text{DA}} \xrightarrow[\tau \to \infty]{} \mathcal{L}_{\text{on-policy KL}}$$

即标准 On-Policy KL 是本框架的特例。

### 4.2 梯度方差分析

标准 On-Policy KL 的梯度方差来源：
1. 采样方差（来自 $\pi_S$ 的随机采样）
2. **发散后噪声梯度方差**（来自教师对异常前缀的无意义输出）

Divergence-Aware 方法通过以下途径降低方差：

$$\text{Var}[\nabla_\theta \mathcal{L}_{\text{DA}}] \leq \text{Var}[\nabla_\theta \mathcal{L}_{\text{standard}}] - \underbrace{\sum_{t > t^*} \text{Var}[\nabla_\theta D_{\mathrm{KL}}^{(t)}] \cdot (1 - w_t^2)}_{\text{消除的噪声方差}}$$

当 $w_t \to 0$ 时，发散后的噪声梯度被完全消除。

### 4.3 纠偏采样的重要性

仅做权重衰减（丢弃发散后 KL）vs 纠偏采样+权重衰减，关键区别在于：

| 方案 | 发散点处 | 发散后位置 | 信息利用 |
|------|---------|-----------|---------|
| 简单截断 | 学习信号极大但噪声大 | 完全丢失 | 浪费后续位置 |
| 纯权重衰减 | 信号被压制 | 信号递减但仍有噪声 | 噪声仍存在 |
| **纠偏 + 自适应权重** | 软抑制 + 纠偏学习 | 在正确前缀上恢复有效信号 | 充分利用 |

纠偏采样使得学生能在"正确的前缀道路"上继续生成和学习，既避免了错误前缀上的噪声，又不浪费后续位置的蒸馏信号。

### 4.4 收敛性直觉

从 RL 视角看（on-policy distillation $\approx$ RL with teacher log-prob as reward）：

- 标准方法：在错误状态上继续接收 reward 信号 $\to$ 策略梯度方向错误
- 本方法：在错误状态上执行"教师纠正动作"，然后继续累积 reward $\to$ 类似于 **expert intervention**，加速策略改进

这与 RL 中的 **DAgger (Dataset Aggregation)** 有异曲同工之妙：当 learner 偏离时，expert 接管并给出正确示范，learner 从中学习如何从偏离状态恢复。

---

## 5. 动态阈值策略

固定阈值 $\tau_{\text{div}}$ 可能难以适应训练不同阶段的特点。提出两种动态阈值策略：

### 5.1 基于训练进度的预热退火

训练初期学生能力弱，发散频繁，阈值应较高（容忍更多发散），避免过度干预导致训练不稳定：

$$\tau_{\text{div}}(k) = \tau_{\min} + (\tau_{\max} - \tau_{\min}) \cdot \exp\left(-\frac{k}{K_{\text{warmup}}}\right)$$

其中 $k$ 是当前训练步数，$K_{\text{warmup}}$ 是预热步数。

### 5.2 基于统计的自适应阈值

使用 EMA（指数移动平均）跟踪 KL 散度的分布：

$$\mu_{\text{KL}}^{(k)} = (1 - \rho) \cdot \mu_{\text{KL}}^{(k-1)} + \rho \cdot \bar{s}_k$$
$$\sigma_{\text{KL}}^{(k)} = (1 - \rho) \cdot \sigma_{\text{KL}}^{(k-1)} + \rho \cdot \text{std}(s_t^{(k)})$$

设动态阈值为均值加 $n$ 倍标准差：

$$\tau_{\text{div}}(k) = \mu_{\text{KL}}^{(k)} + n \cdot \sigma_{\text{KL}}^{(k)}$$

只有显著偏离正常水平的 KL 才被认定为发散，避免误判。

---

## 6. 与现有方法的关系

### 6.1 vs DAgger

| 维度 | DAgger | Divergence-Aware Distillation |
|------|--------|-------------------------------|
| 场景 | 模仿学习 | 知识蒸馏 |
| 纠偏时机 | 事后离线 | 在线实时 |
| 纠偏信号 | 专家动作 | 教师条件分布采样 |
| 权重策略 | 均等 | 分段自适应 |
| 核心区别 | 纠偏后全部继续学习 | 纠偏后仍有衰减权重 |

本方法可以被视为 **"DAgger 思想在自回归蒸馏中的在线化、自适应化应用"**。

### 6.2 vs Scheduled Sampling

Scheduled Sampling 以一定概率将教师 token 喂入学生代替学生自己的预测。关键区别：

- Scheduled Sampling 的替换是**随机的、无条件的**
- 本方法的纠偏是**条件性的、仅在发散时触发**
- Scheduled Sampling 不区分正常/异常位置
- 本方法对纠偏位置赋予专门的学习权重

### 6.3 vs Callback-Distillation / MINILLM

MINILLM 等工作也关注 KL 在不同位置的差异化处理，但主要是通过调整 KL 方向（forward vs reverse）或加入长度归一化。本方法从"前缀正确性"的视角提供了全新的分析维度。

---

## 7. 实验设计建议

### 7.1 基线方法

1. **Standard On-Policy KL**：均等权重的 Reverse KL
2. **KL Clipping**：对 KL 值进行上界截断
3. **Token-level Weight Decay**：对后续位置线性降低权重（无发散检测）
4. **Simple Truncation**：检测发散后直接截断，不重采样
5. **DA（本方法，无重采样）**：仅用自适应权重，不进行纠偏采样
6. **DA-Full（本方法完整版）**：发散检测 + 纠偏重采样 + 自适应权重

### 7.2 评估指标

| 指标 | 说明 |
|------|------|
| **Generation Quality** | 生成质量（BLEU/ROUGE/胜率） |
| **KL Profile** | 训练过程中每个位置的 KL 散度均值变化 |
| **Divergence Rate** | 每序列平均发散次数，反映学生能力提升 |
| **Gradient SNR** | 梯度信噪比，验证噪声消除效果 |
| **Teacher FLOPs** | 教师模型前向计算量，验证效率提升 |
| **Recovery Rate** | 纠偏后学生能否继续高质量生成 |

### 7.3 关键消融实验

1. **发散检测消融**：$\tau_{\text{div}}$ 阈值扫描
2. **权重策略消融**：分别去掉类型 B/C/D 权重
3. **重采样消融**：对比坚偏采样 vs teacher-forcing 替换 vs 无纠偏
4. **最大纠偏次数消融**：$n_{\max} \in \{1, 2, 3, 5, \infty\}$

### 7.4 预期结果

1. DA-Full 在生成质量上应优于所有基线
2. Divergence Rate 应随训练逐步降低（学生越来越不偏离教师）
3. Teacher FLOPs 应低于标准方法（可提前终止教师前向）
4. 纠偏采样对比简单截断应有显著优势，尤其在长序列任务上

---

## 8. 训练效率优化

### 8.1 早停机制（Early Termination）

当检测到发散且有足够多的纠偏点后，可以**提前终止序列生成**，避免计算无意义的后续 token。这进一步节省计算：

$$\text{FLOPs}_{\text{teacher}} \leq T_{\text{total}} \cdot C_{\text{forward}} - \sum_{i} (T_{\text{total}} - t^*_i) \cdot C_{\text{forward}} \cdot p_{\text{early\_stop}}$$

### 8.2 批量化纠偏

当批次中多个序列同时检测到发散时，可以将纠偏 token 的教师前向传播批量处理，减少 kernel launch 开销。

### 8.3 发散预测器（可选进阶）

训练一个轻量级的发散预测器 $f_\phi(y_{<t}) \to [0,1]$，基于学生隐状态预测下一位置是否可能发散。若预测概率高，可以：
- 预先准备教师的前向计算（与计算流水线化）
- 在采样前就调整采样策略（如 temperature 调节）

这可以进一步降低检测延迟。

---

## 9. 总结

| 要点 | 内容 |
|------|------|
| 核心问题 | 学生采样偏离后，后续 KL 信号失效且有害 |
| 关键洞察 | 自回归条件分布导致错误级联传播 |
| 核心创新 | 三阶段：发散检测 → 纠偏重采样 → 自适应权重 |
| 与 DAgger 的联系 | 在线纠偏的蒸馏版本，但增加细粒度权重 |
| 收敛保证 | 退化为标准方法（阈值→∞时），理论上不劣于基线 |
| 效率收益 | 减少教师无意义前向计算 |
| 实用价值 | 长序列蒸馏、弱学生场景收益最大 |

**一句话总结**：Divergence-Aware On-Policy Distillation 通过检测学生采样中的发散点，在发散处执行教师引导的纠偏采样，并对不同类型的 KL 信号施以自适应权重，既消除了错误前缀上的噪声梯度，又通过纠偏恢复了后续位置的有效蒸馏信号，实现了"及时发现、精准纠偏、有效利用"的自回归蒸馏新范式。