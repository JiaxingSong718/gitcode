# Divergence-Aware On-Policy Distillation（v2）：FSDP 友好的两阶段实现

## 1. 核心问题回顾

在 On-Policy Distillation 中，学生模型 $\pi_S$ 自回归生成序列，每个位置计算 KL 散度作为蒸馏信号。核心问题：

> **当学生在位置 $t^*$ 采样到教师认为概率极低的 token 后，后续所有位置的 KL 散度都建立在"错误前缀"之上——教师在异常前缀上的条件分布缺乏意义，后续 KL 信号成为噪声。**

### 1.1 原方案（v1）的工程困难

v1 方案在采样阶段要求**教师和学生交替前向**：每生成一个 token 都需要同时跑教师和学生做 KL 检测，检测到发散后当场纠偏、当场重采样。这在 FSDP（Fully Sharded Data Parallel）下的工程实现有显著困难：

- **交替前向破坏 FSDP 通信优化**：FSDP 对连续的前向/反后向做了 all-gather 通信优化，逐步交替教师-学生的前向会导致频繁的 all-gather / reduce-scatter，严重拖慢训练
- **自回归逐步推理效率极低**：无法利用 KV Cache 的 prefill 批量加速，逐 token 前向的 GPU 利用率很低
- **变长序列难以批量处理**：不同序列的发散点位置不同，导致纠偏后的序列长度和结构不一致

### 1.2 新方案（v2）的核心改动

将整个过程拆分为**完全解耦的两个阶段**：

| 阶段 | 内容 | 模型参与 | 工程特点 |
|------|------|---------|---------|
| **Phase 1: 采样+纠偏** | 生成纠偏后的完整序列 | 教师+学生 | 纯推理，no grad，可用 vLLM 等推理引擎加速 |
| **Phase 2: 前向+训练** | 对纠偏后序列做一次完整前向，算 logp 和加权 KL | 教师+学生 | 标准 FSDP 前向/反后向流程，无特殊处理 |

关键 insight：**一旦 Phase 1 得到了纠偏后的完整序列，Phase 2 就变成了一个完全标准的 teacher-forcing 式前向——把整条序列喂入模型，一次拿到所有位置的 log prob，然后算加权 KL。** 这与 FSDP 框架完美兼容。

---

## 2. 两阶段算法详解

### 2.1 Phase 1: 采样 + 发散检测 + 教师纠偏

**目标**：对每个 prompt，生成一条"纠偏后的完整序列"，同时记录每个位置的元信息（是否为发散点、是否为纠偏 token、属于哪个 segment）。

#### 2.1.1 流程

```
输入: prompt x, 学生模型 π_S, 教师模型 π_T, 阈值 τ, 最大纠偏次数 K

初始化: y = x (前缀为 prompt), metadata = []

For t = 1, 2, ..., T:
    1. 学生采样 y_t ~ π_S(·|y_{<t})
    
    2. 计算 token 级发散指标:
       - s_t = KL(π_S(·|y_{<t}) || π_T(·|y_{<t}))     # 分布级发散
       - a_t = -log π_T(y_t | y_{<t})                   # 教师惊讶度
    
    3. 判断是否发散:
       if (s_t > τ_div 或 a_t > τ_surp) and n_divergences < K:
           a) 记录: 位置 t 为发散点, 保留学生原始 token y_t 的信息
           b) 教师纠偏采样: ŷ_t ~ π_T(·|y_{<t})
           c) 将纠偏 token ŷ_t 拼入序列 (替换 y_t)
           d) 记录: 位置 t 的纠偏 token 为 ŷ_t
           e) n_divergences += 1
       else:
           a) 将 y_t 拼入序列
       
    4. 记录该位置的 metadata: {position, is_divergence, is_correction, segment_id}

输出: 纠偏后完整序列 ỹ = (ỹ_1, ỹ_2, ..., ỹ_T), metadata 列表
```

#### 2.1.2 序列结构示例

假设在位置 3 发散，位置 5 再次发散：

```
位置:     1    2    3(div)  3(corr)  4    5(div)  5(corr)  6    7    ...
token:   y_1  y_2   y_3     ŷ_3     y_4   y_5     ŷ_5     y_6  y_7  ...
segment:  0    0     0       1       1     1       2       2    2   ...
类型:     A    A     B       C       D     B       C       D    D   ...
```

**注意**：发散点处序列会多一个位置——保留原始 token 用于计算发散点 KL（类型 B），同时插入纠偏 token 用于后续生成和纠偏点 KL（类型 C）。也就是说，纠偏后的序列长度为 $T + N_{\text{corr}}$，其中 $N_{\text{corr}}$ 是纠偏次数。

#### 2.1.3 采样阶段的工程优化

Phase 1 是纯推理（no grad），因此可以做以下优化：

1. **推理引擎加速**：用 vLLM / SGLang 等推理框架替代 huggingface 逐步生成，利用 continuous batching 和 KV Cache 加速
2. **投机采样加速**：在发散检测时，可以批量 prefetch 教师前向（而非逐步做），在非发散位置用学生独立生成跳过教师推理
3. **教师前向共享前缀**：教师和学生共享 prompt 的 prefill，头部的 KV Cache 只需算一次

### 2.2 Phase 2: 前向 + 加权 KL 损失

**目标**：对 Phase 1 输出的纠偏后序列做一次标准前向，计算每个位置的 log prob，然后按分段权重计算加权 KL 损失。

#### 2.2.1 前向过程

```
输入: 纠偏后序列 ỹ, metadata 列表

1. 学生模型前向: 一次性将整条序列 ỹ 输入 π_S，得到所有位置的 logits
   s_logits[i] = π_S(logits | ỹ_{<i})    # shape: [seq_len, vocab_size]

2. 教师模型前向: 一次性将整条序列 ỹ 输入 π_T，得到所有位置的 logits
   t_logits[i] = π_T(logits | ỹ_{<i})    # shape: [seq_len, vocab_size]

3. 取每个位置对应 token 的 log prob:
   s_logp[i] = log π_S(ỹ_i | ỹ_{<i})
   t_logp[i] = log π_T(ỹ_i | ỹ_{<i})

4. 完整KL散度（用于位置类型判定时可复用）:
   kl_full[i] = D_KL(π_S(·|ỹ_{<i}) || π_T(·|ỹ_{<i}))
```

**这就是一个标准的 teacher-forcing 前向——和 FSDP 的训练流程完全一致，没有任何特殊的交互需求。**

#### 2.2.2 分段权重计算

根据 metadata 中记录的信息，为每个位置分配权重：

**类型 A：正常位置**（$t < t^*_1$，任何发散点之前）

$$w_t^{(A)} = 1$$

这些位置的前缀完全由学生自己采样，KL 信号质量最高。

**类型 B：发散点**（学生原始 token 发散的位置）

$$w_t^{(B)} = \gamma \cdot \text{sg}\left(\frac{\min(s_t, s_{\max})}{\min(s_t, s_{\max}) + \beta}\right)$$

其中 $\text{sg}(\cdot)$ 为 stop_gradient，$s_{\max}$ 为 KL 截断上界防止极端值。对发散点做软抑制：

- $s_t$ 越大（越发散）→ 权重越低（信号越不可靠）
- 但不完全置零，保留"告诉学生这个位置有问题"的信号
- $\gamma \in (0,1)$ 是全局缩放因子，$\beta$ 控制饱和速度

**类型 C：纠偏 token 位置**（教师重新采样的 token）

$$w_t^{(C)} = 1 + \lambda \cdot \text{sg}\left(\max\left(0,\; \log \pi_T(\hat{y}_t | \hat{y}_{<t}) - c\right)\right)$$

纠偏位置是**最有价值的学习信号**——它告诉学生"在这种前缀下你应该选什么"。权重设计理念：

- 基础权重为 1，不低于正常位置
- 教师越自信的纠偏（log prob 越高），权重越大
- $c$ 是置信度阈值，只有教师足够自信的纠偏才获得额外权重
- $\lambda$ 控制增强幅度

**类型 D：纠偏后后续位置**（$t > t^*_k$，在最近一次纠偏之后）

$$w_t^{(D)} = \alpha \cdot \exp\left(-\eta \cdot d(t, t^*_{\text{last}})\right) \cdot \prod_{k=1}^{N_{\text{corr}}} \mathbb{1}[t > t^*_k] + (1 - \alpha)$$

其中 $d(t, t^*_{\text{last}})$ 是到最近一次纠偏点的距离。纠偏后的位置虽然前缀已恢复正确，但仍存在两个问题：

1. 纠偏后学生的采样分布可能与纯 on-policy 分布有偏差
2. 多次纠偏会累积偏差

指数衰减 + 基础权重 $(1-\alpha)$ 的组合既体现信任递减，又保证最低学习信号。

#### 2.2.3 完整损失函数

$$\mathcal{L}_{\text{DA}} = \frac{1}{\sum_t w_t} \sum_{t=1}^{T+N_{\text{corr}}} w_t \cdot D_{\mathrm{KL}}\left(\pi_S(\cdot|\hat{y}_{<t}) \;\|\; \pi_T(\cdot|\hat{y}_{<t})\right)$$

注意**用权重归一化**，避免不同序列因发散次数不同导致损失量纲不一致。

等价地，用 token 级 log prob 展开：

$$\mathcal{L}_{\text{DA}} = \frac{1}{\sum_t w_t} \sum_{t=1}^{T+N_{\text{corr}}} w_t \cdot \left[\sum_{v \in \mathcal{V}} \pi_S(v|\hat{y}_{<t}) \log \frac{\pi_S(v|\hat{y}_{<t})}{\pi_T(v|\hat{y}_{<t})}\right]$$

或者如果用简化版（只对采样 token 的 log prob 差值）：

$$\mathcal{L}_{\text{DA}} \approx \frac{1}{\sum_t w_t} \sum_{t} w_t \cdot \left(\log \pi_S(\hat{y}_t|\hat{y}_{<t}) - \log \pi_T(\hat{y}_t|\hat{y}_{<t})\right)^2$$

---

## 3. 完整算法流程

```
==========================================================================
Divergence-Aware On-Policy Distillation (v2) - 完整流程
==========================================================================

输入: 
  教师模型 π_T (frozen), 学生模型 π_S (trainable)
  数据集 D, 阈值 τ_div, τ_surp
  权重超参 γ, β, α, λ, η, c
  最大纠偏次数 K

================================================================================
Phase 1: 采样 + 发散检测 + 纠偏  (no grad, 可用推理引擎)
================================================================================

For each prompt x in batch:
    1. 初始化: y_prefix = x, corrected_seq = [], metadata = []
    2. n_div = 0
    3. For t = 1 to T:
        a) y_t ~ π_S(·|y_prefix)                          # 学生采样
        b) [并行] 计算 s_t, a_t from π_S, π_T             # 发散指标
        c) If (s_t > τ_div or a_t > τ_surp) and n_div < K:
            - 记录 {pos, token=y_t, type=B, segment, kl=s_t}
            - ŷ_t ~ π_T(·|y_prefix)                        # 教师纠偏采样
            - 记录 {pos, token=ŷ_t, type=C, segment+1}
            - y_prefix = concat(y_prefix, ŷ_t)             # 用纠偏 token 继续
            - n_div += 1
        d) Else:
            - 记录 {pos, token=y_t, type=A/D, segment, dist_to_last_corr}
            - y_prefix = concat(y_prefix, y_t)
    4. 输出: corrected_seq, metadata

================================================================================
Phase 2: 前向 + 加权 KL 损失  (标准 FSDP 训练流程)
================================================================================

1. 【批量前向 - 学生】
   将批次内所有纠偏后序列 padding 后输入学生模型
   s_logits = π_S(corrected_seqs)    # shape: [B, max_seq_len, V]

2. 【批量前向 - 教师】
   将同样的序列输入教师模型 (no grad)
   with torch.no_grad():
       t_logits = π_T(corrected_seqs)  # shape: [B, max_seq_len, V]

3. 【计算逐 token 的 KL 散度】
   For each position t in each sequence:
       kl_t = KL(π_S(·|ỹ_{<t}) || π_T(·|ỹ_{<t}))

4. 【根据 metadata 计算权重】
   For each position t in each sequence:
       根据 type (A/B/C/D) 和 s_t, dist_to_last_corr 等计算 w_t

5. 【计算加权损失】
   loss = (1 / Σ w_t) * Σ (w_t * kl_t)

6. 【反后向 + 更新】
   loss.backward()
   optimizer.step()

================================================================================
```

---

## 4. PyTorch 伪代码实现

```python
import torch
import torch.nn.functional as F
from dataclasses import dataclass
from typing import List, Tuple

# ============================================================
# 数据结构定义
# ============================================================

@dataclass
class PositionMeta:
    """记录每个位置的发散元信息"""
    token_id: int            # 最终拼入序列的 token id
    position_type: str       # 'A' (正常), 'B' (发散点), 'C' (纠偏token), 'D' (纠偏后)
    segment_id: int          # 所属 segment 编号
    kl_at_div: float = 0.0   # 仅发散点有值，记录发散时的 KL 散度
    teacher_logp: float = 0.0  # 仅纠偏 token 有值，记录教师对该 token 的置信度
    dist_to_last_corr: int = 0  # 仅类型 D 有值，到最近纠偏点的距离
    is_loss_token: bool = True  # 是否参与损失计算


def phase1_sampling_with_correction(
    student, teacher, prompt_ids, 
    tau_div=5.0, tau_surp=10.0,
    max_corrections=3, max_seq_len=512
) -> Tuple[List[int], List[PositionMeta]]:
    """
    Phase 1: 采样 + 发散检测 + 纠偏
    返回纠偏后的完整序列和元信息
    
    注意: 此阶段为纯推理，no grad，可用推理引擎加速
    """
    corrected_seq = list(prompt_ids)
    metadata = []
    n_divergences = 0
    segment_id = 0
    last_correction_pos = -1
    
    prefix = list(prompt_ids)
    
    with torch.no_grad():
        for t in range(max_seq_len):
            # 学生采样
            s_logits = student(torch.tensor([prefix])).logits[:, -1, :]
            s_probs = F.softmax(s_logits, dim=-1)
            y_t = torch.multinomial(s_probs, num_samples=1).item()
            
            # 教师前向（共享前缀）
            t_logits = teacher(torch.tensor([prefix])).logits[:, -1, :]
            t_probs = F.softmax(t_logits, dim=-1)
            t_log_probs = F.log_softmax(t_logits, dim=-1)
            
            # 计算发散指标
            s_t = F.kl_div(
                t_log_probs, s_probs, 
                log_target=False, reduction='sum'
            ).item()  # reverse KL
            a_t = -t_log_probs[0, y_t].item()  # 教师惊讶度
            
            # 发散检测
            if (s_t > tau_div or a_t > tau_surp) and n_divergences < max_corrections:
                # === 类型 B: 发散点 ===
                meta_b = PositionMeta(
                    token_id=y_t,
                    position_type='B',
                    segment_id=segment_id,
                    kl_at_div=s_t,
                )
                metadata.append(meta_b)
                corrected_seq.append(y_t)
                
                # 教师纠偏采样
                y_t_corrected = torch.multinomial(t_probs, num_samples=1).item()
                teacher_logp = t_log_probs[0, y_t_corrected].item()
                
                # === 类型 C: 纠偏 token ===
                segment_id += 1
                meta_c = PositionMeta(
                    token_id=y_t_corrected,
                    position_type='C',
                    segment_id=segment_id,
                    teacher_logp=teacher_logp,
                )
                metadata.append(meta_c)
                corrected_seq.append(y_t_corrected)
                
                # 用纠偏 token 继续生成
                prefix.append(y_t_corrected)
                n_divergences += 1
                last_correction_pos = len(corrected_seq) - 1
            else:
                # === 类型 A 或 D ===
                is_type_d = (n_divergences > 0)
                meta = PositionMeta(
                    token_id=y_t,
                    position_type='D' if is_type_d else 'A',
                    segment_id=segment_id,
                    dist_to_last_corr=(len(corrected_seq) - last_correction_pos) if is_type_d else 0,
                )
                metadata.append(meta)
                corrected_seq.append(y_t)
                prefix.append(y_t)
    
    return corrected_seq, metadata


def compute_adaptive_weights(metadata: List[PositionMeta], 
                             gamma=0.3, beta=1.0, alpha=0.7, 
                             lam=1.0, eta=0.1, c=-2.0, s_max=20.0):
    """根据 metadata 计算每个位置的权重"""
    weights = []
    for meta in metadata:
        if not meta.is_loss_token:
            weights.append(0.0)
            continue
            
        if meta.position_type == 'A':
            # 正常位置：全权重
            w = 1.0
            
        elif meta.position_type == 'B':
            # 发散点：软抑制
            s_clamped = min(meta.kl_at_div, s_max)
            w = gamma * (s_clamped / (s_clamped + beta))
            w = w.detach()  # stop gradient
            
        elif meta.position_type == 'C':
            # 纠偏 token：置信度加权
            bonus = max(0.0, meta.teacher_logp - c)
            w = 1.0 + lam * bonus
            w = w  # 不需要 stop grad，teacher_logp 是常数
            
        elif meta.position_type == 'D':
            # 纠偏后后续：指数衰减 + 基础权重
            d = meta.dist_to_last_corr
            w = alpha * torch.exp(torch.tensor(-eta * d)).item() + (1 - alpha)
            
        else:
            w = 1.0
            
        weights.append(w)
    
    return weights


def phase2_forward_and_loss(student, teacher, corrected_seq, metadata, 
                            gamma=0.3, beta=1.0, alpha=0.7, 
                            lam=1.0, eta=0.1, c=-2.0):
    """
    Phase 2: 标准前向 + 加权 KL 损失
    完全兼容 FSDP 训练流程
    """
    # 计算权重
    weights = compute_adaptive_weights(
        metadata, gamma, beta, alpha, lam, eta, c
    )
    weight_tensor = torch.tensor(weights, device=student.device)
    
    # 学生前向（整条序列，一次前向）
    input_ids = torch.tensor([corrected_seq], device=student.device)
    s_logits = student(input_ids).logits  # [1, seq_len, vocab]
    
    # 教师前向（整条序列，一次前向，no grad）
    with torch.no_grad():
        t_logits = teacher(input_ids).logits  # [1, seq_len, vocab]
    
    # 计算逐位置 KL 散度
    # 注意: 只计算 response 部分的 loss，跳过 prompt
    prompt_len = len(corrected_seq) - len(metadata)
    response_logits_s = s_logits[:, prompt_len-1:-1, :]  # shift
    response_logits_t = t_logits[:, prompt_len-1:-1, :]
    
    # Reverse KL: KL(π_S || π_T)
    s_log_probs = F.log_softmax(response_logits_s, dim=-1)
    t_log_probs = F.log_softmax(response_logits_t, dim=-1)
    s_probs = F.softmax(response_logits_s, dim=-1)
    
    # 逐位置 KL: sum_v π_S(v) * (log π_S(v) - log π_T(v))
    kl_per_token = (s_probs * (s_log_probs - t_log_probs)).sum(dim=-1)  # [1, resp_len]
    kl_per_token = kl_per_token.squeeze(0)  # [resp_len]
    
    # 加权 KL 损失（权重归一化）
    resp_weights = weight_tensor[:len(kl_per_token)]
    loss = (resp_weights * kl_per_token).sum() / resp_weights.sum()
    
    return loss


# ============================================================
# 训练主循环
# ============================================================

def train_step(student, teacher, dataloader, optimizer, **kwargs):
    """一个完整的训练 step"""
    
    batch_metadata = []
    batch_corrected_seqs = []
    
    # ========== Phase 1: 采样 + 纠偏 (no grad) ==========
    student.eval()
    teacher.eval()
    with torch.no_grad():
        for prompt in dataloader:
            seq, meta = phase1_sampling_with_correction(
                student, teacher, prompt, **kwargs
            )
            batch_corrected_seqs.append(seq)
            batch_metadata.append(meta)
    
    # ========== Phase 2: 前向 + 损失 + 反后向 ==========
    student.train()
    
    # 对 batch 中每条序列分别计算 loss（因为长度不同、元信息不同）
    total_loss = 0.0
    for seq, meta in zip(batch_corrected_seqs, batch_metadata):
        loss = phase2_forward_and_loss(student, teacher, seq, meta, **kwargs)
        total_loss += loss
    
    total_loss = total_loss / len(batch_corrected_seqs)
    
    # 标准反后向
    optimizer.zero_grad()
    total_loss.backward()
    optimizer.step()
    
    return total_loss.item()
```

---

## 5. FSDP 工程实现细节

### 5.1 Phase 1 的 FSDP 兼容方案

Phase 1 需要逐步生成并做发散检测，与 FSDP 的批量训练模式不兼容。推荐做法：

**方案 A：推理引擎 offload**

```
训练节点 ↔ 共享内存/文件系统 ↔ 推理引擎（vLLM/SGLang）
   ↑                                     ↓
 Phase 2                          Phase 1 (采样+纠偏)
```

- Phase 1 用独立的推理引擎完成，生成纠偏后序列存入 buffer
- Phase 2 从 buffer 读取序列，做标准 FSDP 训练
- 两个阶段可异步流水线化：Phase 1 提前生成下一批数据，Phase 2 训练当前批次

**方案 B：FSDP 模型做逐步推理**

如果必须在训练进程中完成 Phase 1：

```python
# 将 FSDP 模型切换到推理模式
from torch.distributed.fsdp import FullyShardedDataParallel as FSDP

# 逐步生成时，使用 FSDP 的 summon_params 上下文
# 或在单卡上用 local model 做推理
with FSDP.summon_full_params(student, recurse=False):
    student.eval()
    # ... 逐步采样
    student.train()
```

这种方案性能较差，不推荐用于大规模训练。

**方案 C（推荐）：Rollout Buffer 解耦**

```
                ┌─────────────────────┐
                │   Rollout Worker    │
                │ (Phase 1: 采样+纠偏) │
                │  - 可用推理引擎      │
                │  - 可用 float16/8    │
                │  - 不需梯度          │
                └────────┬────────────┘
                         │ 纠偏序列 + metadata
                         ▼
                ┌─────────────────────┐
                │   Training Buffer   │
                │ (共享内存 / Redis)   │
                └────────┬────────────┘
                         │
                         ▼
                ┌─────────────────────┐
                │   Training Worker   │
                │ (Phase 2: 标准FSDP) │
                │  - 批量前向反后向    │
                │  - 完全标准训练流程  │
                │  - 可多卡 FSDP      │
                └─────────────────────┘
```

类似于 RLHF/PPO 中的 rollout buffer 架构，将采样和训练完全解耦。这是最推荐的工程方案。

### 5.2 Phase 2 的 FSDP 标准实现

Phase 2 是标准的 teacher-forcing 前向，完全兼容 FSDP：

```python
import torch
import torch.distributed as dist
from torch.distributed.fsdp import FullyShardedDataParallel as FSDP

def fsdp_phase2_train_step(student_fsdp, teacher_fsdp, batch_seqs, batch_metadata, optimizer):
    """
    Phase 2: 标准 FSDP 训练 step
    batch_seqs: padding 后的 token ids [B, max_seq_len]
    batch_metadata: 每条序列的元信息
    """
    # 学生前向（FSDP 自动处理 all-gather 和通信）
    s_logits = student_fsdp(batch_seqs).logits  # [B, S, V]
    
    # 教师前向（no grad，FSDP 同样处理）
    with torch.no_grad():
        t_logits = teacher_fsdp(batch_seqs).logits  # [B, S, V]
    
    # 逐位置 KL
    s_logp = F.log_softmax(s_logits, dim=-1)
    t_logp = F.log_softmax(t_logits, dim=-1)
    s_p = F.softmax(s_logits, dim=-1)
    kl = (s_p * (s_logp - t_logp)).sum(dim=-1)  # [B, S]
    
    # 构造权重矩阵 [B, S]
    weight_matrix = build_weight_matrix(batch_metadata, device=kl.device)
    
    # 加权损失
    mask = (batch_seqs != pad_token_id).float()  # padding mask
    loss = (weight_matrix * kl * mask).sum() / (weight_matrix * mask).sum()
    
    # 标准反后向
    optimizer.zero_grad()
    loss.backward()
    # FSDP 自动处理 gradient reduce-scatter
    optimizer.step()
    
    return loss.item()
```

### 5.3 变长序列的批量化处理

不同序列的发散点数量不同，纠偏后序列长度也不同。处理方案：

**方案 1：Padding + Mask（简单但浪费）**

```python
# Pad 到批次内最长序列
padded = torch.nn.utils.rnn.pad_sequence(seqs, batch_first=True, padding_value=pad_id)
# 用 mask 忽略 padding 位置
mask = (padded != pad_id).float()
```

**方案 2：按序列长度分组（推荐）**

```python
# 按 metadata 中纠偏次数分组
# 纠偏次数相同的序列长度一致（或近似），减少 padding 浪费
groups = group_by_num_corrections(batch)
for group in groups:
    loss = phase2_forward_and_loss(student, teacher, group.seqs, group.metas)
```

**方案 3：Flash Attention 的 varlen 模式**

```python
# 使用 flash_attn_varlen_func 处理拼接后的连续序列
# 通过 cu_seqlens 标记每条序列的边界
all_tokens = torch.cat([torch.tensor(s) for s in batch_seqs])
cu_seqlens = torch.tensor([0] + [len(s) for s in batch_seqs]).cumsum(0)
```

---

## 6. 与 v1 方案的关键差异

| 维度 | v1（原方案） | v2（本方案） |
|------|-------------|-------------|
| **采样与训练** | 交织进行，逐步交互 | 完全解耦为两个阶段 |
| **FSDP 兼容性** | 差（需逐步交替教师-学生前向） | 好（Phase 2 完全标准流程） |
| **推理引擎可用性** | 不可用（需逐步交互） | 可用（Phase 1 是纯推理） |
| **KL 计算** | 在采样时同步计算 | Phase 2 一次前向批量计算 |
| **工程复杂度** | 高（自回归逐步+梯度） | 低（两个阶段各自简单） |
| **理论等价性** | 原始方案 | 完全等价（权重策略相同） |
| **序列结构** | 原地替换 token | 序列中插入纠偏 token（长度+1） |
| **训练效率** | 低（逐步前向无法批量化） | 高（Phase 2 标准批量化） |

### 6.1 等价性说明

v1 和 v2 在数学上是完全等价的：

1. Phase 1 生成的纠偏序列与 v1 逐步采样的结果一致
2. Phase 2 的前向计算（给定序列算 log prob）与 v1 逐步前向的结果一致
3. 权重策略完全相同

唯一的区别是**工程实现方式**：v2 将整个过程拆分成更适合实际训练框架的两个阶段。

---

## 7. 简化版本：无纠偏的 Divergence-Aware 截断

如果纠偏采样的工程成本仍然较高，可以先实现一个**简化版本**——仅做发散后截断，不做纠偏：

### 7.1 简化版 Phase 1

```
For each prompt x:
    用 π_S 自回归生成, 每步计算 s_t, a_t
    若发散: 记录发散点 t*, 截断后续生成
    输出: 截断序列 y[1:t*], 发散点位置 t*
```

### 7.2 简化版权重

只有两种权重：

$$w_t = \begin{cases} 1 & t < t^* \text{ (发散前: 正常位置)}\\ \gamma \cdot \text{sg}\left(\frac{\min(s_t, s_{\max})}{\min(s_t, s_{\max}) + \beta}\right) & t = t^* \text{ (发散点: 软抑制)}\\ 0 & t > t^* \text{ (发散后: 直接截断)}\\ \end{cases}$$

### 7.3 简化版的优势

- Phase 1 更简单：只需在发散点截断，不需要教师重新采样
- 不改变序列长度，批量化更容易
- 训练效率更高：短序列意味着更少的前向计算

### 7.4 简化版的代价

- 丢失了发散后位置的学习信号（但如前分析，这些信号本身质量低）
- 丢失了纠偏 token 的关键学习信号（类型 C 权重）
- 序列倾向于变短，可能导致学生对长序列生成能力不足

**建议**：先用简化版验证"发散后 KL 无用"的核心假设，再升级到完整版。

---

## 8. 进阶优化

### 8.1 自适应截断长度

简化版中直接截断可能过于激进。替代方案：截断后用教师补全剩余部分：

```
用 π_S 生成至发散点 t*
截断 y[t*+1:]
用 π_T 从 y[1:t*] 继续生成至长度 T
得到混合序列: [学生生成的前缀 | 教师生成的后缀]
```

后缀部分的 KL 权重设为较低值（类型 D），但保留了长序列的训练信号。

### 8.2 多发散点预算

设置每条序列的最大发散次数 $K$：
- $K=0$：纯 on-policy，等同标准方法加截断
- $K=1$：一次纠偏机会，性价比最高
- $K>1$：多次纠偏，适合长序列

实验建议从 $K=1$ 开始。

### 8.3 发散分数的批量计算优化

Phase 1 中每步需要计算 KL 散度和教师惊讶度。可以复用 logits：

```python
# 一次前向同时获取学生和教师的 logits
logits_s, logits_t = parallel_forward(student, teacher, prefix)

# 从 logits 直接计算 s_t 和 a_t
probs_s = softmax(logits_s[-1])
probs_t = softmax(logits_t[-1])
s_t = (probs_s * (log(probs_s) - log(probs_t))).sum()  # reverse KL
a_t = -log(probs_t[y_t])
```

如果用 vLLM 推理引擎，可以自定义采样钩子，在采样过程中自动计算这些指标。

### 8.4 动态阈值（延续 v1 方案）

$$\tau_{\text{div}}(k) = \mu_{\text{KL}}^{(k)} + n \cdot \sigma_{\text{KL}}^{(k)}$$

用 EMA 跟踪训练过程中 KL 散度的分布，自动调整发散阈值。训练早期阈值高（容忍更多发散），训练后期阈值低（更精细地检测）。

---

## 9. 实验设计

### 9.1 基线方法

| 编号 | 方法 | 说明 |
|------|------|------|
| B1 | Standard On-Policy KL | 均等权重，无发散处理 |
| B2 | KL Clipping | 对 KL 值截断上界 |
| B3 | Token Weight Decay | 位置线性衰减权重（无发散检测） |
| B4 | DA-Truncate（简化版） | 发散后直接截断 |
| B5 | DA-Full（完整版） | 发散检测 + 纠偏 + 自适应权重 |

### 9.2 主要实验

1. **核心验证**：DA-Truncate vs B1，验证"发散后 KL 无用"的假设
2. **纠偏增益**：DA-Full vs DA-Truncate，验证纠偏采样的额外价值
3. **权重消融**：分别去掉类型 B/C/D 权重，验证自适应权重的必要性
4. **阈值扫描**：$\tau_{\text{div}} \in \{1, 3, 5, 10, 20\}$，找最优阈值
5. **纠偏次数**：$K \in \{0, 1, 2, 3, 5\}$，验证多次纠偏的边际收益
6. **长序列 vs 短序列**：在不同输出长度上的效果差异

### 9.3 分析指标

| 指标 | 含义 |
|------|------|
| Divergence Rate | 每序列平均发散次数（应随训练降低） |
| Truncated Token Ratio | 被截断/降权的 token 占比 |
| KL Profile | 训练中各位置 KL 均值变化曲线 |
| Gradient Norm | 梯度范数变化（验证去噪效果） |
| Teacher FLOPs | 教师计算量对比 |
| Generation Quality | BLEU/ROUGE/Win Rate |

### 9.4 预期结论

1. DA-Truncate 应显著优于 B1（验证发散后 KL 有害）
2. DA-Full 在长序列任务上优于 DA-Truncate（纠偏恢复后续信号）
3. 类型 C 权重（纠偏 token 增强权重）贡献最大
4. Divergence Rate 随训练单调下降
5. Teacher FLOPs 在 DA-Truncate 中显著降低（截断后无需教师前向）

---

## 10. 总结

| 要点 | v2 方案 |
|------|--------|
| **核心创新** | 发散检测 + 纠偏采样 + 自适应权重 |
| **工程改进** | 采样与训练完全解耦，FSDP 友好 |
| **Phase 1** | 纯推理，可用推理引擎加速，支持 Rollout Buffer 架构 |
| **Phase 2** | 标准 FSDP 前向/反后向，无需特殊处理 |
| **简化版** | 发散后截断，工程成本最低，先验证核心假设 |
| **完整版** | 教师纠偏采样，恢复后续 KL 信号，效果最优 |
| **与 v1 等价** | 数学上完全等价，仅工程实现不同 |
| **推荐路径** | 先实现简化版 → 验证假设 → 升级完整版 |

**一句话总结**：Divergence-Aware On-Policy Distillation v2 将算法拆分为"采样+纠偏"和"前向+训练"两个完全解耦的阶段，Phase 1 用推理引擎高效生成纠偏序列，Phase 2 用标准 FSDP 流程计算加权 KL 损失，兼顾了理论创新与工程可行性。