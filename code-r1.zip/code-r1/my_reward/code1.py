import re
import random
import asyncio
from openai import OpenAI
import sys
import os
# 将 my_reward 目录加入路径（tool_sandbox 就在这个目录下）
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# 使用slime中retool的tool_sandbox.py
from tool_sandbox import tool_registry

client = OpenAI(base_url='http://10.11.19.71:8800/v1', api_key='111')


def get_llm_output(prompt):
    messages = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": prompt},
    ]

    completion = client.chat.completions.create(
        model='Qwen3-14B',
        temperature=0.0,
        messages=messages,
        extra_body={
                "chat_template_kwargs": {"enable_thinking": False}
            },
        stream=False,
    )
    output = completion.choices[0].message.content
    return output


def extract_answer(text):
    answer = text.split("<answer>")[-1]
    answer = answer.split("</answer>")[0]
    return answer.strip()


def is_valid_sequence(content):
    # Check for balanced tags
    tags_to_check = ["think", "code", "observation", "answer"]
    for tag in tags_to_check:
        opening_count = len(re.findall(f"<{tag}>", content))
        closing_count = len(re.findall(f"</{tag}>", content))
        if opening_count != closing_count:
            return False, f"Mismatch in {tag} tags: {opening_count} opening vs {closing_count} closing tags"

    # 1. First split the content by any tags we recognize
    split_pattern = r"(</?(?:think|code|observation|answer)>)"
    parts = re.split(split_pattern, content)

    # 2. Keep track of the current position in the expected sequence
    state = "start"  # start -> think -> search -> information -> think -> ... -> answer -> end

    # 3. Check each part
    for i, part in enumerate(parts):
        # Skip empty parts
        if not part.strip():
            continue

        # Check if this is a tag
        if re.match(r"</?(?:think|code|observation|answer)>", part):
            # This is a tag, check if it's valid in the current state
            if part == "<think>" and state in ["start", "observation"]:
                state = "in_think"
            elif part == "</think>" and state == "in_think":
                state = "after_think"
            elif part == "<code>" and state == "after_think":
                state = "in_code"
            elif part == "</code>" and state == "in_code":
                state = "after_code"
            elif part == "<observation>" and state == "after_code":
                state = "in_observation"
            elif part == "</observation>" and state == "in_observation":
                state = "observation"
            elif part == "<answer>" and state == "after_think":
                state = "in_answer"
            elif part == "</answer>" and state == "in_answer":
                state = "end"
            else:
                return False, f"Unexpected tag {part} in state {state}"
        else:
            # This is content, check if it's valid in the current state
            if state in ["in_think", "in_code", "in_observation", "in_answer"]:
                # Content is allowed inside tags
                pass
            elif state in ["start", "after_think", "after_code", "observation"]:
                # Only whitespace is allowed between tags
                if part.strip():
                    return False, f"Unexpected content '{part.strip()}' between tags (state: {state})"
            else:
                return False, f"Unexpected content in state {state}"

    # Check final state
    if state != "end":
        return False, f"Incomplete sequence, ended in state {state}"

    return True, "Valid sequence format"


def answer_reward(user_message, answer):
    prompt = '''
    ## 任务目标
    根据执行过程判断是否成功解决问题
    
    ## 任务要求
    - 认真审视执行过程，做出正确的判断
    - 只输出是或否，不要输出多余内容
    
    ## 问题
    {}
    
    ## 执行过程
    {}'''

    result = get_llm_output(prompt.format(user_message, answer))
    if result == '是':
        return 1
    else:
        return -1


async def exec_code_async(code: str):
    """
    使用 tool_sandbox 的 code_interpreter 工具异步执行代码
    返回 (stdout, stderr) 元组，与原接口保持一致
    """
    result = await tool_registry.execute_tool(
        tool_name="code_interpreter",
        arguments={"code": code}
    )

    # 解析返回结果，适配不同的返回格式
    if isinstance(result, dict):
        stdout = result.get("stdout", "")
        stderr = result.get("stderr", "")
    elif isinstance(result, str):
        # 如果返回纯字符串，视为 stdout
        stdout = result
        stderr = ""
    else:
        stdout = str(result)
        stderr = ""

    # 截断，与原逻辑保持一致
    stdout = stdout[:1000]
    stderr = stderr[:1000]

    print(stdout, stderr)
    return stdout, stderr


def exec_code(code: str):
    """
    同步包装器，内部调用异步的 exec_code_async
    兼容原有同步调用方式
    """
    try:
        # 尝试获取当前事件循环
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # 若已有运行中的事件循环（如 Jupyter 环境），使用 asyncio.ensure_future
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(asyncio.run, exec_code_async(code))
                return future.result()
        else:
            return loop.run_until_complete(exec_code_async(code))
    except RuntimeError:
        # 没有事件循环时，直接创建新的运行
        return asyncio.run(exec_code_async(code))


def extract_code(text: str) -> list:
    code_block_pattern = re.compile(r'<code>(.*?)</code>', re.DOTALL)

    # Find all matches in the text
    code_blocks = code_block_pattern.findall(text)

    # If no code blocks are found, return empty list
    if not code_blocks:
        return []
    return code_blocks


def code_result(solution_str):
    code_blocks = extract_code(solution_str)
    if not code_blocks:
        return '', ''
    code = code_blocks[-1]
    stdout, stderr = exec_code(code)
    return stdout, stderr


def compute_score(data_source, solution_str, ground_truth, extra_info=None):
    
    is_valid, _ = is_valid_sequence(solution_str)
    if is_valid:
        score = 0.5
        stdout, stderr = code_result(solution_str)
        if 'error' in stderr.lower() or 'traceback' in stderr.lower():
            score -= 0.5
        else:
            score += 0.5
            user_message = extra_info['user_message']
            score += answer_reward(user_message, solution_str)
        print('+++++++++++++++++++++++++++++')
        print(solution_str)
        print('+++++++++++++++++++++++++++++')
        return score
    else:
        format_score = 0
        
        if solution_str.startswith('<think>'):
            format_score += 0.1
        if solution_str.endswith('</answer>'):
            format_score += 0.1
        
        if '</think><answer>' in solution_str.replace('\n', ''):
            format_score += 0.1
        
        if '<think>' in solution_str and '</think>' in solution_str:
            format_score += 0.02
        
        if '<code>' in solution_str and '</code>' in solution_str:
            format_score += 0.02
        
        if '<answer>' in solution_str and '</answer>' in solution_str:
            format_score += 0.02
        
        return format_score

