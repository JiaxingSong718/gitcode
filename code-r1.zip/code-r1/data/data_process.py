import pandas as pd
import json

with open('/nativemm/share/cpfs/songjiaxing/data/code_data/python-codes-25k.jsonl', 'r', encoding='utf-8') as f:
    lines = f.readlines()

df_train = pd.DataFrame(columns=['data_source', 'prompt', 'ability', 'reward_model', 'extra_info'])
df_val = pd.DataFrame(columns=['data_source', 'prompt', 'ability', 'reward_model', 'extra_info'])

INSTRUCTIONS = """Generate code to solve the given question. \
You must conduct reasoning inside <think> and </think> before <code> and <answer> every time. \
After reasoning, if you find you need run code, you can call a code engine by <code> your code </code> and it will return the run results between <observation> and </observation>. \
You can generate and run code as many times as your want. \
After reasoning, if you find the given question has already been solved , you can directly provide the run summary inside <answer> and </answer>. \
Question: {}\n"""

# 训练集构建
data_source = []
prompt = []
ability = []
reward_model = []
extra_info = []
for idx, line in enumerate(lines[:20000]):
    line = json.loads(line)
    content = line['instruction'] + line['input']
    data_source.append('code')
    prompt.append([{"role": "user", "content": INSTRUCTIONS.format(content)}])
    ability.append('text')
    reward_model.append({
                "style": "rule",
                "ground_truth": "",
            })

    extra_info.append({
                'split': 'train',
                'index': idx,
                "user_message": content,
            })

df_train['data_source'] = data_source
df_train['prompt'] = prompt
df_train['ability'] = ability
df_train['reward_model'] = reward_model
df_train['extra_info'] = extra_info

print(df_train.head())

df_train.to_parquet('/nativemm/share/cpfs/songjiaxing/data/code_data/code_train.parquet')

# 评测集构建
data_source = []
prompt = []
ability = []
reward_model = []
extra_info = []
for idx, line in enumerate(lines[-1000:]):
    line = json.loads(line)
    content = line['instruction'] + line['input']
    data_source.append('code')
    prompt.append([{"role": "user", "content": INSTRUCTIONS.format(content)}])
    ability.append('text')
    reward_model.append({
                "style": "rule",
                "ground_truth": "",
            })
    
    extra_info.append({
                'split': 'val',
                'index': idx,
                "user_message": content,
            })

df_val['data_source'] = data_source
df_val['prompt'] = prompt
df_val['ability'] = ability
df_val['reward_model'] = reward_model
df_val['extra_info'] = extra_info

print(df_val.head())
df_val.to_parquet('/nativemm/share/cpfs/songjiaxing/data/code_data/code_val.parquet')