# Code-R1: Reinforcement Learning for Code Generation with Multi-Turn Code Execution

<p align="center">
  <img src="code-r1.png" alt="Code-R1" width="600"/>
</p>

Code-R1 是一个基于 [verl](https://github.com/volcengine/verl)（Volcano Engine Reinforcement Learning for LLMs）框架的**代码生成强化学习训练系统**。项目通过多轮代码执行反馈循环，让大语言模型在"思考 → 编写代码 → 执行观察 → 再思考"的交互过程中，通过强化学习不断提升代码生成能力。

## 项目来源与改进

本项目最初参考了 [code-r1](https://github.com/wyf3/llm_related/tree/main/code-r1) 的基础实现思路。在此基础上，我们进行了大量的工程改造与实验优化，主要改进工作包括：

- **数据工程重构**：基于 xx 数据集重新设计了数据处理流程，编写了完整的数据清洗、格式转换与训练/验证集划分管线，适配 verl 框架所需的 Parquet 数据格式
- **代码执行引擎替换**：将原项目中依赖 Docker 容器的远程代码沙箱方案，替换为基于 Slime ReTool 中 `tool_sandbox.py` 的本地安全沙箱执行方案，实现了进程级隔离、内存限制（4GB）、超时控制（120s）及并发管理（32 并发），显著降低了部署复杂度并提升了执行效率
- **奖励函数体系设计**：设计并实现了多层次的奖励评分机制，涵盖格式校验、代码执行成功率检测、以及基于外部 LLM（Qwen3）的 Answer-as-Judge 正确性评估，构建了从粗粒度格式引导到细粒度语义评判的完整奖励信号链路

## 核心思想

传统的代码生成模型只能一次性输出代码，无法根据执行结果进行迭代修正。Code-R1 引入了**多轮交互式代码执行**机制：

```
用户问题 → LLM 思考(<think>) → 生成代码(<code>) → 沙箱执行 → 观察结果(<observation>) → 继续思考 → ... → 最终回答(<answer>)
```

整个过程通过 GRPO（Group Relative Policy Optimization）强化学习算法进行端到端训练，使模型学会：
1. 何时需要编写代码来辅助解题
2. 如何根据执行结果调整策略
3. 何时给出最终答案


## 核心工作流

### 1. 多轮代码执行循环

`LLMGenerationManager`（`search_r1/llm_agent/generation.py`）是系统的核心，管理多轮 LLM 生成与代码执行的交互循环：

```
┌──────────────────────────────────────────────────────────────┐
│                    run_llm_loop() 主循环                      │
│                                                              │
│  for step in range(max_turns):                               │
│    ┌─────────────────────────────────────────────────────┐   │
│    │ 1. LLM 生成 response                                 │   │
│    │    → <think>推理过程</think>                          │   │
│    │    → <code>Python代码</code>  或  <answer>最终答案     │   │
│    ├─────────────────────────────────────────────────────┤   │
│    │ 2. 后处理：在 </code> 或 </answer> 处截断              │   │
│    ├─────────────────────────────────────────────────────┤   │
│    │ 3. 执行预测：                                        │   │
│    │    - <code> → 沙箱执行代码 → <observation>结果        │   │
│    │    - <answer> → 标记完成                             │   │
│    │    - 无效 → 返回格式提示                              │   │
│    ├─────────────────────────────────────────────────────┤   │
│    │ 4. 更新状态：拼接 prompt + response + observation     │   │
│    │    同时维护 info_mask（屏蔽 observation tokens）      │   │
│    └─────────────────────────────────────────────────────┘   │
│                                                              │
│  最终输出：input_ids + attention_mask + info_mask            │
└──────────────────────────────────────────────────────────────┘
```

### 2. 奖励函数设计

奖励函数（`my_reward/code.py`）采用多层次评分机制：

| 条件 | 分数 | 说明 |
|------|------|------|
| **格式完全正确** | 基础 0.5 | `<think>` → `<code>` → `<observation>` → `<answer>` 标签序列正确 |
| + 代码执行无错误 | +0.5 | 沙箱执行无 error/traceback |
| + LLM 评判正确 | +1.0 | 外部 LLM（Qwen3）判断答案是否正确解决问题 |
| + LLM 评判错误 | -1.0 | 答案未正确解决问题 |
| **格式不正确** | 最高 0.36 | 部分格式奖励（鼓励模型逐步学会正确格式） |

格式不正确时的部分奖励细则：
- 以 `<think>` 开头：+0.1
- 以 `</answer>` 结尾：+0.1
- 包含 `</think><answer>` 序列：+0.1
- 各标签成对出现：每对 +0.02

### 3. 信息掩码机制（Info Mask）

训练时使用 `info_mask` 屏蔽环境返回的 `<observation>` tokens 的梯度，防止模型从执行结果中"作弊"学习。这确保模型学习的是**生成正确代码的能力**，而非记忆执行结果。

### 4. 代码沙箱执行

`tool_sandbox.py` 提供安全的 Python 代码执行环境：
- **安全检查**：扫描危险模式（`os`、`subprocess`、`eval` 等）
- **资源限制**：内存 4GB、超时 120 秒
- **进程隔离**：使用 subprocess 在临时目录中执行
- **并发控制**：最多 32 个并发执行进程
- **内存管理**：自动监控和清理内存使用

## 快速开始

### 环境准备

```bash
# 克隆项目
git clone <repo-url> code-r1
cd code-r1

# 安装依赖
conda create -n code-r1 python=3.11 -y

pip install torch==2.6.0 torchvision==0.21.0 torchaudio==2.6.0 --index-url https://download.pytorch.org/whl/cu124
pip install vllm==0.8.5
MAX_JOBS=4 pip install flash-attn==2.7.4.post1 --no-build-isolation
pip install --only-binary=pyarrow pyarrow
pip install -U "ray[all]"
pip install "transformers>=4.40.0,<4.50.0"
pip install "numpy<2.0"

cd xxx/verl #你的code-r1路径
pip install -e .
```

### 数据准备

1. 准备 JSONL 格式的代码任务数据（每行包含 `instruction` 和 `input` 字段）

2. 运行数据处理脚本，转换为 verl 所需的 Parquet 格式：

```bash
python data/data_process.py
```

数据处理会生成训练集和验证集，每条数据的 prompt 模板为：

```
Generate code to solve the given question.
You must conduct reasoning inside <think> and </think> before <code> and <answer> every time.
After reasoning, if you find you need run code, you can call a code engine by <code> your code </code>
and it will return the run results between <observation> and </observation>.
You can generate and run code as many times as your want.
After reasoning, if you find the given question has already been solved,
you can directly provide the run summary inside <answer> and </answer>.
Question: {问题内容}
```

### 配置修改

编辑 `verl/trainer/config/grpo_trainer.yaml`，修改以下关键配置：

```yaml
# 数据路径
data:
  train_files: /path/to/code_train.parquet
  val_files: /path/to/code_val.parquet

# 模型路径
actor_rollout_ref:
  model:
    path: /path/to/your/model  # 如 Qwen2.5-7B

# 自定义奖励函数路径
custom_reward_function:
  path: /path/to/my_reward/code1.py
  name: compute_score

# 检查点保存路径
trainer:
  default_local_dir: /path/to/save/checkpoints

# 多轮交互配置
max_turns: 5        # 最大交互轮数
do_search: True     # 启用代码执行
```

### 启动训练

```bash
# 单节点 8 GPU 训练
python -m verl.trainer.main_ppo \
    --config-path=config \
    --config-name=grpo_trainer \
    data.train_files=/path/to/code_train.parquet \
    data.val_files=/path/to/code_val.parquet \
    actor_rollout_ref.model.path=/path/to/model \
    custom_reward_function.path=/path/to/my_reward/code1.py \
    trainer.default_local_dir=/path/to/checkpoints \
    trainer.n_gpus_per_node=8 \
    trainer.nnodes=1
```

## 关键配置说明

### 训练超参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `data.max_prompt_length` | 1024 | 最大 prompt 长度 |
| `data.max_response_length` | 4096 | 最大 response 长度 |
| `data.max_start_length` | 1024 | 初始输入最大长度 |
| `data.max_obs_length` | 1000 | observation 最大长度 |
| `data.train_batch_size` | 16 | 训练 batch 大小 |
| `actor_rollout_ref.rollout.n` | 8 | 每个 prompt 生成的 response 数量 |
| `actor_rollout_ref.model.lora_rank` | 32 | LoRA 秩 |
| `algorithm.adv_estimator` | grpo | 优势估计器（GRPO） |
| `max_turns` | 5 | 最大代码执行轮数 |
| `do_search` | True | 是否启用多轮代码执行 |


## 致谢
- [code-r1](https://github.com/wyf3/llm_related/tree/main/code-r1) - 本项目的参考实现
- [verl](https://github.com/volcengine/verl) - ByteDance Seed 团队开发的 LLM 强化学习训练框架
- [Search-R1](https://github.com/PeterGriffinJin/Search-R1) - 搜索增强推理的灵感来源
- [HybridFlow](https://arxiv.org/abs/2409.19256v2) - verl 的理论基础论文
